#!/bin/bash
# PROBLEM STATEMENT (Q59)
# Generate a frequency list of all shell commands you've used and display the
# top five commands with their counts (hint: use history/hist).
# ----------------------------------------------------------------------
# Q59 - Top five shell commands from history
# Run     : ./q59_top5_commands_history.sh
# Reads   : $HISTFILE (default ~/.bash_history)
# Note    : in an interactive shell you can also run:
#           history | awk '{print $2}' | sort | uniq -c | sort -rn | head -5
#           bash saves history when the terminal closes (or run 'history -a' first).

HIST="${HISTFILE:-$HOME/.bash_history}"

if [ ! -f "$HIST" ]; then
    echo "No history file found at $HIST"
    exit 1
fi

echo "Top 5 commands in $HIST:"
echo "COUNT  COMMAND"
awk '!/^#/ && NF {print $1}' "$HIST" | sort | uniq -c | sort -rn | head -5
