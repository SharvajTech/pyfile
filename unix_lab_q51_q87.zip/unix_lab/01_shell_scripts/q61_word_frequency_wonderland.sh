#!/bin/bash
# PROBLEM STATEMENT (Q61)
# Produce a word-frequency list for wonderland.txt
# (hint: use grep, tr, sort, uniq, or similar tools).
# ----------------------------------------------------------------------
# Q61 - Word frequency list
# Run     : ./q61_word_frequency_wonderland.sh [wonderland.txt]
#           (defaults to wonderland.txt in the current folder)

file="${1:-wonderland.txt}"

if [ ! -f "$file" ]; then
    echo "File '$file' not found."
    exit 1
fi

echo "Total words : $(tr -cs 'A-Za-z' '\n' < "$file" | grep -c .)"
echo "Top 25 words (count word):"
tr -cs 'A-Za-z' '\n' < "$file" | tr 'A-Z' 'a-z' | grep -v '^$' \
    | sort | uniq -c | sort -rn | head -n 25
