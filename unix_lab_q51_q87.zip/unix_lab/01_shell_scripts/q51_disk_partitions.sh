#!/bin/bash
# PROBLEM STATEMENT (Q51)
# Create a shell script that displays disk partitions, their sizes, and disk usage/free space.
# ----------------------------------------------------------------------
# Q51 - Disk partitions, sizes and usage
# Run     : chmod +x q51_disk_partitions.sh && ./q51_disk_partitions.sh
# Uses    : lsblk (partitions + sizes), df (usage + free space)
# Note    : 'fdisk -l' also lists partitions but needs root (sudo fdisk -l).

echo "=== Disk partitions and sizes (lsblk) ==="
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT
echo
echo "=== Disk usage and free space (df) ==="
df -hT -x tmpfs -x devtmpfs -x squashfs
