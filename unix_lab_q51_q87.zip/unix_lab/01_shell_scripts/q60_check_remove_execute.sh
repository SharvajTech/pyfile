#!/bin/bash
# PROBLEM STATEMENT (Q60)
# Write a shell script that takes a filename and checks whether it is executable;
# then modify it to remove execute permission if the file is executable.
# ----------------------------------------------------------------------
# Q60 - Check executable bit and remove it
# Run     : ./q60_check_remove_execute.sh myscript.sh

if [ $# -ne 1 ]; then
    echo "Usage: $0 filename"
    exit 1
fi

f="$1"

if [ ! -f "$f" ]; then
    echo "Error: '$f' is not a regular file or does not exist"
    exit 1
fi

if [ -x "$f" ]; then
    echo "'$f' IS executable."
    echo "Before: $(ls -l "$f")"
    chmod a-x "$f"
    echo "After : $(ls -l "$f")"
    echo "Execute permission removed."
else
    echo "'$f' is NOT executable. Nothing changed."
fi
