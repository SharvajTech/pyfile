#!/bin/bash
# PROBLEM STATEMENT (Q62)
# Create a bash script that accepts two or more arguments where each argument is a
# filename; if fewer than two arguments are given print an error; if any file does
# not exist print an error; otherwise concatenate the files.
# ----------------------------------------------------------------------
# Q62 - Concatenate files
# Run     : ./q62_concatenate_files.sh a.txt b.txt > joined.txt
#           (concatenated output goes to stdout; redirect it to save)

if [ $# -lt 2 ]; then
    echo "Error: at least two filenames are required." >&2
    echo "Usage: $0 file1 file2 [file3 ...]" >&2
    exit 1
fi

missing=0
for f in "$@"; do
    if [ ! -f "$f" ]; then
        echo "Error: file '$f' does not exist." >&2
        missing=1
    fi
done

if [ $missing -eq 1 ]; then
    exit 1
fi

cat "$@"
