#!/bin/bash
# PROBLEM STATEMENT (Q52)
# Write a shell script to locate a given file on the system using find or locate.
# ----------------------------------------------------------------------
# Q52 - Locate a file
# Run     : ./q52_locate_file.sh notes.txt
# Uses    : locate (fast, uses a database) or find (slow, always current).
# Note    : if locate misses a new file, run 'sudo updatedb' first.

if [ $# -ne 1 ]; then
    echo "Usage: $0 filename"
    exit 1
fi

name="$1"
echo "Searching for '$name' ..."

if command -v locate >/dev/null 2>&1; then
    # -b matches the base name exactly (\name = exact base name)
    results=$(locate -b "\\$name" 2>/dev/null)
else
    results=$(find / -name "$name" 2>/dev/null)
fi

if [ -n "$results" ]; then
    echo "$results"
else
    echo "'$name' not found on the system."
fi
