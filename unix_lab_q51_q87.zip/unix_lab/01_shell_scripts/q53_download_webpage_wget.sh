#!/bin/bash
# PROBLEM STATEMENT (Q53)
# Write a shell script that downloads a webpage from a given URL using wget.
# ----------------------------------------------------------------------
# Q53 - Download a webpage with wget
# Run     : ./q53_download_webpage_wget.sh https://example.com [output.html]
# Needs   : wget (sudo apt install wget)

if [ $# -lt 1 ]; then
    echo "Usage: $0 URL [output_file]"
    exit 1
fi

url="$1"
out="${2:-page.html}"

if ! command -v wget >/dev/null 2>&1; then
    echo "wget is not installed (sudo apt install wget)"
    exit 1
fi

if wget -q -O "$out" "$url"; then
    echo "Downloaded $url -> $out ($(wc -c < "$out") bytes)"
else
    echo "Download failed for $url"
    rm -f "$out"
    exit 1
fi
