#!/bin/bash
# PROBLEM STATEMENT (Q63)
# Write a shell script to download a file from a remote machine using lftp with get/mget.
# ----------------------------------------------------------------------
# Q63 - Download with lftp (get = one file, mget = many files with wildcard)
# Usage   : ./q63_lftp_download.sh HOST USER REMOTE_PATH [LOCAL_NAME]
# Examples: ./q63_lftp_download.sh 192.168.1.10 student /home/student/report.txt
#           ./q63_lftp_download.sh 192.168.1.10 student '/home/student/*.txt'   (mget)
# Needs   : lftp (sudo apt install lftp); you will be asked for the password.

if [ $# -lt 3 ]; then
    echo "Usage: $0 HOST USER REMOTE_PATH [LOCAL_NAME]"
    exit 1
fi

host="$1"; user="$2"; remote="$3"; local_name="$4"

if ! command -v lftp >/dev/null 2>&1; then
    echo "lftp is not installed (sudo apt install lftp)"
    exit 1
fi

if [[ "$remote" == *'*'* ]]; then
    cmd="mget $remote"                       # many files
elif [ -n "$local_name" ]; then
    cmd="get $remote -o $local_name"         # one file, custom local name
else
    cmd="get $remote"                        # one file, same name
fi

lftp -u "$user", -e "$cmd; bye" "$host"
