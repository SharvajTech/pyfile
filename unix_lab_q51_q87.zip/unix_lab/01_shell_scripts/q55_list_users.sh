#!/bin/bash
# PROBLEM STATEMENT (Q55)
# Write a shell script that displays system users (using finger or who).
# ----------------------------------------------------------------------
# Q55 - Display system users
# Run     : ./q55_list_users.sh
# Uses    : finger if installed, otherwise who (always available).

if command -v finger >/dev/null 2>&1; then
    echo "=== System users (finger) ==="
    finger
else
    echo "=== System users (who) ==="
    who
fi
