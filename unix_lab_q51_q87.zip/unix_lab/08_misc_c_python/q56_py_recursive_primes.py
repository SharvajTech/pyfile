"""
PROBLEM STATEMENT (Q56)
Implement a recursive Python function that generates prime numbers up to a given
limit (limit passed as a parameter).

Q56 - Recursive prime generator
Run     : python3 q56_py_recursive_primes.py 50
Example : prints [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
Note    : recursion depth grows with the limit; for large limits raise the limit
          with sys.setrecursionlimit() as shown in main().
"""
import sys


def is_prime(n, d=2):
    """Recursively test whether n is prime by trying divisors d, d+1, ... up to sqrt(n)."""
    if n < 2:
        return False
    if d * d > n:
        return True
    if n % d == 0:
        return False
    return is_prime(n, d + 1)


def primes_up_to(limit, current=2):
    """Recursively collect all primes from current up to limit (inclusive)."""
    if current > limit:
        return []
    rest = primes_up_to(limit, current + 1)
    return ([current] + rest) if is_prime(current) else rest


def main():
    if len(sys.argv) != 2:
        print(f"Usage: python3 {sys.argv[0]} LIMIT")
        sys.exit(1)
    limit = int(sys.argv[1])
    sys.setrecursionlimit(max(1000, limit * 3))
    print(primes_up_to(limit))


if __name__ == "__main__":
    main()
