/*
 * PROBLEM STATEMENT (Q57)
 * Write a program that prints a pyramid with the number of lines supplied by the user;
 * center the pyramid as closely as possible. (Hint: nested loops)
 */
/*
 * Q57 - Centered pyramid
 * Compile : gcc -Wall q57_pyramid_centered.c -o q57_pyramid_centered
 * Run     : ./q57_pyramid_centered        then enter the number of lines
 * Example : 3 lines ->
 *               *
 *              ***
 *             *****
 */
#include <stdio.h>

int main(void)
{
    int lines;
    printf("Enter number of lines: ");
    if (scanf("%d", &lines) != 1 || lines <= 0) {
        fprintf(stderr, "Please enter a positive number.\n");
        return 1;
    }

    for (int i = 1; i <= lines; i++) {
        for (int s = 0; s < lines - i; s++)     /* leading spaces */
            putchar(' ');
        for (int k = 0; k < 2 * i - 1; k++)     /* stars */
            putchar('*');
        putchar('\n');
    }
    return 0;
}
