/*
 * PROBLEM STATEMENT (Q58)
 * Given a text file, write code to count word frequencies in the file (use file handling).
 */
/*
 * Q58 - Word frequency count from a text file
 * Compile : gcc -Wall q58_word_frequency_count.c -o q58_word_frequency_count
 * Run     : ./q58_word_frequency_count wonderland.txt
 * Notes   : a word = a run of letters; case is ignored ("The" and "the" count together).
 *           Output is sorted by frequency, highest first.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_UNIQUE 5000
#define WORD_LEN   64

struct entry { char word[WORD_LEN]; int count; };

static struct entry table[MAX_UNIQUE];
static int nentries = 0;

static void add_word(const char *w)
{
    for (int i = 0; i < nentries; i++) {
        if (strcmp(table[i].word, w) == 0) { table[i].count++; return; }
    }
    if (nentries >= MAX_UNIQUE) { fprintf(stderr, "word table full\n"); return; }
    strncpy(table[nentries].word, w, WORD_LEN - 1);
    table[nentries].word[WORD_LEN - 1] = '\0';
    table[nentries].count = 1;
    nentries++;
}

static int by_count_desc(const void *a, const void *b)
{
    const struct entry *x = a, *y = b;
    if (y->count != x->count) return y->count - x->count;
    return strcmp(x->word, y->word);
}

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s textfile\n", argv[0]); return 1; }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) { perror("fopen"); return 1; }

    char buf[WORD_LEN];
    int len = 0, c;
    long total = 0;
    while ((c = fgetc(fp)) != EOF) {
        if (isalpha(c)) {
            if (len < WORD_LEN - 1) buf[len++] = (char)tolower(c);
        } else if (len > 0) {
            buf[len] = '\0';
            add_word(buf);
            total++;
            len = 0;
        }
    }
    if (len > 0) { buf[len] = '\0'; add_word(buf); total++; }
    fclose(fp);

    qsort(table, nentries, sizeof table[0], by_count_desc);

    printf("Total words: %ld   Unique words: %d\n", total, nentries);
    printf("%-22s %s\n", "WORD", "COUNT");
    for (int i = 0; i < nentries && i < 25; i++)
        printf("%-22s %d\n", table[i].word, table[i].count);
    if (nentries > 25) printf("... (%d more, top 25 shown)\n", nentries - 25);
    return 0;
}
