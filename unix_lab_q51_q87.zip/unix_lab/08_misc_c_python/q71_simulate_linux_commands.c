/*
 * PROBLEM STATEMENT (Q71)
 * Implement programs that simulate common Linux commands such as cat, ls, cp, mv, head, etc.
 */
/*
 * Q71 - Simulated Linux commands: cat, ls, cp, mv, head (one program, subcommand style)
 * Compile : gcc -Wall q71_simulate_linux_commands.c -o q71_simulate_linux_commands
 * Run     : ./q71_simulate_linux_commands cat  file.txt
 *           ./q71_simulate_linux_commands ls   [directory]
 *           ./q71_simulate_linux_commands cp   src.txt dst.txt
 *           ./q71_simulate_linux_commands mv   old.txt new.txt
 *           ./q71_simulate_linux_commands head [-n N] file.txt     (default N = 10)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

static int do_cat(const char *file)
{
    FILE *fp = fopen(file, "rb");
    if (!fp) { perror(file); return 1; }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, fp)) > 0) fwrite(buf, 1, n, stdout);
    fclose(fp);
    return 0;
}

static int do_ls(const char *dir)
{
    DIR *d = opendir(dir);
    if (!d) { perror(dir); return 1; }
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;          /* hide dot-files like ls */
        printf("%s\n", e->d_name);
    }
    closedir(d);
    return 0;
}

static int copy_file(const char *src, const char *dst)
{
    FILE *in = fopen(src, "rb");
    if (!in) { perror(src); return 1; }
    FILE *out = fopen(dst, "wb");
    if (!out) { perror(dst); fclose(in); return 1; }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, in)) > 0) fwrite(buf, 1, n, out);
    fclose(in);
    fclose(out);
    return 0;
}

static int do_cp(const char *src, const char *dst)
{
    return copy_file(src, dst);
}

static int do_mv(const char *src, const char *dst)
{
    if (rename(src, dst) == 0) return 0;            /* same filesystem: just rename */
    if (copy_file(src, dst) != 0) return 1;          /* otherwise copy then delete   */
    if (remove(src) != 0) { perror("remove"); return 1; }
    return 0;
}

static int do_head(const char *file, int nlines)
{
    FILE *fp = fopen(file, "r");
    if (!fp) { perror(file); return 1; }
    int c, lines = 0;
    while (lines < nlines && (c = fgetc(fp)) != EOF) {
        putchar(c);
        if (c == '\n') lines++;
    }
    fclose(fp);
    return 0;
}

static void usage(const char *prog)
{
    fprintf(stderr,
        "Usage:\n"
        "  %s cat  FILE\n"
        "  %s ls   [DIR]\n"
        "  %s cp   SRC DST\n"
        "  %s mv   SRC DST\n"
        "  %s head [-n N] FILE\n", prog, prog, prog, prog, prog);
}

int main(int argc, char *argv[])
{
    if (argc < 2) { usage(argv[0]); return 1; }

    if (strcmp(argv[1], "cat") == 0 && argc == 3)
        return do_cat(argv[2]);
    if (strcmp(argv[1], "ls") == 0)
        return do_ls(argc == 3 ? argv[2] : ".");
    if (strcmp(argv[1], "cp") == 0 && argc == 4)
        return do_cp(argv[2], argv[3]);
    if (strcmp(argv[1], "mv") == 0 && argc == 4)
        return do_mv(argv[2], argv[3]);
    if (strcmp(argv[1], "head") == 0) {
        int n = 10;
        if (argc == 5 && strcmp(argv[2], "-n") == 0) { n = atoi(argv[3]); return do_head(argv[4], n); }
        if (argc == 3) return do_head(argv[2], n);
    }

    usage(argv[0]);
    return 1;
}
