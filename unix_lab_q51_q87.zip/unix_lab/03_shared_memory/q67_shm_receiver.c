/*
 * PROBLEM STATEMENT (Q67)
 * Implement IPC using shared memory (shmget, shmat, shmdt) where one process sends
 * A-Z or 1-100 (from user input) and another process receives it.
 */
/*
 * Q67 - Receiver (pairs with q67_shm_sender.c)
 * Compile : gcc -Wall q67_shm_receiver.c -o q67_shm_receiver
 * Run     : start q67_shm_sender first, then ./q67_shm_receiver in the same folder
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

struct shared { volatile int ready; char data[SHM_SIZE]; };

int main(void)
{
    key_t key = ftok(".", 'S');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, sizeof(struct shared), 0666);   /* do not create */
    if (shmid == -1) { perror("shmget (start the sender first)"); return 1; }

    struct shared *shm = shmat(shmid, NULL, 0);
    if (shm == (void *)-1) { perror("shmat"); return 1; }

    while (shm->ready != 1) sleep(1);     /* wait for the sender */
    printf("Received: %s\n", shm->data);

    shm->ready = 2;                       /* tell sender we are done */
    shmdt(shm);
    return 0;
}
