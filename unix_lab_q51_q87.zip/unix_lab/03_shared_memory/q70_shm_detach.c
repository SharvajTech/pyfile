/*
 * PROBLEM STATEMENT (Q70)
 * Create programs where different processes perform different shared-memory
 * operations: create, delete, attach, detach (shmget, shmat, shmdt).
 */
/*
 * Q70 - Program 3 of 4: DETACH after reading (q70_shm_detach.c)
 * Compile : gcc -Wall q70_shm_detach.c -o q70_shm_detach
 * Run     : ./q70_shm_detach     (run while q70_shm_attach is still sleeping, or after it)
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(void)
{
    key_t key = ftok(".", 'M');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, SHM_SIZE, 0666);
    if (shmid == -1) { perror("shmget (run q70_shm_create first)"); return 1; }

    char *addr = shmat(shmid, NULL, 0);             /* attach to read */
    if (addr == (char *)-1) { perror("shmat"); return 1; }
    printf("DETACH: read message: \"%s\"\n", addr);

    if (shmdt(addr) == -1) { perror("shmdt"); return 1; }   /* DETACH */
    printf("        detached from shared memory.\n");

    struct shmid_ds info;
    shmctl(shmid, IPC_STAT, &info);
    printf("        processes still attached = %ld\n", (long)info.shm_nattch);
    return 0;
}
