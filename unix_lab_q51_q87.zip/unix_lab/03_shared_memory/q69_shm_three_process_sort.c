/*
 * PROBLEM STATEMENT (Q69)
 * Write a shared-memory IPC program where:
 *   Process 1 takes numbers from the user and writes them to shared memory,
 *   Process 2 sorts the numbers and writes them back,
 *   Process 3 displays the sorted data.
 */
/*
 * Q69 - Three processes sharing one array in shared memory
 * Compile : gcc -Wall q69_shm_three_process_sort.c -o q69_shm_three_process_sort
 * Run     : ./q69_shm_three_process_sort
 * Sync    : parent runs P1, waits; then P2, waits; then P3 - so each step sees the
 *           previous step's result (wait() is the synchronization here).
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX_NUMS 100

struct shared { int n; int arr[MAX_NUMS]; };

static void process1_input(struct shared *s)          /* takes numbers from user */
{
    printf("[P1] How many numbers (max %d)? ", MAX_NUMS);
    if (scanf("%d", &s->n) != 1 || s->n < 1 || s->n > MAX_NUMS) {
        fprintf(stderr, "[P1] invalid count\n");
        exit(1);
    }
    for (int i = 0; i < s->n; i++) {
        printf("[P1] number %d: ", i + 1);
        if (scanf("%d", &s->arr[i]) != 1) { fprintf(stderr, "[P1] bad input\n"); exit(1); }
    }
    printf("[P1] wrote %d numbers to shared memory\n", s->n);
}

static void process2_sort(struct shared *s)           /* sorts in shared memory */
{
    for (int i = 0; i < s->n - 1; i++)
        for (int j = 0; j < s->n - 1 - i; j++)
            if (s->arr[j] > s->arr[j + 1]) {
                int t = s->arr[j]; s->arr[j] = s->arr[j + 1]; s->arr[j + 1] = t;
            }
    printf("[P2] sorted the numbers in shared memory\n");
}

static void process3_display(struct shared *s)        /* displays sorted data */
{
    printf("[P3] sorted list: ");
    for (int i = 0; i < s->n; i++) printf("%d ", s->arr[i]);
    printf("\n");
}

int main(void)
{
    int shmid = shmget(IPC_PRIVATE, sizeof(struct shared), IPC_CREAT | 0600);
    if (shmid == -1) { perror("shmget"); return 1; }
    struct shared *s = shmat(shmid, NULL, 0);
    if (s == (void *)-1) { perror("shmat"); return 1; }

    pid_t pid;
    fflush(stdout);
    pid = fork();
    if (pid == 0) { process1_input(s); exit(0); }
    waitpid(pid, NULL, 0);

    fflush(stdout);
    pid = fork();
    if (pid == 0) { process2_sort(s); exit(0); }
    waitpid(pid, NULL, 0);

    fflush(stdout);
    pid = fork();
    if (pid == 0) { process3_display(s); exit(0); }
    waitpid(pid, NULL, 0);

    shmdt(s);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
