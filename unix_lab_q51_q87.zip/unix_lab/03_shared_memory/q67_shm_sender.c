/*
 * PROBLEM STATEMENT (Q67)
 * Implement IPC using shared memory (shmget, shmat, shmdt) where one process sends
 * A-Z or 1-100 (from user input) and another process receives it.
 */
/*
 * Q67 - Sender (pairs with q67_shm_receiver.c)
 * Compile : gcc -Wall q67_shm_sender.c -o q67_shm_sender
 * Run     : ./q67_shm_sender     (start this FIRST - it creates the segment)
 *           ./q67_shm_receiver   (then run this in the same folder)
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

struct shared { volatile int ready; char data[SHM_SIZE]; };

int main(void)
{
    key_t key = ftok(".", 'S');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, sizeof(struct shared), IPC_CREAT | 0666);
    if (shmid == -1) { perror("shmget"); return 1; }

    struct shared *shm = shmat(shmid, NULL, 0);
    if (shm == (void *)-1) { perror("shmat"); return 1; }

    int choice;
    printf("1) Send letters A-Z\n2) Send numbers 1-100\nChoice: ");
    if (scanf("%d", &choice) != 1) { fprintf(stderr, "bad input\n"); return 1; }

    shm->ready = 0;
    if (choice == 1) {
        strcpy(shm->data, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    } else if (choice == 2) {
        char *p = shm->data;
        for (int i = 1; i <= 100; i++) p += sprintf(p, "%d ", i);
    } else {
        fprintf(stderr, "invalid choice\n");
        shmdt(shm);
        return 1;
    }
    shm->ready = 1;                       /* tell the receiver data is ready */
    printf("Sent. Waiting for the receiver to finish...\n");

    while (shm->ready == 1) sleep(1);     /* receiver sets ready = 2 when done */
    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);        /* remove segment */
    printf("Done. Segment removed.\n");
    return 0;
}
