/*
 * PROBLEM STATEMENT (Q70)
 * Create programs where different processes perform different shared-memory
 * operations: create, delete, attach, detach (shmget, shmat, shmdt).
 */
/*
 * Q70 - Program 4 of 4: DELETE (mark for removal) the segment (q70_shm_delete.c)
 * Compile : gcc -Wall q70_shm_delete.c -o q70_shm_delete
 * Run     : ./q70_shm_delete
 * Note    : the segment is destroyed once the last process detaches.
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(void)
{
    key_t key = ftok(".", 'M');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, SHM_SIZE, 0666);
    if (shmid == -1) { perror("shmget"); return 1; }

    if (shmctl(shmid, IPC_RMID, NULL) == -1) { perror("shmctl IPC_RMID"); return 1; }
    printf("DELETE: segment %d marked for deletion (IPC_RMID).\n", shmid);
    return 0;
}
