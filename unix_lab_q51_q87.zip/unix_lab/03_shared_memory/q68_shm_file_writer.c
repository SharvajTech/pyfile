/*
 * PROBLEM STATEMENT (Q68)
 * Implement IPC via shared memory where one process reads A-Z or 1-100 from a file
 * and writes it into shared memory, and another process reads from shared memory
 * and writes to a different file (same directory, different filename).
 */
/*
 * Q68 - Process 1: read a file -> shared memory (pairs with q68_shm_file_reader.c)
 * Compile : gcc -Wall q68_shm_file_writer.c -o q68_shm_file_writer
 * Setup   : create an input file, e.g.  seq 1 100 > input.txt   or   echo ABC...Z > input.txt
 * Run     : ./q68_shm_file_writer input.txt   (start FIRST)
 *           ./q68_shm_file_reader output.txt  (then in the same folder)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 4096

struct shared { volatile int ready; long len; char data[SHM_SIZE]; };

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s input_file\n", argv[0]); return 1; }

    FILE *fp = fopen(argv[1], "rb");
    if (!fp) { perror("fopen"); return 1; }

    key_t key = ftok(".", 'F');
    if (key == -1) { perror("ftok"); return 1; }
    int shmid = shmget(key, sizeof(struct shared), IPC_CREAT | 0666);
    if (shmid == -1) { perror("shmget"); return 1; }
    struct shared *shm = shmat(shmid, NULL, 0);
    if (shm == (void *)-1) { perror("shmat"); return 1; }

    shm->ready = 0;
    shm->len = fread(shm->data, 1, SHM_SIZE, fp);
    fclose(fp);
    shm->ready = 1;
    printf("Wrote %ld bytes from %s into shared memory.\n", shm->len, argv[1]);

    while (shm->ready == 1) sleep(1);     /* wait until reader is done */
    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
