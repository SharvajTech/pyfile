/*
 * PROBLEM STATEMENT (Q70)
 * Create programs where different processes perform different shared-memory
 * operations: create, delete, attach, detach (shmget, shmat, shmdt).
 */
/*
 * Q70 - Program 2 of 4: ATTACH and write a message (q70_shm_attach.c)
 * Compile : gcc -Wall q70_shm_attach.c -o q70_shm_attach
 * Run     : ./q70_shm_attach     (stays attached 30 s - run q70_shm_detach / ipcs -m meanwhile)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(void)
{
    key_t key = ftok(".", 'M');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, SHM_SIZE, 0666);        /* segment must already exist */
    if (shmid == -1) { perror("shmget (run q70_shm_create first)"); return 1; }

    setvbuf(stdout, NULL, _IONBF, 0);
    char *addr = shmat(shmid, NULL, 0);             /* ATTACH */
    if (addr == (char *)-1) { perror("shmat"); return 1; }

    strcpy(addr, "Hello from the attach process");
    printf("ATTACH: attached at %p and wrote a message.\n", (void *)addr);

    struct shmid_ds info;
    shmctl(shmid, IPC_STAT, &info);
    printf("        number of processes attached now = %ld\n", (long)info.shm_nattch);
    printf("        staying attached for 30 seconds...\n");
    sleep(30);

    shmdt(addr);                                    /* detach on the way out */
    fflush(stdout);
    return 0;
}
