/*
 * PROBLEM STATEMENT (Q70)
 * Create programs where different processes perform different shared-memory
 * operations: create, delete, attach, detach (shmget, shmat, shmdt).
 */
/*
 * Q70 - Program 1 of 4: CREATE the shared memory segment (q70_shm_create.c)
 * Compile : gcc -Wall q70_shm_create.c -o q70_shm_create
 * Run     : ./q70_shm_create        (then q70_shm_attach, q70_shm_detach, q70_shm_delete)
 * Check   : ipcs -m
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

int main(void)
{
    key_t key = ftok(".", 'M');
    if (key == -1) { perror("ftok"); return 1; }

    int shmid = shmget(key, SHM_SIZE, IPC_CREAT | IPC_EXCL | 0666);
    if (shmid == -1) { perror("shmget (already exists? run q70_shm_delete first)"); return 1; }

    printf("CREATE: shared memory segment created, shmid = %d, size = %d bytes\n",
           shmid, SHM_SIZE);
    return 0;
}
