/*
 * PROBLEM STATEMENT (Q68)
 * Implement IPC via shared memory where one process reads A-Z or 1-100 from a file
 * and writes it into shared memory, and another process reads from shared memory
 * and writes to a different file (same directory, different filename).
 */
/*
 * Q68 - Process 2: shared memory -> output file (pairs with q68_shm_file_writer.c)
 * Compile : gcc -Wall q68_shm_file_reader.c -o q68_shm_file_reader
 * Run     : start q68_shm_file_writer first, then:  ./q68_shm_file_reader output.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 4096

struct shared { volatile int ready; long len; char data[SHM_SIZE]; };

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s output_file\n", argv[0]); return 1; }

    key_t key = ftok(".", 'F');
    if (key == -1) { perror("ftok"); return 1; }
    int shmid = shmget(key, sizeof(struct shared), 0666);
    if (shmid == -1) { perror("shmget (start the writer first)"); return 1; }
    struct shared *shm = shmat(shmid, NULL, 0);
    if (shm == (void *)-1) { perror("shmat"); return 1; }

    while (shm->ready != 1) sleep(1);

    FILE *fp = fopen(argv[1], "wb");
    if (!fp) { perror("fopen"); return 1; }
    fwrite(shm->data, 1, shm->len, fp);
    fclose(fp);
    printf("Copied %ld bytes from shared memory to %s\n", shm->len, argv[1]);

    shm->ready = 2;                       /* writer may now clean up */
    shmdt(shm);
    return 0;
}
