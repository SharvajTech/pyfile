/*
 * PROBLEM STATEMENT (Q73 - Q76)
 * Q73: Write two programs that exchange messages to form the dialog:
 *   Q74: Process 1 sends "Hi?"
 *   Q75: Process 2 receives and replies "Hello"
 *   Q76: Process 1 receives the reply and then sends "I am fine"
 * Use System V message queues (msgget, msgsnd, msgrcv).
 */
/*
 * Q73 / Q74 / Q76 - Process 1 (pairs with q73_msgq_dialog_process2.c)
 * Compile : gcc -Wall q73_msgq_dialog_process1.c -o q73_msgq_dialog_process1
 * Run     : ./q73_msgq_dialog_process1   (in one terminal)
 *           ./q73_msgq_dialog_process2   (in another terminal, same folder)
 * Types   : type 2 = message for Process 2, type 1 = message for Process 1
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define TO_P1 1
#define TO_P2 2

struct dialog { long mtype; char text[64]; };

static void send_msg(int qid, long type, const char *txt)
{
    struct dialog m;
    m.mtype = type;
    strncpy(m.text, txt, sizeof m.text - 1);
    m.text[sizeof m.text - 1] = '\0';
    if (msgsnd(qid, &m, strlen(m.text) + 1, 0) == -1) { perror("msgsnd"); exit(1); }
}

static void recv_msg(int qid, long type, struct dialog *m)
{
    if (msgrcv(qid, m, sizeof m->text, type, 0) == -1) { perror("msgrcv"); exit(1); }
}

int main(void)
{
    key_t key = ftok(".", 'D');
    if (key == -1) { perror("ftok"); return 1; }
    int qid = msgget(key, IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }

    struct dialog m;

    send_msg(qid, TO_P2, "Hi?");                 /* Q74: P1 sends "Hi?"  */
    printf("Process 1 sent : Hi?\n");

    recv_msg(qid, TO_P1, &m);                    /* Q76: P1 gets reply   */
    printf("Process 1 got  : %s\n", m.text);

    send_msg(qid, TO_P2, "I am fine");           /* Q76: P1 sends reply  */
    printf("Process 1 sent : I am fine\n");
    return 0;
}
