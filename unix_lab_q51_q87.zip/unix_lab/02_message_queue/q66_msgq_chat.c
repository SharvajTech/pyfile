/*
 * PROBLEM STATEMENT (Q66)
 * Write a program to demonstrate IPC via message queues (msgget, msgsnd, msgrcv)
 * for chatting between two or three users.
 */
/*
 * Q66 - Multi-user chat with System V message queue (2 or 3 users)
 * Compile : gcc -Wall q66_msgq_chat.c -o q66_msgq_chat
 * Run     : open 2 or 3 terminals in THIS folder and run one per terminal:
 *             ./q66_msgq_chat 1
 *             ./q66_msgq_chat 2
 *             ./q66_msgq_chat 3        (optional third user)
 *           Type a line and press Enter - it goes to every other user.
 *           Type /quit to leave.
 * Idea    : each user has a message type = its user id. A message to user T is
 *           sent with mtype = T, so each user only receives messages meant for it.
 * Check   : ipcs -q          Clean up: ipcrm -Q 0x... (or ipcrm -q <id>)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define MAX_USERS 3
#define TEXT_LEN  256

struct chatmsg { long mtype; char text[TEXT_LEN]; };

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s <user-id 1..%d>\n", argv[0], MAX_USERS); return 1; }
    int me = atoi(argv[1]);
    if (me < 1 || me > MAX_USERS) { fprintf(stderr, "user id must be 1..%d\n", MAX_USERS); return 1; }

    key_t key = ftok(".", 'C');
    if (key == -1) { perror("ftok"); return 1; }
    int qid = msgget(key, IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }

    printf("User %d joined. Type messages, /quit to leave.\n", me);

    pid_t child = fork();
    if (child == -1) { perror("fork"); return 1; }

    if (child == 0) {                       /* child: receive messages for me */
        struct chatmsg m;
        for (;;) {
            if (msgrcv(qid, &m, sizeof m.text, me, 0) == -1) break;
            printf("\r%s\nYou: ", m.text);   /* show incoming, re-show prompt */
            fflush(stdout);
        }
        return 0;
    }

    /* parent: read from keyboard and send to every other user */
    char line[TEXT_LEN];
    while (fgets(line, sizeof line, stdin)) {
        line[strcspn(line, "\n")] = '\0';
        int quit = (strcmp(line, "/quit") == 0);

        struct chatmsg m;
        snprintf(m.text, sizeof m.text, quit ? "[user %d left the chat]" : "[user %d]: %s", me, line);
        for (int t = 1; t <= MAX_USERS; t++) {
            if (t == me) continue;
            m.mtype = t;
            if (msgsnd(qid, &m, strlen(m.text) + 1, 0) == -1) perror("msgsnd");
        }
        if (quit) break;
        printf("You: ");
        fflush(stdout);
    }

    kill(child, SIGTERM);
    waitpid(child, NULL, 0);
    printf("Bye from user %d\n", me);
    return 0;
}
