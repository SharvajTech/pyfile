# UNIX Operating System Lab - Q51 to Q87

Every source file starts with a **PROBLEM STATEMENT (Qnn)** block (the question text),
followed by a comment block that says **how to compile and run it**.
Run `./build.sh` to compile all C programs into `./bin`.

| Folder | Questions | Notes |
|---|---|---|
| 01_shell_scripts | Q51-Q55, Q59-Q63 | Bash scripts (run directly, no compile). Q54 is a duplicate of Q53 |
| 02_message_queue | Q66, Q73-Q76 | System V message queues (`gcc file.c -o name`) |
| 03_shared_memory | Q67-Q70 | System V shared memory (`shmget/shmat/shmdt`) |
| 04_semaphores | Q64, Q65, Q72, Q84, Q85 | Q64/Q65 use `semaphore.h` (POSIX, `-pthread`); Q72/Q84/Q85 use `sys/sem.h` (System V) |
| 05_sockets | Q77-Q80 | TCP/UDP in C; Q79/Q80 have iterative and concurrent servers |
| 06_pipes | Q81-Q83 | Unnamed pipes: `pipe()` + `fork()` |
| 07_file_locking | Q86, Q87 | `lockf()` (Q86) and `flock()` (Q87) |
| 08_misc_c_python | Q56-Q58, Q71 | Q56 is Python (`python3`); the rest are C |

Files are named `qNN_<topic>_<what-it-does>[_role].c`; programs that come in pairs (sender/receiver,
server/client, writer/reader, process1/process2) - start them in separate terminals in the order given
in the file header.

System V IPC programs use `ftok(".", ...)`, so run both halves from the **same directory**.

Cleanup if a run was interrupted:  `ipcs` to list, `ipcrm -q|-m|-s <id>` to remove, `rm -f *fifo* lockf_shared.txt flock_shared.txt`.

Questions with a shell-command part: Q59 and Q61 read history / a text file, and Q82 and Q83 show
extra shell pipelines (`ls -l | ./q83...`) in their header comments.

## Notes on specific questions

- **Q54** is marked "(Duplicate)" in the question paper. It has the same solution as Q53.
- **Q73-Q76** form one dialog (Hi? / Hello / I am fine). Both programs for it are in `02_message_queue`.
- **Q84 - sem.h vs semaphore.h:** `<sys/sem.h>` is System V (kernel objects, sets of semaphores,
  `semget/semop/semctl`). `<semaphore.h>` is POSIX (`sem_init/sem_wait/sem_post`, one semaphore per
  object, named or unnamed). The note is also in the file header.
- **Q85** is three separate programs: init (shows the semaphore ID), P (wait), V (signal).
- **Q70** is four programs: create, attach, detach, delete.
- **Q72** needs an interactive terminal (type a username, Enter, then a password, Enter).

## File index (Q number -> file)

| Q | Folder | File |
|---|---|---|
| 51 | 01_shell_scripts | q51_disk_partitions.sh |
| 52 | 01_shell_scripts | q52_locate_file.sh |
| 53 | 01_shell_scripts | q53_download_webpage_wget.sh |
| 54 | 01_shell_scripts | q54_download_webpage_wget_dup.sh |
| 55 | 01_shell_scripts | q55_list_users.sh |
| 56 | 08_misc_c_python | q56_py_recursive_primes.py |
| 57 | 08_misc_c_python | q57_pyramid_centered.c |
| 58 | 08_misc_c_python | q58_word_frequency_count.c |
| 59 | 01_shell_scripts | q59_top5_commands_history.sh |
| 60 | 01_shell_scripts | q60_check_remove_execute.sh |
| 61 | 01_shell_scripts | q61_word_frequency_wonderland.sh |
| 62 | 01_shell_scripts | q62_concatenate_files.sh |
| 63 | 01_shell_scripts | q63_lftp_download.sh |
| 64 | 04_semaphores | q64_sem_producer_consumer.c |
| 65 | 04_semaphores | q65_sem_reader_writer.c |
| 66 | 02_message_queue | q66_msgq_chat.c |
| 67 | 03_shared_memory | q67_shm_sender.c |
| 67 | 03_shared_memory | q67_shm_receiver.c |
| 68 | 03_shared_memory | q68_shm_file_writer.c |
| 68 | 03_shared_memory | q68_shm_file_reader.c |
| 69 | 03_shared_memory | q69_shm_three_process_sort.c |
| 70 | 03_shared_memory | q70_shm_create.c |
| 70 | 03_shared_memory | q70_shm_attach.c |
| 70 | 03_shared_memory | q70_shm_detach.c |
| 70 | 03_shared_memory | q70_shm_delete.c |
| 71 | 08_misc_c_python | q71_simulate_linux_commands.c |
| 72 | 04_semaphores | q72_sem_order_f1_before_f2.c |
| 73 | 02_message_queue | q73_msgq_dialog_process1.c |
| 73 | 02_message_queue | q73_msgq_dialog_process2.c |
| 74 | 02_message_queue | q73_msgq_dialog_process1.c (Hi? sent by Process 1) |
| 75 | 02_message_queue | q73_msgq_dialog_process2.c (Hello sent by Process 2) |
| 76 | 02_message_queue | q73_msgq_dialog_process1.c (I am fine sent by Process 1) |
| 77 | 05_sockets | q77_tcp_socket_demo_server.c |
| 77 | 05_sockets | q77_tcp_socket_demo_client.c |
| 78 | 05_sockets | q78_udp_socket_demo_server.c |
| 78 | 05_sockets | q78_udp_socket_demo_client.c |
| 79 | 05_sockets | q79_tcp_echo_server.c |
| 79 | 05_sockets | q79_tcp_echo_client.c |
| 80 | 05_sockets | q80_udp_echo_server.c |
| 80 | 05_sockets | q80_udp_echo_client.c |
| 81 | 06_pipes | q81_pipe_parent_to_child_data.c |
| 82 | 06_pipes | q82_pipe_send_file_parent_to_child.c |
| 83 | 06_pipes | q83_pipe_filter_upper_to_lower.c |
| 84 | 04_semaphores | q84_sem_fork_coordination.c |
| 85 | 04_semaphores | q85_sem_init_display.c |
| 85 | 04_semaphores | q85_sem_p_wait.c |
| 85 | 04_semaphores | q85_sem_v_signal.c |
| 86 | 07_file_locking | q86_lockf_demo.c |
| 87 | 07_file_locking | q87_flock_demo.c |

Tip: `find . -name 'q7*'` finds a question's files instantly.
Executables built by `build.sh` use the same names (in `./bin`).
