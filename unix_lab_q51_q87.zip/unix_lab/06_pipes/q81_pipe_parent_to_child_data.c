/*
 * PROBLEM STATEMENT (Q81)
 * Write a program using an unnamed pipe to send data from parent to child.
 */
/*
 * Q81 - Unnamed pipe: parent sends data, child receives it
 * Compile : gcc -Wall q81_pipe_parent_to_child_data.c -o q81_pipe_parent_to_child_data
 * Run     : ./q81_pipe_parent_to_child_data
 * Flow    : parent writes to fd[1] and closes it; child reads fd[0] until EOF.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(void)
{
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    const char *messages[] = {"first message", "second message", "third message"};

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {                                  /* CHILD: reader */
        close(fd[1]);                                /* not writing  */
        char buf[128];
        ssize_t n;
        while ((n = read(fd[0], buf, sizeof buf - 1)) > 0) {
            buf[n] = '\0';
            printf("Child received: %s\n", buf);
        }
        close(fd[0]);
        exit(0);
    }

    close(fd[0]);                                    /* PARENT: writer */
    for (int i = 0; i < 3; i++) {
        write(fd[1], messages[i], strlen(messages[i]));
        printf("Parent sent   : %s\n", messages[i]);
        sleep(1);
    }
    close(fd[1]);                                    /* EOF for the child */
    wait(NULL);
    return 0;
}
