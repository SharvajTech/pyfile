/*
 * PROBLEM STATEMENT (Q83)
 * Write a program using a pipe that acts as a filter to convert uppercase text to
 * lowercase (reading from a command or a file).
 */
/*
 * Q83 - Pipe filter: uppercase -> lowercase
 * Compile : gcc -Wall q83_pipe_filter_upper_to_lower.c -o q83_pipe_filter_upper_to_lower
 * Run     : ./q83_pipe_filter_upper_to_lower notes.txt         (read from a file)
 *           echo "HELLO WORLD" | ./q83_pipe_filter_upper_to_lower   (read from stdin)
 *           ls -l | ./q83_pipe_filter_upper_to_lower           (read from a command)
 * Flow    : parent reads the file/stdin and writes it into the pipe;
 *           child (the filter) reads the pipe, converts to lowercase, prints.
 */
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    FILE *in = stdin;
    if (argc > 1) {
        in = fopen(argv[1], "r");
        if (!in) { perror("fopen"); return 1; }
    }

    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {                                  /* CHILD = filter */
        close(fd[1]);
        char ch;
        while (read(fd[0], &ch, 1) == 1) {           /* read one byte at a time */
            putchar(tolower((unsigned char)ch));
        }
        fflush(stdout);
        close(fd[0]);
        exit(0);
    }

    close(fd[0]);                                    /* PARENT = producer */
    int c;
    while ((c = fgetc(in)) != EOF) {
        char ch = (char)c;
        write(fd[1], &ch, 1);
    }
    close(fd[1]);
    if (in != stdin) fclose(in);
    wait(NULL);
    return 0;
}
