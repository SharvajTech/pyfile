/*
 * PROBLEM STATEMENT (Q82)
 * Write a program using an unnamed pipe to send a file from parent to child.
 */
/*
 * Q82 - Unnamed pipe: parent sends a FILE's contents to the child
 * Compile : gcc -Wall q82_pipe_send_file_parent_to_child.c -o q82_pipe_send_file_parent_to_child
 * Run     : ./q82_pipe_send_file_parent_to_child input.txt [copy_name.txt]
 *           (child writes the received data to copy_name.txt, default received_copy.txt)
 * Check   : diff input.txt received_copy.txt   (no output = identical)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    if (argc < 2) { fprintf(stderr, "Usage: %s file [copy]\n", argv[0]); return 1; }
    const char *copy_name = (argc > 2) ? argv[2] : "received_copy.txt";

    FILE *src = fopen(argv[1], "rb");
    if (!src) { perror("fopen source"); return 1; }

    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {                                  /* CHILD: receive file data */
        close(fd[1]);
        FILE *dst = fopen(copy_name, "wb");
        if (!dst) { perror("fopen copy"); _exit(1); }
        char buf[512];
        ssize_t n, total = 0;
        while ((n = read(fd[0], buf, sizeof buf)) > 0) {
            fwrite(buf, 1, n, dst);
            total += n;
        }
        fclose(dst);
        close(fd[0]);
        printf("Child : received %zd bytes, saved to %s\n", total, copy_name);
        fflush(stdout);
        exit(0);
    }

    close(fd[0]);                                    /* PARENT: send file data */
    char buf[512];
    size_t n, total = 0;
    while ((n = fread(buf, 1, sizeof buf, src)) > 0) {
        write(fd[1], buf, n);
        total += n;
    }
    fclose(src);
    close(fd[1]);                                    /* EOF for child */
    printf("Parent: sent %zu bytes from %s\n", total, argv[1]);
    wait(NULL);
    return 0;
}
