/*
 * PROBLEM STATEMENT (Q65)
 * Implement the reader-writer problem using semaphores.
 */
/*
 * Q65 - Reader-writer with POSIX semaphores (readers share, writers exclusive)
 * Compile : gcc -Wall -pthread q65_sem_reader_writer.c -o q65_sem_reader_writer
 * Run     : ./q65_sem_reader_writer
 * Logic   : rw   = lock for writers and for the first/last reader,
 *           mutex protects readcount. Many readers can read together; a writer
 *           needs the whole database to itself.
 */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NREADERS 3
#define NWRITERS 2
#define OPS      3

static int shared_value = 0;       /* the "database" */
static int readcount = 0;
static sem_t rw, mutex;

static void *reader(void *arg)
{
    long id = (long)arg;
    for (int k = 0; k < OPS; k++) {
        sem_wait(&mutex);
        readcount++;
        if (readcount == 1) sem_wait(&rw);     /* first reader locks writers out */
        sem_post(&mutex);

        printf("Reader %ld reads value %d\n", id, shared_value);
        usleep(200000);

        sem_wait(&mutex);
        readcount--;
        if (readcount == 0) sem_post(&rw);     /* last reader lets writers in   */
        sem_post(&mutex);
        usleep(150000);
    }
    return NULL;
}

static void *writer(void *arg)
{
    long id = (long)arg;
    for (int k = 0; k < OPS; k++) {
        sem_wait(&rw);
        shared_value += 10;
        printf("        Writer %ld writes, value now %d\n", id, shared_value);
        usleep(300000);
        sem_post(&rw);
        usleep(250000);
    }
    return NULL;
}

int main(void)
{
    pthread_t r[NREADERS], w[NWRITERS];
    sem_init(&rw, 0, 1);
    sem_init(&mutex, 0, 1);

    for (long i = 0; i < NREADERS; i++) pthread_create(&r[i], NULL, reader, (void *)(i + 1));
    for (long i = 0; i < NWRITERS; i++) pthread_create(&w[i], NULL, writer, (void *)(i + 1));

    for (int i = 0; i < NREADERS; i++) pthread_join(r[i], NULL);
    for (int i = 0; i < NWRITERS; i++) pthread_join(w[i], NULL);

    sem_destroy(&rw);
    sem_destroy(&mutex);
    return 0;
}
