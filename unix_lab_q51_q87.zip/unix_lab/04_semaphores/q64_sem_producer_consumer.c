/*
 * PROBLEM STATEMENT (Q64)
 * Implement the producer-consumer problem using semaphores (semaphore.h) in C or Java.
 */
/*
 * Q64 - Producer-consumer with POSIX semaphores (semaphore.h), threads
 * Compile : gcc -Wall -pthread q64_sem_producer_consumer.c -o q64_sem_producer_consumer
 * Run     : ./q64_sem_producer_consumer
 * Logic   : empty = free slots (starts at BUF), full = filled slots (starts at 0),
 *           mutex protects the buffer indexes. Producer waits on empty, consumer on full.
 */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUF_SIZE 5
#define ITEMS    10

static int buffer[BUF_SIZE];
static int in = 0, out = 0;
static sem_t empty, full, mutex;

static void *producer(void *arg)
{
    (void)arg;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&empty);                 /* wait for a free slot   */
        sem_wait(&mutex);
        buffer[in] = i;
        in = (in + 1) % BUF_SIZE;
        printf("Producer produced %2d\n", i);
        sem_post(&mutex);
        sem_post(&full);                  /* one more filled slot   */
        usleep(100000);
    }
    return NULL;
}

static void *consumer(void *arg)
{
    (void)arg;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&full);                  /* wait for an item       */
        sem_wait(&mutex);
        int item = buffer[out];
        out = (out + 1) % BUF_SIZE;
        printf("Consumer consumed %2d\n", item);
        sem_post(&mutex);
        sem_post(&empty);                 /* one more free slot     */
        usleep(250000);
    }
    return NULL;
}

int main(void)
{
    pthread_t p, c;
    sem_init(&empty, 0, BUF_SIZE);
    sem_init(&full, 0, 0);
    sem_init(&mutex, 0, 1);

    pthread_create(&p, NULL, producer, NULL);
    pthread_create(&c, NULL, consumer, NULL);
    pthread_join(p, NULL);
    pthread_join(c, NULL);

    sem_destroy(&empty);
    sem_destroy(&full);
    sem_destroy(&mutex);
    return 0;
}
