/*
 * PROBLEM STATEMENT (Q85)
 * Create three separate programs: (1) initialize a semaphore and display its ID,
 * (2) perform the P (wait) operation and print a message, (3) perform the V (signal)
 * operation and print a message - all operating on the same semaphore.
 */
/*
 * Q85 - Program 3 of 3: V (signal) operation (q85_sem_v_signal.c)
 * Compile : gcc -Wall q85_sem_v_signal.c -o q85_sem_v_signal
 * Run     : ./q85_sem_v_signal
 * Check   : ipcs -s     (shows the semaphore and its ID)
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int main(void)
{
    key_t key = ftok(".", 'Z');
    if (key == -1) { perror("ftok"); return 1; }

    int semid = semget(key, 1, 0666);          /* do not create */
    if (semid == -1) { perror("semget (run q85_sem_init_display first)"); return 1; }

    setvbuf(stdout, NULL, _IONBF, 0);
    struct sembuf V = {0, +1, 0};
    if (semop(semid, &V, 1) == -1) { perror("semop V"); return 1; }
    printf("V: signalled semaphore %d. value now = %d\n",
           semid, semctl(semid, 0, GETVAL));
    fflush(stdout);
    return 0;
}
