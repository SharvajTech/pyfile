/*
 * PROBLEM STATEMENT (Q72)
 * Write a program using semaphores to ensure function f1() executes before f2()
 * (example: prompt for username before prompting for password).
 */
/*
 * Q72 - f1() always finishes before f2(), using a System V semaphore
 * Compile : gcc -Wall q72_sem_order_f1_before_f2.c -o q72_sem_order_f1_before_f2
 * Run     : ./q72_sem_order_f1_before_f2   (type username, Enter, then password, Enter)
 * Logic   : semaphore starts at 0. Child runs f2 but must P() first (blocks until 0 -> 1).
 *           Parent runs f1, then V() to release the child. Result: f1 always comes first.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/mman.h>

union semun { int val; struct semid_ds *buf; unsigned short *array; };

static void f1(char *user)
{
    printf("f1: enter username: ");
    fflush(stdout);
    if (scanf("%31s", user) != 1) strcpy(user, "unknown");
    printf("f1: got username '%s'\n", user);
    fflush(stdout);
}

static void f2(const char *user)
{
    printf("f2: enter password for %s: ", user);
    fflush(stdout);
    char pw[64];
    if (scanf("%63s", pw) == 1) printf("f2: password received (%zu chars)\n", strlen(pw));
}

int main(void)
{
    int semid = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (semid == -1) { perror("semget"); return 1; }

    union semun arg; arg.val = 0;
    semctl(semid, 0, SETVAL, arg);

    struct sembuf P = {0, -1, 0};     /* wait: block until value > 0 */
    struct sembuf V = {0, +1, 0};     /* signal: value + 1           */

    /* username lives in shared memory so the child sees what f1() stored */
    char *user = mmap(NULL, 32, PROT_READ | PROT_WRITE,
                      MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (user == MAP_FAILED) { perror("mmap"); return 1; }
    user[0] = '\0';

    fflush(stdout);                   /* avoid duplicated buffered output after fork */
    pid_t pid = fork();
    if (pid == 0) {                   /* child: f2 */
        semop(semid, &P, 1);          /* blocks until f1 has finished */
        f2(user);
        exit(0);
    }

    f1(user);                         /* parent: f1 */
    semop(semid, &V, 1);              /* release f2 */

    waitpid(pid, NULL, 0);
    semctl(semid, 0, IPC_RMID);
    munmap(user, 32);
    return 0;
}
