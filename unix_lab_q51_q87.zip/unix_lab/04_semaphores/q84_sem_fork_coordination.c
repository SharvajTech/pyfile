/*
 * PROBLEM STATEMENT (Q84)
 * Illustrate semaphore usage with fork() so two processes run simultaneously and
 * coordinate via semaphores; include a short note on differences between sem.h and
 * semaphore.h.
 */
/*
 * Q84 - Two processes (fork) coordinating with a System V semaphore
 * Compile : gcc -Wall q84_sem_fork_coordination.c -o q84_sem_fork_coordination
 * Run     : ./q84_sem_fork_coordination
 *
 * NOTE: sem.h vs semaphore.h
 *   <sys/sem.h>  (System V) : semget/semop/semctl. Works on sets of semaphores, identified
 *                             by a key or IPC_PRIVATE, lives until IPC_RMID (kernel object).
 *                             Used here.
 *   <semaphore.h> (POSIX)   : sem_init/sem_wait/sem_post or sem_open for a named semaphore.
 *                             Simpler API, one semaphore per object. Unnamed = needs shared
 *                             memory/threads; named = visible in /dev/shm. Used in Q64, Q65.
 *
 * Logic   : parent and child both loop; a single binary semaphore lets only one of them
 *           print its line at a time, but both are running (fork gives two processes).
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>

union semun { int val; struct semid_ds *buf; unsigned short *array; };

static void do_work(int semid, const char *who)
{
    struct sembuf P = {0, -1, 0}, V = {0, +1, 0};
    for (int i = 1; i <= 3; i++) {
        semop(semid, &P, 1);                       /* enter critical section */
        printf("%s: step %d (in critical section)\n", who, i);
        fflush(stdout);
        sleep(1);
        printf("%s: step %d done, leaving\n", who, i);
        fflush(stdout);
        semop(semid, &V, 1);                       /* leave critical section */
        usleep(100000);
    }
}

int main(void)
{
    int semid = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (semid == -1) { perror("semget"); return 1; }

    union semun arg; arg.val = 1;                 /* binary semaphore */
    semctl(semid, 0, SETVAL, arg);

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }
    if (pid == 0) { do_work(semid, "CHILD "); exit(0); }

    do_work(semid, "PARENT");
    waitpid(pid, NULL, 0);
    semctl(semid, 0, IPC_RMID);
    printf("Both processes finished.\n");
    return 0;
}
