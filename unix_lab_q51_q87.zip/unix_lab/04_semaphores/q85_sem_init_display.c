/*
 * PROBLEM STATEMENT (Q85)
 * Create three separate programs: (1) initialize a semaphore and display its ID,
 * (2) perform the P (wait) operation and print a message, (3) perform the V (signal)
 * operation and print a message - all operating on the same semaphore.
 */
/*
 * Q85 - Program 1 of 3: INITIALIZE the semaphore and show its ID (q85_sem_init_display.c)
 * Compile : gcc -Wall q85_sem_init_display.c -o q85_sem_init_display
 * Run     : ./q85_sem_init_display [initial_value]     (default 1)
 *           use 0 to make the next P() block until a V() happens.
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>

union semun { int val; struct semid_ds *buf; unsigned short *array; };

int main(int argc, char *argv[])
{
    int initial = (argc > 1) ? atoi(argv[1]) : 1;

    key_t key = ftok(".", 'Z');
    if (key == -1) { perror("ftok"); return 1; }

    int semid = semget(key, 1, IPC_CREAT | 0666);
    if (semid == -1) { perror("semget"); return 1; }

    union semun arg; arg.val = initial;
    if (semctl(semid, 0, SETVAL, arg) == -1) { perror("semctl SETVAL"); return 1; }

    printf("Semaphore initialized. Semaphore ID = %d, value = %d\n",
           semid, semctl(semid, 0, GETVAL));
    return 0;
}
