/*
 * PROBLEM STATEMENT (Q85)
 * Create three separate programs: (1) initialize a semaphore and display its ID,
 * (2) perform the P (wait) operation and print a message, (3) perform the V (signal)
 * operation and print a message - all operating on the same semaphore.
 */
/*
 * Q85 - Program 2 of 3: P (wait) operation (q85_sem_p_wait.c)
 * Compile : gcc -Wall q85_sem_p_wait.c -o q85_sem_p_wait
 * Run     : ./q85_sem_p_wait       (after q85_sem_init_display)
 * Note    : if the value is 0 this blocks until q85_sem_v_signal is run in another terminal.
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int main(void)
{
    key_t key = ftok(".", 'Z');
    if (key == -1) { perror("ftok"); return 1; }

    int semid = semget(key, 1, 0666);          /* do not create */
    if (semid == -1) { perror("semget (run q85_sem_init_display first)"); return 1; }

    struct sembuf P = {0, -1, 0};
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("P: waiting on semaphore %d (value before = %d)...\n",
           semid, semctl(semid, 0, GETVAL));
    if (semop(semid, &P, 1) == -1) { perror("semop P"); return 1; }
    printf("P: acquired. value now = %d\n", semctl(semid, 0, GETVAL));
    fflush(stdout);
    return 0;
}
