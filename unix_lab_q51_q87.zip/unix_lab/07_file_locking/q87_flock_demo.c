/*
 * PROBLEM STATEMENT (Q87)
 * Write a program to demonstrate file locking using flock().
 */
/*
 * Q87 - File locking with flock() (BSD-style lock, per open file)
 * Compile : gcc -Wall q87_flock_demo.c -o q87_flock_demo
 * Run     : ./q87_flock_demo
 * Flow    : parent takes an EXCLUSIVE lock (LOCK_EX), writes, holds 5 s, releases.
 *           child tries LOCK_EX|LOCK_NB (refused), then LOCK_EX (blocks) until released.
 * Note    : flock() locks belong to the open file description; lockf() locks belong
 *           to the process. Each side here opens the file itself.
 */
#include <stdio.h>
#include <fcntl.h>
#include <sys/file.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

#define FILENAME "flock_shared.txt"

int main(void)
{
    int fd = open(FILENAME, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) { perror("open"); return 1; }
    close(fd);

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {                                  /* CHILD */
        sleep(1);
        int cfd = open(FILENAME, O_RDWR);
        if (cfd == -1) { perror("child open"); _exit(1); }

        if (flock(cfd, LOCK_EX | LOCK_NB) == -1 && errno == EWOULDBLOCK)
            printf("CHILD : lock busy (LOCK_NB refused)\n");

        time_t t0 = time(NULL);
        printf("CHILD : waiting for exclusive lock (blocking)...\n");
        fflush(stdout);
        flock(cfd, LOCK_EX);                         /* blocks until parent releases */
        printf("CHILD : got the lock after %ld s\n", (long)(time(NULL) - t0));

        lseek(cfd, 0, SEEK_END);
        write(cfd, "child line\n", 11);
        flock(cfd, LOCK_UN);
        close(cfd);
        exit(0);
    }

    /* PARENT */
    int pfd = open(FILENAME, O_RDWR);
    if (pfd == -1) { perror("parent open"); return 1; }
    flock(pfd, LOCK_EX);
    printf("PARENT: exclusive lock held, writing for 5 s...\n");
    fflush(stdout);
    lseek(pfd, 0, SEEK_END);
    write(pfd, "parent line\n", 12);
    sleep(5);
    flock(pfd, LOCK_UN);
    printf("PARENT: released the lock\n");
    fflush(stdout);
    close(pfd);

    waitpid(pid, NULL, 0);
    printf("Final contents of %s:\n", FILENAME);
    fflush(stdout);
    execlp("cat", "cat", FILENAME, (char *)NULL);
    return 0;
}
