/*
 * PROBLEM STATEMENT (Q86)
 * Write a program to demonstrate file locking using lockf().
 */
/*
 * Q86 - File locking with lockf() (POSIX record locks, per process)
 * Compile : gcc -Wall q86_lockf_demo.c -o q86_lockf_demo
 * Run     : ./q86_lockf_demo
 * Flow    : parent LOCKS the file, writes, holds the lock 5 s, then UNLOCKS.
 *           child tries F_TLOCK (non-blocking) -> "busy", then F_LOCK (blocks)
 *           until the parent unlocks, then writes its own line.
 */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

#define FILENAME "lockf_shared.txt"

int main(void)
{
    /* create/clear the file first */
    int fd = open(FILENAME, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) { perror("open"); return 1; }
    close(fd);

    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) { perror("fork"); return 1; }

    if (pid == 0) {                                  /* CHILD: competing writer */
        sleep(1);                                    /* let parent lock first */
        int cfd = open(FILENAME, O_RDWR);
        if (cfd == -1) { perror("child open"); _exit(1); }

        if (lockf(cfd, F_TLOCK, 0) == -1 && (errno == EAGAIN || errno == EACCES))
            printf("CHILD : file is locked by parent (F_TLOCK refused)\n");

        time_t t0 = time(NULL);
        printf("CHILD : waiting for lock (F_LOCK blocks)...\n");
        fflush(stdout);
        lockf(cfd, F_LOCK, 0);                       /* blocks until parent unlocks */
        printf("CHILD : got the lock after %ld s\n", (long)(time(NULL) - t0));

        lseek(cfd, 0, SEEK_END);
        write(cfd, "child line\n", 11);
        lockf(cfd, F_ULOCK, 0);
        close(cfd);
        exit(0);
    }

    /* PARENT */
    int pfd = open(FILENAME, O_RDWR);
    if (pfd == -1) { perror("parent open"); return 1; }
    lockf(pfd, F_LOCK, 0);                           /* lock the whole file */
    printf("PARENT: locked the file, writing for 5 s...\n");
    fflush(stdout);
    lseek(pfd, 0, SEEK_END);
    write(pfd, "parent line\n", 12);
    sleep(5);
    lockf(pfd, F_ULOCK, 0);                          /* release */
    printf("PARENT: unlocked the file\n");
    fflush(stdout);
    close(pfd);

    waitpid(pid, NULL, 0);
    printf("Final contents of %s:\n", FILENAME);
    fflush(stdout);
    execlp("cat", "cat", FILENAME, (char *)NULL);
    return 0;
}
