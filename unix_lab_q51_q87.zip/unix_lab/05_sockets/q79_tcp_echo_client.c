/*
 * PROBLEM STATEMENT (Q79)
 * Implement an echo server over TCP using iterative and/or concurrent logic.
 */
/*
 * Q79 - TCP echo client (pairs with q79_tcp_echo_server.c)
 * Compile : gcc -Wall q79_tcp_echo_client.c -o q79_tcp_echo_client
 * Run     : ./q79_tcp_echo_client      then type lines; each one is echoed back.
 *           Ctrl+D to quit.
 * Tip     : open 2-3 clients at once with the 'concurrent' server to see it serve them together.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9079

int main(void)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv = {0};
    serv.sin_family = AF_INET;
    serv.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);
    if (connect(sockfd, (struct sockaddr *)&serv, sizeof serv) == -1) {
        perror("connect (is the server running?)"); return 1;
    }

    char line[512], reply[512];
    while (fgets(line, sizeof line, stdin)) {
        send(sockfd, line, strlen(line), 0);
        ssize_t n = recv(sockfd, reply, sizeof reply - 1, 0);
        if (n <= 0) break;
        reply[n] = '\0';
        printf("echo: %s", reply);
    }
    close(sockfd);
    return 0;
}
