/*
 * PROBLEM STATEMENT (Q77)
 * Implement a TCP program demonstrating socket system calls in C or Python.
 */
/*
 * Q77 - TCP socket demo: CLIENT (pairs with q77_tcp_socket_demo_server.c)
 * Compile : gcc -Wall q77_tcp_socket_demo_client.c -o q77_tcp_socket_demo_client
 * Run     : start the server first, then ./q77_tcp_socket_demo_client
 * Calls   : socket -> connect -> send -> recv -> close
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9077

int main(void)
{
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);               /* 1. socket  */
    if (sockfd == -1) { perror("socket"); return 1; }

    struct sockaddr_in serv = {0};
    serv.sin_family = AF_INET;
    serv.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    if (connect(sockfd, (struct sockaddr *)&serv, sizeof serv) == -1) {  /* 2. connect */
        perror("connect (is the server running?)");
        return 1;
    }
    printf("connect()  -> connected to 127.0.0.1:%d\n", PORT);

    const char *msg = "Hello server";
    send(sockfd, msg, strlen(msg), 0);                           /* 3. send    */
    printf("send()     -> \"%s\"\n", msg);

    char buf[256] = {0};
    ssize_t n = recv(sockfd, buf, sizeof buf - 1, 0);            /* 4. recv    */
    printf("recv()     -> %zd bytes: \"%s\"\n", n, buf);

    close(sockfd);                                               /* 5. close   */
    return 0;
}
