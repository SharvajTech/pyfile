/*
 * PROBLEM STATEMENT (Q79)
 * Implement an echo server over TCP using iterative and/or concurrent logic.
 */
/*
 * Q79 - TCP echo server, iterative OR concurrent (pairs with q79_tcp_echo_client.c)
 * Compile : gcc -Wall q79_tcp_echo_server.c -o q79_tcp_echo_server
 * Run     : ./q79_tcp_echo_server iterative     (one client at a time)
 *           ./q79_tcp_echo_server concurrent    (fork() a child per client)
 * Port    : 9079
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9079

static void serve_client(int connfd)
{
    char buf[512];
    ssize_t n;
    while ((n = recv(connfd, buf, sizeof buf, 0)) > 0)
        send(connfd, buf, n, 0);                 /* echo back exactly what came in */
    close(connfd);
}

int main(int argc, char *argv[])
{
    int concurrent = (argc > 1 && strcmp(argv[1], "concurrent") == 0);

    int listenfd = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(PORT);
    if (bind(listenfd, (struct sockaddr *)&addr, sizeof addr) == -1) { perror("bind"); return 1; }
    listen(listenfd, 5);

    if (concurrent) signal(SIGCHLD, SIG_IGN);    /* auto-reap finished children */
    printf("Echo server (%s) listening on port %d\n",
           concurrent ? "concurrent" : "iterative", PORT);

    for (;;) {
        int connfd = accept(listenfd, NULL, NULL);
        if (connfd == -1) continue;

        if (!concurrent) {                       /* ITERATIVE: serve, then next client */
            serve_client(connfd);
        } else {                                 /* CONCURRENT: child serves, parent loops */
            pid_t pid = fork();
            if (pid == 0) {
                close(listenfd);
                serve_client(connfd);
                _exit(0);
            }
            close(connfd);
        }
    }
}
