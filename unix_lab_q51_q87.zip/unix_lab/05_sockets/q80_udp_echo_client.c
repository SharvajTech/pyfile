/*
 * PROBLEM STATEMENT (Q80)
 * Implement an echo server over UDP using iterative and/or concurrent logic.
 */
/*
 * Q80 - UDP echo client (pairs with q80_udp_echo_server.c)
 * Compile : gcc -Wall q80_udp_echo_client.c -o q80_udp_echo_client
 * Run     : ./q80_udp_echo_client      then type lines; each is echoed back. Ctrl+D quits.
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9080

int main(void)
{
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in serv = {0};
    serv.sin_family = AF_INET;
    serv.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    char line[512], reply[512];
    while (fgets(line, sizeof line, stdin)) {
        sendto(sockfd, line, strlen(line), 0, (struct sockaddr *)&serv, sizeof serv);
        ssize_t n = recvfrom(sockfd, reply, sizeof reply - 1, 0, NULL, NULL);
        if (n < 0) break;
        reply[n] = '\0';
        printf("echo: %s", reply);
    }
    close(sockfd);
    return 0;
}
