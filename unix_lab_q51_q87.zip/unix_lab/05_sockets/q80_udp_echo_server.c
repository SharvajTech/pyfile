/*
 * PROBLEM STATEMENT (Q80)
 * Implement an echo server over UDP using iterative and/or concurrent logic.
 */
/*
 * Q80 - UDP echo server, iterative OR concurrent (pairs with q80_udp_echo_client.c)
 * Compile : gcc -Wall q80_udp_echo_server.c -o q80_udp_echo_server
 * Run     : ./q80_udp_echo_server iterative     (handle each datagram in the main loop)
 *           ./q80_udp_echo_server concurrent    (fork() a child per datagram)
 * Port    : 9080
 * Note    : UDP has no connection, so there is no accept(); recvfrom() gives the sender.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9080

static void echo_to(int sockfd, const char *data, ssize_t len,
                    struct sockaddr_in *cli, socklen_t clen)
{
    sendto(sockfd, data, len, 0, (struct sockaddr *)cli, clen);
}

int main(int argc, char *argv[])
{
    int concurrent = (argc > 1 && strcmp(argv[1], "concurrent") == 0);

    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(PORT);
    if (bind(sockfd, (struct sockaddr *)&addr, sizeof addr) == -1) { perror("bind"); return 1; }

    if (concurrent) signal(SIGCHLD, SIG_IGN);
    printf("UDP echo server (%s) on port %d\n",
           concurrent ? "concurrent" : "iterative", PORT);

    char buf[512];
    for (;;) {
        struct sockaddr_in cli; socklen_t clen = sizeof cli;
        ssize_t n = recvfrom(sockfd, buf, sizeof buf, 0, (struct sockaddr *)&cli, &clen);
        if (n < 0) continue;

        if (!concurrent) {                       /* ITERATIVE */
            echo_to(sockfd, buf, n, &cli, clen);
        } else {                                 /* CONCURRENT: child echoes this datagram */
            pid_t pid = fork();
            if (pid == 0) {
                echo_to(sockfd, buf, n, &cli, clen);
                _exit(0);
            }
        }
    }
}
