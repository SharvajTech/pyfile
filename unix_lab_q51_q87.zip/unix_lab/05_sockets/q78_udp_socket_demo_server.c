/*
 * PROBLEM STATEMENT (Q78)
 * Implement a UDP program demonstrating socket system calls in C or Python.
 */
/*
 * Q78 - UDP socket demo: SERVER (pairs with q78_udp_socket_demo_client.c)
 * Compile : gcc -Wall q78_udp_socket_demo_server.c -o q78_udp_socket_demo_server
 * Run     : ./q78_udp_socket_demo_server     (start first; port 9078)
 *           ./q78_udp_socket_demo_client     (in another terminal)
 * Calls   : socket -> bind -> recvfrom -> sendto -> close   (no listen/accept: UDP is connectionless)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9078

int main(void)
{
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);                /* 1. socket  */
    if (sockfd == -1) { perror("socket"); return 1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(PORT);
    if (bind(sockfd, (struct sockaddr *)&addr, sizeof addr) == -1) { perror("bind"); return 1; }
    printf("bind()     -> UDP port %d, waiting for datagrams...\n", PORT);

    char buf[256] = {0};
    struct sockaddr_in cli; socklen_t clen = sizeof cli;
    ssize_t n = recvfrom(sockfd, buf, sizeof buf - 1, 0,        /* 2. recvfrom */
                         (struct sockaddr *)&cli, &clen);
    printf("recvfrom() -> %zd bytes from %s:%d: \"%s\"\n", n,
           inet_ntoa(cli.sin_addr), ntohs(cli.sin_port), buf);

    const char *reply = "Hello from UDP server";
    sendto(sockfd, reply, strlen(reply), 0,                     /* 3. sendto  */
           (struct sockaddr *)&cli, clen);
    printf("sendto()   -> reply sent\n");

    close(sockfd);                                              /* 4. close   */
    return 0;
}
