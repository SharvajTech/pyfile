/*
 * PROBLEM STATEMENT (Q78)
 * Implement a UDP program demonstrating socket system calls in C or Python.
 */
/*
 * Q78 - UDP socket demo: CLIENT (pairs with q78_udp_socket_demo_server.c)
 * Compile : gcc -Wall q78_udp_socket_demo_client.c -o q78_udp_socket_demo_client
 * Run     : start the server first, then ./q78_udp_socket_demo_client
 * Calls   : socket -> sendto -> recvfrom -> close
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9078

int main(void)
{
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);                /* 1. socket  */
    if (sockfd == -1) { perror("socket"); return 1; }

    struct sockaddr_in serv = {0};
    serv.sin_family = AF_INET;
    serv.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    const char *msg = "Hello UDP";
    sendto(sockfd, msg, strlen(msg), 0,                         /* 2. sendto  */
           (struct sockaddr *)&serv, sizeof serv);
    printf("sendto()   -> \"%s\"\n", msg);

    char buf[256] = {0};
    struct sockaddr_in from; socklen_t flen = sizeof from;
    ssize_t n = recvfrom(sockfd, buf, sizeof buf - 1, 0,        /* 3. recvfrom */
                         (struct sockaddr *)&from, &flen);
    printf("recvfrom() -> %zd bytes: \"%s\"\n", n, buf);

    close(sockfd);                                              /* 4. close   */
    return 0;
}
