/*
 * PROBLEM STATEMENT (Q77)
 * Implement a TCP program demonstrating socket system calls in C or Python.
 */
/*
 * Q77 - TCP socket demo: SERVER (pairs with q77_tcp_socket_demo_client.c)
 * Compile : gcc -Wall q77_tcp_socket_demo_server.c -o q77_tcp_socket_demo_server
 * Run     : ./q77_tcp_socket_demo_server       (start first; listens on port 9077)
 *           ./q77_tcp_socket_demo_client       (in another terminal)
 * Calls   : socket -> setsockopt -> bind -> listen -> accept -> recv -> send -> close
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 9077

int main(void)
{
    int listenfd = socket(AF_INET, SOCK_STREAM, 0);             /* 1. socket  */
    if (listenfd == -1) { perror("socket"); return 1; }
    printf("socket()   -> fd %d\n", listenfd);

    int yes = 1;                                                /* 2. setsockopt */
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(PORT);
    if (bind(listenfd, (struct sockaddr *)&addr, sizeof addr) == -1) { perror("bind"); return 1; }
    printf("bind()     -> port %d\n", PORT);                    /* 3. bind    */

    if (listen(listenfd, 5) == -1) { perror("listen"); return 1; }  /* 4. listen  */
    printf("listen()   -> waiting for a client...\n");

    struct sockaddr_in peer; socklen_t plen = sizeof peer;
    int connfd = accept(listenfd, (struct sockaddr *)&peer, &plen);  /* 5. accept */
    if (connfd == -1) { perror("accept"); return 1; }
    printf("accept()   -> client %s:%d\n", inet_ntoa(peer.sin_addr), ntohs(peer.sin_port));

    char buf[256] = {0};
    ssize_t n = recv(connfd, buf, sizeof buf - 1, 0);            /* 6. recv    */
    printf("recv()     -> %zd bytes: \"%s\"\n", n, buf);

    const char *reply = "Hello from server";
    send(connfd, reply, strlen(reply), 0);                       /* 7. send    */
    printf("send()     -> reply sent\n");

    close(connfd);                                               /* 8. close   */
    close(listenfd);
    return 0;
}
