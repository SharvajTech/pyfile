#!/bin/bash
# Compile every C program into ./bin  (usage: ./build.sh)
# Needs: gcc (all C), -pthread (semaphore.h programs Q64/Q65), python3 (Q56 runs directly).
# Shell scripts (01_shell_scripts) only need chmod +x - they are not compiled.
mkdir -p bin
ok=0; bad=0
build() {   # build <flags> <file>
    out="bin/$(basename "${2%.c}")"
    if gcc $1 "$2" -o "$out" 2>/tmp/build_err.txt; then ok=$((ok+1)); else bad=$((bad+1)); echo "FAILED: $2"; cat /tmp/build_err.txt; fi
}
for f in 02_message_queue/*.c 06_pipes/*.c 07_file_locking/*.c 08_misc_c_python/*.c 05_sockets/*.c; do build "-Wall" "$f"; done
for f in 03_shared_memory/*.c; do build "-Wall" "$f"; done
for f in 04_semaphores/*.c; do build "-Wall -pthread" "$f"; done
chmod +x 01_shell_scripts/*.sh
echo "Built OK: $ok   Failed: $bad   -> executables are in ./bin"
echo "Shell scripts ready in 01_shell_scripts/ ; Python: python3 08_misc_c_python/q56_py_recursive_primes.py 50"
