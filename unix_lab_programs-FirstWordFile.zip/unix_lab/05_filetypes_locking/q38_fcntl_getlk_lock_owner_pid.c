/*
 * PROBLEM STATEMENT
 * Q38. Use fcntl() with F_GETLK to find out which process ID is holding a
 *     lock on a file.
 *
 * Q38: Use fcntl() with F_GETLK to find which process holds a lock.
 *
 * Compile : gcc q38_fcntl_getlk_lock_owner_pid.c -o q38_fcntl_getlk_lock_owner_pid
 * Run     : Terminal 1: ./q38_fcntl_getlk_lock_owner_pid hold      (write-locks the whole file, 30 s)
 *           Terminal 2: ./q38_fcntl_getlk_lock_owner_pid query     (prints the PID of the lock owner)
 * Check   : the PID printed by "query" equals the PID printed by "hold".
 *
 * F_GETLK does not set a lock. It asks "would this lock be blocked?". If a
 * conflicting lock exists, l_type/l_pid/l_start/l_len are filled in with the
 * blocking lock; otherwise l_type is set to F_UNLCK.
 */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2 || (strcmp(argv[1], "hold") && strcmp(argv[1], "query"))) {
        fprintf(stderr, "Usage: %s hold|query\n", argv[0]);
        return 1;
    }
    int fd = open("q38_lockfile.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) { perror("open"); return 1; }

    struct flock fl;
    memset(&fl, 0, sizeof fl);
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;                           /* 0 = until end of file */

    if (strcmp(argv[1], "hold") == 0) {
        fl.l_type = F_WRLCK;
        if (fcntl(fd, F_SETLK, &fl) == -1) {
            perror("fcntl F_SETLK");
            return 1;
        }
        printf("Lock holder PID = %d (holding write lock for 30 s)\n", (int)getpid());
        fflush(stdout);
        sleep(30);
        return 0;
    }

    fl.l_type = F_WRLCK;                    /* test: could we get a write lock? */
    if (fcntl(fd, F_GETLK, &fl) == -1) {
        perror("fcntl F_GETLK");
        return 1;
    }
    if (fl.l_type == F_UNLCK)
        printf("File is not locked.\n");
    else
        printf("File is locked by PID %d (%s lock, start=%lld, len=%lld)\n",
               (int)fl.l_pid, fl.l_type == F_WRLCK ? "write" : "read",
               (long long)fl.l_start, (long long)fl.l_len);
    return 0;
}
