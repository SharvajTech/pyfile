/*
 * PROBLEM STATEMENT
 * Q35. Use lockf() so that two instances of a program append to the same
 *     file one after the other. Use F_TLOCK so the second instance prints
 *     "locked by another process" if the file is busy.
 *
 * Q35: lockf() so two instances append to the same file one after the other.
 *      F_TLOCK: the second instance prints "locked by another process" if the
 *      file is busy.
 *
 * Compile : gcc q35_lockf_ftlock_append.c -o q35_lockf_ftlock_append
 * Run     : Terminal 1: ./q35_lockf_ftlock_append A
 *           Terminal 2: ./q35_lockf_ftlock_append B          (within 6 s -> "locked by another process")
 *           Or in one terminal:  ./q35_lockf_ftlock_append A & ./q35_lockf_ftlock_append B
 *           ./q35_lockf_ftlock_append B wait                 (uses F_LOCK: waits for the lock instead)
 * Check   : cat q35_shared.txt
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    const char *tag = (argc > 1) ? argv[1] : "X";
    int wait_mode = (argc > 2 && strcmp(argv[2], "wait") == 0);

    int fd = open("q35_shared.txt", O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd == -1) { perror("open"); return 1; }

    if (lockf(fd, wait_mode ? F_LOCK : F_TLOCK, 0) == -1) {
        if (errno == EACCES || errno == EAGAIN) {
            printf("[%s] locked by another process\n", tag);
            close(fd);
            return 1;
        }
        perror("lockf");
        return 1;
    }
    printf("[%s] PID %d got the lock, appending...\n", tag, (int)getpid());

    for (int i = 1; i <= 3; i++) {
        char line[128];
        int n = snprintf(line, sizeof line, "[%s] PID %d line %d\n", tag, (int)getpid(), i);
        write(fd, line, (size_t)n);
        sleep(2);                           /* hold the lock for ~6 s in total */
    }

    lseek(fd, 0, SEEK_SET);                 /* unlock the region locked from offset 0 */
    lockf(fd, F_ULOCK, 0);
    printf("[%s] lock released\n", tag);
    close(fd);
    return 0;
}
