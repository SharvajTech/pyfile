/*
 * PROBLEM STATEMENT
 * Q36. Using fcntl() with struct flock, lock bytes 0 to 49 of a file in one
 *     process. In a second process show that locking bytes 50 to 99 succeeds
 *     and locking bytes 0 to 10 fails.
 *
 * Q36: Record locking with fcntl() and struct flock.
 *      Process 1 locks bytes 0..49. Process 2 shows that locking bytes 50..99
 *      succeeds and locking bytes 0..10 fails.
 *
 * Compile : gcc q36_fcntl_byte_range_locks.c -o q36_fcntl_byte_range_locks
 * Run     : Terminal 1: ./q36_fcntl_byte_range_locks hold     (locks 0-49 for 30 s)
 *           Terminal 2: ./q36_fcntl_byte_range_locks test     (tries 50-99, then 0-10)
 * Expected in terminal 2:
 *           lock bytes 50-99 : SUCCESS
 *           lock bytes 0-10  : FAILED (Resource temporarily unavailable / Permission denied)
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define FILE_NAME "q36_lockfile.dat"

static int lock_range(int fd, off_t start, off_t len)
{
    struct flock fl;
    memset(&fl, 0, sizeof fl);
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = start;
    fl.l_len = len;                         /* bytes start .. start+len-1 */
    return fcntl(fd, F_SETLK, &fl);         /* F_SETLK = do not wait */
}

int main(int argc, char *argv[])
{
    if (argc != 2 || (strcmp(argv[1], "hold") && strcmp(argv[1], "test"))) {
        fprintf(stderr, "Usage: %s hold|test\n", argv[0]);
        return 1;
    }
    int fd = open(FILE_NAME, O_RDWR | O_CREAT, 0644);
    if (fd == -1) { perror("open"); return 1; }

    if (strcmp(argv[1], "hold") == 0) {
        char zeros[200] = { 0 };
        write(fd, zeros, sizeof zeros);     /* make the file 200 bytes long */
        if (lock_range(fd, 0, 50) == -1) {
            perror("lock 0-49");
            return 1;
        }
        printf("PID %d holds a write lock on bytes 0-49 for 30 s\n", (int)getpid());
        fflush(stdout);
        sleep(30);
        printf("Releasing the lock (process exits)\n");
        return 0;
    }

    printf("Tester PID %d\n", (int)getpid());
    if (lock_range(fd, 50, 50) == 0)
        printf("lock bytes 50-99 : SUCCESS\n");
    else
        printf("lock bytes 50-99 : FAILED (%s)\n", strerror(errno));

    if (lock_range(fd, 0, 11) == 0)
        printf("lock bytes 0-10  : SUCCESS\n");
    else
        printf("lock bytes 0-10  : FAILED (%s)\n", strerror(errno));
    return 0;
}
