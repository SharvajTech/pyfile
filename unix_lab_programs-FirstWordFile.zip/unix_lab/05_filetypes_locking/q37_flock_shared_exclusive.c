/*
 * PROBLEM STATEMENT
 * Q37. Use flock() with LOCK_SH in two reading processes at the same time.
 *     Then try LOCK_EX from a third process and show that it waits.
 *
 * Q37: flock() with LOCK_SH in two readers at once; LOCK_EX from a third
 *      process waits until both shared locks are released.
 *
 * Compile : gcc q37_flock_shared_exclusive.c -o q37_flock_shared_exclusive
 * Run     : Terminal 1: ./q37_flock_shared_exclusive sh R1      (shared lock, held 15 s)
 *           Terminal 2: ./q37_flock_shared_exclusive sh R2      (also gets it immediately)
 *           Terminal 3: ./q37_flock_shared_exclusive ex W       (prints "waiting..." and blocks
 *                                               until both readers finish)
 */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/file.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 3 || (strcmp(argv[1], "sh") && strcmp(argv[1], "ex"))) {
        fprintf(stderr, "Usage: %s sh|ex <name>\n", argv[0]);
        return 1;
    }
    int shared = (strcmp(argv[1], "sh") == 0);
    const char *name = argv[2];

    int fd = open("q37_flockfile.txt", O_RDWR | O_CREAT, 0644);
    if (fd == -1) { perror("open"); return 1; }

    printf("[%s] PID %d requesting %s lock, waiting...\n", name, (int)getpid(),
           shared ? "SHARED (LOCK_SH)" : "EXCLUSIVE (LOCK_EX)");
    fflush(stdout);

    if (flock(fd, shared ? LOCK_SH : LOCK_EX) == -1) {
        perror("flock");
        return 1;
    }
    printf("[%s] lock ACQUIRED, holding for %d s\n", name, shared ? 15 : 3);
    fflush(stdout);
    sleep(shared ? 15 : 3);

    flock(fd, LOCK_UN);
    printf("[%s] lock released\n", name);
    close(fd);
    return 0;
}
