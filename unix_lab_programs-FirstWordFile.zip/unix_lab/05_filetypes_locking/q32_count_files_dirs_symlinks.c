/*
 * PROBLEM STATEMENT
 * Q32. Write a program that counts the regular files, directories and
 *     symbolic links in a given directory.
 *
 * Q32: Count regular files, directories and symbolic links in a directory.
 *
 * Compile : gcc q32_count_files_dirs_symlinks.c -o q32_count_files_dirs_symlinks
 * Run     : ./q32_count_files_dirs_symlinks .
 *           ./q32_count_files_dirs_symlinks /etc
 * Compare : ls -l /etc | cut -c1 | sort | uniq -c
 *
 * lstat() is used so that symbolic links are counted as links (stat() would
 * follow them). "." and ".." are counted as directories.
 */
#include <dirent.h>
#include <stdio.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    const char *dir = (argc > 1) ? argv[1] : ".";
    DIR *d = opendir(dir);
    if (!d) {
        perror("opendir");
        return 1;
    }
    int reg = 0, dirs = 0, links = 0, other = 0;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        char path[4096];
        snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
        struct stat st;
        if (lstat(path, &st) == -1) {
            perror(path);
            continue;
        }
        if (S_ISREG(st.st_mode))      reg++;
        else if (S_ISDIR(st.st_mode)) dirs++;
        else if (S_ISLNK(st.st_mode)) links++;
        else                          other++;
    }
    closedir(d);

    printf("Directory       : %s\n", dir);
    printf("Regular files   : %d\n", reg);
    printf("Directories     : %d (includes . and ..)\n", dirs);
    printf("Symbolic links  : %d\n", links);
    printf("Other types     : %d\n", other);
    return 0;
}
