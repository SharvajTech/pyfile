/*
 * PROBLEM STATEMENT
 * Q33. Write a program that creates a regular file, a directory, a FIFO and
 *     a symbolic link using open(), mkdir(), mkfifo() and symlink(), and
 *     then prints the type of each using lstat().
 *
 * Q33: Create a regular file, a directory, a FIFO and a symbolic link with
 *      open(), mkdir(), mkfifo() and symlink(); print each type using lstat().
 *
 * Compile : gcc q33_create_file_dir_fifo_symlink_lstat.c -o q33_create_file_dir_fifo_symlink_lstat
 * Run     : ./q33_create_file_dir_fifo_symlink_lstat
 * Compare : ls -l demo_file demo_dir demo_fifo demo_link
 * Cleanup : rm -rf demo_file demo_dir demo_fifo demo_link
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static void show_type(const char *name)
{
    struct stat st;
    if (lstat(name, &st) == -1) {
        perror(name);
        return;
    }
    const char *t = S_ISREG(st.st_mode)  ? "regular file"
                  : S_ISDIR(st.st_mode)  ? "directory"
                  : S_ISFIFO(st.st_mode) ? "FIFO (named pipe)"
                  : S_ISLNK(st.st_mode)  ? "symbolic link"
                  : S_ISCHR(st.st_mode)  ? "character device"
                  : S_ISBLK(st.st_mode)  ? "block device"
                  : S_ISSOCK(st.st_mode) ? "socket" : "unknown";
    printf("%-12s -> %s\n", name, t);
}

int main(void)
{
    /* remove leftovers so the program can be run repeatedly */
    unlink("demo_file");
    rmdir("demo_dir");
    unlink("demo_fifo");
    unlink("demo_link");

    int fd = open("demo_file", O_WRONLY | O_CREAT | O_EXCL, 0644);
    if (fd == -1) { perror("open"); return 1; }
    close(fd);

    if (mkdir("demo_dir", 0755) == -1)    { perror("mkdir");   return 1; }
    if (mkfifo("demo_fifo", 0644) == -1)  { perror("mkfifo");  return 1; }
    if (symlink("demo_file", "demo_link") == -1) { perror("symlink"); return 1; }

    show_type("demo_file");
    show_type("demo_dir");
    show_type("demo_fifo");
    show_type("demo_link");
    return 0;
}
