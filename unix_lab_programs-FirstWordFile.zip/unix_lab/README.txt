UNIX PROGRAMMING LAB - Q1 to Q50
================================

Every .c file starts with a comment block that says how to compile it, how to
run it, and (where the question asks) what the output means. Q34 needs no C
code, so it is a text file of commands with explanations.

Quick start
-----------
    cd unix_lab
    ./compile_all.sh                  # builds every program (needs gcc, Linux)
    cd 02_process_control && ./q06_fork_even_odd_parent_child

Or compile one file:   gcc qNN_name.c -o qNN_name
Thread programs need:  gcc -pthread qNN_name.c -o qNN_name

Folders
-------
01_kernel_system        Q1-Q5     PID/UID, read/write + strace, sysconf, uname, getrlimit
02_process_control      Q6-Q14    fork, zombie, orphan, exec*, mini shell, vfork timing
03_signals              Q15-Q23   SIGINT, alarm, ping-pong, SIG_IGN, kill, sigprocmask, SIGCHLD, killpg
04_filesystem           Q24-Q31   stat, fstat, hard/soft links, statvfs, ls -li, unlink, chmod
05_filetypes_locking    Q32-Q38   file types, super block (Q34 = text), lockf, fcntl, flock, F_GETLK
06_threads              Q39-Q43   pthreads, join, mutex, clone, partial sums
07_semaphores           Q44-Q50   System V semaphores, producer-consumer, blocking P/V

Programs that need two or three terminals
-----------------------------------------
Q14 (compile q14_child_worker_exit_status too), Q19 (receiver + sender), Q35, Q36, Q37, Q38
and Q48 (create, P, V). Their header comments give the exact order.

Notes
-----
* Written for Linux (glibc). clone() (Q42) and /proc based tools are Linux only.
* Q34 needs root (sudo) and an ext2/3/4 root partition for dumpe2fs/tune2fs.
* Leftover System V semaphores can be listed with "ipcs -s" and removed with
  "ipcrm -s <id>". Programs clean up after themselves except Q48.

File index (question -> file)
----------------------------
Q1   01_kernel_system/q01_print_pid_ppid_uid_gid.c
Q2   01_kernel_system/q02_copy_file_read_write_strace.c
Q3   01_kernel_system/q03_cpu_cores_page_size_sysconf.c
Q4   01_kernel_system/q04_os_kernel_machine_uname.c
Q5   01_kernel_system/q05_max_open_files_stack_getrlimit.c
Q6   02_process_control/q06_fork_even_odd_parent_child.c
Q7   02_process_control/q07_zombie_process.c
Q8   02_process_control/q08_orphan_process.c
Q9   02_process_control/q09_two_children_execl_execvp_waitpid.c
Q10  02_process_control/q10_run_command_execv.c
Q11  02_process_control/q11_mini_shell.c
Q12  02_process_control/q12_process_chain_grandchild.c
Q13  02_process_control/q13_fork_vs_vfork_timing.c
Q14  02_process_control/q14_child_worker_exit_status.c
Q14  02_process_control/q14_three_children_exit_status.c
Q15  03_signals/q15_sigint_ctrl_c_counter.c
Q16  03_signals/q16_alarm_sigalrm_tick.c
Q17  03_signals/q17_sigusr_ping_pong.c
Q18  03_signals/q18_sigint_ignore_then_default.c
Q19  03_signals/q19_kill_send_sigusr1_sender.c
Q19  03_signals/q19_pause_wait_sigusr1_receiver.c
Q20  03_signals/q20_sigkill_sigstop_cannot_catch.c
Q21  03_signals/q21_sigprocmask_block_sigint.c
Q22  03_signals/q22_sigchld_handler_waitpid_wnohang.c
Q23  03_signals/q23_killpg_process_group.c
Q24  04_filesystem/q24_stat_permissions_owner_group.c
Q25  04_filesystem/q25_fstat_size_inode_append.c
Q26  04_filesystem/q26_hard_link_same_file_check.c
Q27  04_filesystem/q27_symlink_readlink_stat_lstat.c
Q28  04_filesystem/q28_statvfs_blocks_inodes.c
Q29  04_filesystem/q29_ls_li_inode_links_size.c
Q30  04_filesystem/q30_unlink_open_file_still_readable.c
Q31  04_filesystem/q31_chmod_644_st_mode.c
Q32  05_filetypes_locking/q32_count_files_dirs_symlinks.c
Q33  05_filetypes_locking/q33_create_file_dir_fifo_symlink_lstat.c
Q34  05_filetypes_locking/q34_superblock_dumpe2fs_tune2fs_commands.txt
Q35  05_filetypes_locking/q35_lockf_ftlock_append.c
Q36  05_filetypes_locking/q36_fcntl_byte_range_locks.c
Q37  05_filetypes_locking/q37_flock_shared_exclusive.c
Q38  05_filetypes_locking/q38_fcntl_getlk_lock_owner_pid.c
Q39  06_threads/q39_three_threads_even_odd_prime.c
Q40  06_threads/q40_thread_factorial_pthread_exit.c
Q41  06_threads/q41_shared_counter_mutex.c
Q42  06_threads/q42_clone_vm_vs_fork.c
Q43  06_threads/q43_four_threads_array_sum.c
Q44  07_semaphores/q44_semaphore_getval_p_v.c
Q45  07_semaphores/q45_ping_pong_two_semaphores.c
Q46  07_semaphores/q46_semaphore_mutex_file_writes.c
Q47  07_semaphores/q47_producer_consumer_semaphores.c
Q48  07_semaphores/q48_semaphore_create_print_id.c
Q48  07_semaphores/q48_semaphore_p_operation.c
Q48  07_semaphores/q48_semaphore_v_operation.c
Q49  07_semaphores/q49_counter_file_binary_semaphore.c
Q50  07_semaphores/q50_semop_ipc_nowait.c
