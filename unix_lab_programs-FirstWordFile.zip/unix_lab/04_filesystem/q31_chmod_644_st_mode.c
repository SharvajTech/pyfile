/*
 * PROBLEM STATEMENT
 * Q31. Change the permissions of a file to 644 using chmod(). Print st_mode
 *     before and after the change.
 *
 * Q31: Change permissions to 644 with chmod(); print st_mode before and after.
 *
 * Compile : gcc q31_chmod_644_st_mode.c -o q31_chmod_644_st_mode
 * Run     : ./q31_chmod_644_st_mode                 (creates q31_test.txt with mode 777 first)
 *           ./q31_chmod_644_st_mode myfile.txt
 * Compare : ls -l q31_test.txt
 *
 * st_mode holds the file type bits plus permission bits. For a regular file
 * the full value is 0100644 (0100000 = regular file, 644 = rw-r--r--).
 */
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

static void show(const char *label, const char *file)
{
    struct stat st;
    if (stat(file, &st) == -1) {
        perror("stat");
        return;
    }
    printf("%-7s st_mode = %07o (permissions: %03o)\n",
           label, st.st_mode, st.st_mode & 07777);
}

int main(int argc, char *argv[])
{
    const char *file = (argc > 1) ? argv[1] : "q31_test.txt";

    if (argc == 1) {
        int fd = open(file, O_WRONLY | O_CREAT, 0777);
        if (fd >= 0)
            close(fd);
        chmod(file, 0777);                  /* ignore the umask for the demo */
    }
    show("Before:", file);
    if (chmod(file, 0644) == -1) {
        perror("chmod");
        return 1;
    }
    show("After:", file);
    return 0;
}
