/*
 * PROBLEM STATEMENT
 * Q24. Using stat(), print the permissions of a file in rwxr-xr-x form, with
 *     the owner name (getpwuid) and the group name (getgrgid).
 *
 * Q24: Print file permissions in rwxr-xr-x form with owner and group names.
 *
 * Compile : gcc q24_stat_permissions_owner_group.c -o q24_stat_permissions_owner_group
 * Run     : ./q24_stat_permissions_owner_group /bin/ls
 *           ./q24_stat_permissions_owner_group q24_stat_permissions_owner_group.c
 * Compare : ls -l <file>
 */
#include <grp.h>
#include <pwd.h>
#include <stdio.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    }
    struct stat st;
    if (stat(argv[1], &st) == -1) {
        perror("stat");
        return 1;
    }

    char perm[10];
    const char *rwx = "rwxrwxrwx";
    for (int i = 0; i < 9; i++)
        perm[i] = (st.st_mode & (1u << (8 - i))) ? rwx[i] : '-';
    perm[9] = '\0';

    struct passwd *pw = getpwuid(st.st_uid);
    struct group  *gr = getgrgid(st.st_gid);

    printf("File        : %s\n", argv[1]);
    printf("Permissions : %s (octal %03o)\n", perm, st.st_mode & 0777);
    printf("Owner       : %s (uid %d)\n", pw ? pw->pw_name : "?", (int)st.st_uid);
    printf("Group       : %s (gid %d)\n", gr ? gr->gr_name : "?", (int)st.st_gid);
    return 0;
}
