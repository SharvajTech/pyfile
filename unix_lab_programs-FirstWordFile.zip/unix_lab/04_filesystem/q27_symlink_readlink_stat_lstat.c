/*
 * PROBLEM STATEMENT
 * Q27. Create a symbolic link using symlink() and read its target using
 *     readlink(). Show the difference between stat() and lstat() on it.
 *
 * Q27: symlink(), readlink(), and the difference between stat() and lstat().
 *
 * Compile : gcc q27_symlink_readlink_stat_lstat.c -o q27_symlink_readlink_stat_lstat
 * Run     : ./q27_symlink_readlink_stat_lstat                      (target q27_target.txt, link q27_link)
 *           ./q27_symlink_readlink_stat_lstat target.txt mylink
 * Compare : ls -li q27_target.txt q27_link
 *
 * stat()  follows the link  -> describes the TARGET file (regular file,
 *                              target's size and inode).
 * lstat() does not follow   -> describes the LINK itself (type symlink, size
 *                              = length of the target path, its own inode).
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void show(const char *label, const struct stat *st)
{
    const char *type = S_ISLNK(st->st_mode) ? "symbolic link"
                     : S_ISREG(st->st_mode) ? "regular file" : "other";
    printf("%-8s type = %-13s size = %lld, inode = %llu\n", label, type,
           (long long)st->st_size, (unsigned long long)st->st_ino);
}

int main(int argc, char *argv[])
{
    const char *target = (argc > 2) ? argv[1] : "q27_target.txt";
    const char *link   = (argc > 2) ? argv[2] : "q27_link";

    int fd = open(target, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd >= 0) {
        const char *s = "target file contents\n";
        write(fd, s, strlen(s));
        close(fd);
    }

    unlink(link);                               /* remove an old link, if any */
    if (symlink(target, link) == -1) {
        perror("symlink");
        return 1;
    }

    char buf[1024];
    ssize_t n = readlink(link, buf, sizeof buf - 1);
    if (n == -1) {
        perror("readlink");
        return 1;
    }
    buf[n] = '\0';
    printf("readlink(%s) -> \"%s\"\n\n", link, buf);

    struct stat st;
    if (stat(link, &st) == 0)
        show("stat:", &st);
    else
        printf("stat: %s\n", strerror(errno));
    if (lstat(link, &st) == 0)
        show("lstat:", &st);
    return 0;
}
