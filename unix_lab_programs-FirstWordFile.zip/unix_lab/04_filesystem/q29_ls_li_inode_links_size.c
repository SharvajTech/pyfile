/*
 * PROBLEM STATEMENT
 * Q29. Write a program like ls -li: list the files of a directory with inode
 *     number, link count and size.
 *
 * Q29: Mini "ls -li": inode number, link count and size for each file.
 *
 * Compile : gcc q29_ls_li_inode_links_size.c -o q29_ls_li_inode_links_size
 * Run     : ./q29_ls_li_inode_links_size            (current directory)
 *           ./q29_ls_li_inode_links_size /etc
 * Compare : ls -li
 */
#define _DEFAULT_SOURCE
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    const char *dir = (argc > 1) ? argv[1] : ".";
    struct dirent **list;
    int n = scandir(dir, &list, NULL, alphasort);
    if (n < 0) {
        perror("scandir");
        return 1;
    }
    printf("%10s %6s %12s  %s\n", "INODE", "LINKS", "SIZE", "NAME");
    for (int i = 0; i < n; i++) {
        char path[4096];
        snprintf(path, sizeof path, "%s/%s", dir, list[i]->d_name);
        struct stat st;
        if (lstat(path, &st) == -1) {
            perror(path);
        } else {
            printf("%10llu %6lu %12lld  %s\n",
                   (unsigned long long)st.st_ino, (unsigned long)st.st_nlink,
                   (long long)st.st_size, list[i]->d_name);
        }
        free(list[i]);
    }
    free(list);
    return 0;
}
