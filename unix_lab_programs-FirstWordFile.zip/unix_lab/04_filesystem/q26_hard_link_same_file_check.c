/*
 * PROBLEM STATEMENT
 * Q26. Write a program that accepts two file names and tells whether they
 *     are hard links to the same file (compare st_dev and st_ino).
 *
 * Q26: Tell whether two file names are hard links to the same file
 *      (same st_dev and st_ino).
 *
 * Compile : gcc q26_hard_link_same_file_check.c -o q26_hard_link_same_file_check
 * Run     : echo hi > a.txt ; ln a.txt b.txt ; echo other > c.txt
 *           ./q26_hard_link_same_file_check a.txt b.txt    -> same file
 *           ./q26_hard_link_same_file_check a.txt c.txt    -> different files
 */
#include <stdio.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Usage: %s file1 file2\n", argv[0]);
        return 1;
    }
    struct stat a, b;
    if (stat(argv[1], &a) == -1) { perror(argv[1]); return 1; }
    if (stat(argv[2], &b) == -1) { perror(argv[2]); return 1; }

    printf("%s: dev=%llu inode=%llu links=%lu\n", argv[1],
           (unsigned long long)a.st_dev, (unsigned long long)a.st_ino,
           (unsigned long)a.st_nlink);
    printf("%s: dev=%llu inode=%llu links=%lu\n", argv[2],
           (unsigned long long)b.st_dev, (unsigned long long)b.st_ino,
           (unsigned long)b.st_nlink);

    if (a.st_dev == b.st_dev && a.st_ino == b.st_ino)
        printf("Result: SAME file (hard links to one inode).\n");
    else
        printf("Result: DIFFERENT files.\n");
    return 0;
}
