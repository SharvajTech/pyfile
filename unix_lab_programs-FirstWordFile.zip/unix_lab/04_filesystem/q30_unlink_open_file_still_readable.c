/*
 * PROBLEM STATEMENT
 * Q30. Open a file, delete it with unlink() while it is still open, and show
 *     that it can still be read. Explain this using the link count.
 *
 * Q30: Delete a file with unlink() while it is still open; it can still be read.
 *
 * Compile : gcc q30_unlink_open_file_still_readable.c -o q30_unlink_open_file_still_readable
 * Run     : ./q30_unlink_open_file_still_readable
 *           ls q30_test.txt    -> "No such file" after the program unlinks it
 *
 * Explanation (link count):
 *   A file's data lives in an inode. The inode has a link count (st_nlink) =
 *   number of directory entries (names) pointing to it. unlink() removes one
 *   name and decrements the count. The kernel frees the inode and data only
 *   when BOTH the link count is 0 AND no process still has the file open
 *   (the open file description holds a reference). After unlink() the count
 *   is 0, but our open descriptor keeps the inode alive, so read() still
 *   works. When we close(fd), the last reference goes away and the space is
 *   released.
 */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

int main(void)
{
    const char *name = "q30_test.txt";
    int fd = open(name, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) { perror("open"); return 1; }

    const char *text = "This data survives unlink() while the file is open.\n";
    write(fd, text, strlen(text));

    struct stat st;
    fstat(fd, &st);
    printf("Before unlink: link count = %lu\n", (unsigned long)st.st_nlink);

    if (unlink(name) == -1) { perror("unlink"); return 1; }

    fstat(fd, &st);
    printf("After  unlink: link count = %lu (name is gone from the directory)\n",
           (unsigned long)st.st_nlink);
    printf("access(\"%s\") = %d (file no longer visible by name)\n",
           name, access(name, F_OK));

    char buf[256];
    lseek(fd, 0, SEEK_SET);
    ssize_t n = read(fd, buf, sizeof buf - 1);
    if (n > 0) {
        buf[n] = '\0';
        printf("Read through the open descriptor: %s", buf);
    }
    close(fd);
    printf("File closed: inode and data blocks are now freed.\n");
    return 0;
}
