/*
 * PROBLEM STATEMENT
 * Q28. Use statvfs() (or ustat() if available) to print the total blocks,
 *     free blocks and total inodes of the file system that contains a given
 *     path.
 *
 * Q28: Total blocks, free blocks and total inodes of the file system that
 *      contains a given path, using statvfs().
 *
 * Compile : gcc q28_statvfs_blocks_inodes.c -o q28_statvfs_blocks_inodes
 * Run     : ./q28_statvfs_blocks_inodes /
 *           ./q28_statvfs_blocks_inodes /home
 * Compare : df -h / ; df -i /
 */
#include <stdio.h>
#include <sys/statvfs.h>

int main(int argc, char *argv[])
{
    const char *path = (argc > 1) ? argv[1] : "/";
    struct statvfs v;
    if (statvfs(path, &v) == -1) {
        perror("statvfs");
        return 1;
    }
    printf("Path                    : %s\n", path);
    printf("Block size              : %lu bytes\n", v.f_bsize);
    printf("Fragment size           : %lu bytes\n", v.f_frsize);
    printf("Total blocks            : %llu\n", (unsigned long long)v.f_blocks);
    printf("Free blocks             : %llu\n", (unsigned long long)v.f_bfree);
    printf("Free blocks (non-root)  : %llu\n", (unsigned long long)v.f_bavail);
    printf("Total inodes            : %llu\n", (unsigned long long)v.f_files);
    printf("Free inodes             : %llu\n", (unsigned long long)v.f_ffree);
    printf("Total size              : %.2f MB\n",
           (double)v.f_blocks * (double)v.f_frsize / (1024.0 * 1024.0));
    return 0;
}
