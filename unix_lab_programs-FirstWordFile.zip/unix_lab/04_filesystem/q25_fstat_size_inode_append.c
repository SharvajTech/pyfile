/*
 * PROBLEM STATEMENT
 * Q25. Open a file and use fstat() to print its size and inode number.
 *     Append some data with write() and call fstat() again to show the size
 *     change.
 *
 * Q25: fstat() size and inode number; append data with write(); fstat() again.
 *
 * Compile : gcc q25_fstat_size_inode_append.c -o q25_fstat_size_inode_append
 * Run     : ./q25_fstat_size_inode_append              (uses/creates q25_test.txt)
 *           ./q25_fstat_size_inode_append myfile.txt
 * Compare : ls -li q25_test.txt
 */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void show(int fd, const char *label)
{
    struct stat st;
    if (fstat(fd, &st) == -1) {
        perror("fstat");
        return;
    }
    printf("%-14s size = %lld bytes, inode = %llu\n", label,
           (long long)st.st_size, (unsigned long long)st.st_ino);
}

int main(int argc, char *argv[])
{
    const char *name = (argc > 1) ? argv[1] : "q25_test.txt";
    int fd = open(name, O_RDWR | O_CREAT | O_APPEND, 0644);
    if (fd == -1) {
        perror("open");
        return 1;
    }
    show(fd, "Before write:");

    const char *data = "Some appended data\n";
    if (write(fd, data, strlen(data)) == -1) {
        perror("write");
        close(fd);
        return 1;
    }
    show(fd, "After write:");
    printf("Size increased by %zu bytes; inode number is unchanged.\n", strlen(data));
    close(fd);
    return 0;
}
