/*
 * PROBLEM STATEMENT
 * Q40. Create a thread that receives an integer as its argument and returns
 *     its factorial using pthread_exit(). The main thread collects it with
 *     pthread_join().
 *
 * Q40: A thread receives an integer, returns its factorial via pthread_exit();
 *      main collects it with pthread_join().
 *
 * Compile : gcc -pthread q40_thread_factorial_pthread_exit.c -o q40_thread_factorial_pthread_exit
 * Run     : ./q40_thread_factorial_pthread_exit 10        (argument 0..20; default 5)
 *           20! is the largest factorial that fits in unsigned 64 bits.
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static void *factorial(void *arg)
{
    int n = *(int *)arg;
    unsigned long long *result = malloc(sizeof *result);
    *result = 1;
    for (int i = 2; i <= n; i++)
        *result *= (unsigned long long)i;
    pthread_exit(result);                   /* returned value is heap memory */
}

int main(int argc, char *argv[])
{
    int n = (argc > 1) ? atoi(argv[1]) : 5;
    if (n < 0 || n > 20) {
        fprintf(stderr, "Use a number between 0 and 20 (64-bit overflow beyond 20)\n");
        return 1;
    }
    pthread_t tid;
    if (pthread_create(&tid, NULL, factorial, &n) != 0) {
        fprintf(stderr, "pthread_create failed\n");
        return 1;
    }
    void *ret = NULL;
    pthread_join(tid, &ret);
    unsigned long long *res = ret;
    printf("%d! = %llu (returned by the thread)\n", n, *res);
    free(res);
    return 0;
}
