/*
 * PROBLEM STATEMENT
 * Q43. Create four threads. Each computes the sum of one quarter of an array
 *     of 1000 integers, and the main thread adds the partial sums.
 *
 * Q43: Four threads each sum one quarter of a 1000-integer array;
 *      main adds the partial sums.
 *
 * Compile : gcc -pthread q43_four_threads_array_sum.c -o q43_four_threads_array_sum
 * Run     : ./q43_four_threads_array_sum
 * Check   : array holds 1..1000, so the total must be 500500.
 */
#include <pthread.h>
#include <stdio.h>

#define SIZE 1000
#define NTHREADS 4

static int array[SIZE];

struct part {
    int start, end;                         /* [start, end) */
    long sum;
};

static void *partial_sum(void *arg)
{
    struct part *p = arg;
    p->sum = 0;
    for (int i = p->start; i < p->end; i++)
        p->sum += array[i];
    return NULL;
}

int main(void)
{
    for (int i = 0; i < SIZE; i++)
        array[i] = i + 1;

    pthread_t tid[NTHREADS];
    struct part parts[NTHREADS];
    int chunk = SIZE / NTHREADS;

    for (int i = 0; i < NTHREADS; i++) {
        parts[i].start = i * chunk;
        parts[i].end = (i + 1) * chunk;
        pthread_create(&tid[i], NULL, partial_sum, &parts[i]);
    }

    long total = 0;
    for (int i = 0; i < NTHREADS; i++) {
        pthread_join(tid[i], NULL);
        printf("Thread %d: elements %3d..%3d, partial sum = %ld\n",
               i + 1, parts[i].start, parts[i].end - 1, parts[i].sum);
        total += parts[i].sum;
    }
    printf("Total = %ld (expected 500500)\n", total);
    return 0;
}
