/*
 * PROBLEM STATEMENT
 * Q41. Two threads each increment a shared counter 100000 times. Show the
 *     wrong result without protection and then fix it using a pthread mutex.
 *
 * Q41: Two threads each increment a shared counter 100000 times.
 *      First without protection (wrong result), then with a pthread mutex.
 *
 * Compile : gcc -pthread q41_shared_counter_mutex.c -o q41_shared_counter_mutex      (do not use -O2: the
 *           race is easier to see without optimisation)
 * Run     : ./q41_shared_counter_mutex           (run it a few times; the unsafe result varies)
 *
 * Why it is wrong: counter++ is read, add, write. Two threads can read the
 * same value and both write value+1, so one increment is lost.
 */
#include <pthread.h>
#include <stdio.h>

#define N 100000

static volatile long counter = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void *inc_unsafe(void *arg)
{
    (void)arg;
    for (int i = 0; i < N; i++)
        counter++;
    return NULL;
}

static void *inc_safe(void *arg)
{
    (void)arg;
    for (int i = 0; i < N; i++) {
        pthread_mutex_lock(&lock);
        counter++;
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

static void run(void *(*fn)(void *), const char *label)
{
    pthread_t a, b;
    counter = 0;
    pthread_create(&a, NULL, fn, NULL);
    pthread_create(&b, NULL, fn, NULL);
    pthread_join(a, NULL);
    pthread_join(b, NULL);
    printf("%-22s counter = %ld (expected %d)%s\n", label, counter, 2 * N,
           counter == 2 * N ? "  OK" : "  WRONG");
}

int main(void)
{
    run(inc_unsafe, "Without mutex:");
    run(inc_safe,   "With mutex:");
    return 0;
}
