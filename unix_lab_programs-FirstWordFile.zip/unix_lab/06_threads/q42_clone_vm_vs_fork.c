/*
 * PROBLEM STATEMENT
 * Q42. Use clone() with CLONE_VM to create a child that shares memory with
 *     the parent. Show that a variable changed by the child is visible to
 *     the parent and compare this with fork().
 *
 * Q42: clone() with CLONE_VM: the child shares memory with the parent.
 *      Compare with fork(), where the child gets a private copy.
 *
 * Compile : gcc q42_clone_vm_vs_fork.c -o q42_clone_vm_vs_fork
 * Run     : ./q42_clone_vm_vs_fork
 * Expected: after clone(CLONE_VM) the parent sees the child's change (200);
 *           after fork() the parent still sees the original value (100).
 */
#define _GNU_SOURCE
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

#define STACK_SIZE (1024 * 1024)

static int shared = 100;

static int child_fn(void *arg)
{
    (void)arg;
    shared = 200;
    printf("  clone child: set shared = %d\n", shared);
    return 0;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    /* ---- clone with CLONE_VM ---- */
    char *stack = malloc(STACK_SIZE);
    if (!stack) { perror("malloc"); return 1; }
    printf("Before clone: shared = %d\n", shared);
    pid_t pid = clone(child_fn, stack + STACK_SIZE, CLONE_VM | SIGCHLD, NULL);
    if (pid == -1) { perror("clone"); return 1; }
    waitpid(pid, NULL, 0);
    printf("After  clone(CLONE_VM): parent sees shared = %d  (memory is SHARED)\n\n",
           shared);
    free(stack);

    /* ---- fork ---- */
    shared = 100;
    printf("Before fork : shared = %d\n", shared);
    pid = fork();
    if (pid == -1) { perror("fork"); return 1; }
    if (pid == 0) {
        shared = 200;
        printf("  fork child : set shared = %d\n", shared);
        _exit(0);
    }
    waitpid(pid, NULL, 0);
    printf("After  fork()          : parent sees shared = %d  (memory is COPIED)\n",
           shared);
    return 0;
}
