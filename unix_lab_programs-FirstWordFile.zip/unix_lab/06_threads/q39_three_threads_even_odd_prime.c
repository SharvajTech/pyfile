/*
 * PROBLEM STATEMENT
 * Q39. Create three pthreads: one prints even numbers up to 20, one prints
 *     odd numbers up to 20 and one prints prime numbers up to 20. The main
 *     thread joins all of them.
 *
 * Q39: Three pthreads: even numbers, odd numbers and primes up to 20.
 *      The main thread joins all of them.
 *
 * Compile : gcc -pthread q39_three_threads_even_odd_prime.c -o q39_three_threads_even_odd_prime
 * Run     : ./q39_three_threads_even_odd_prime
 */
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define LIMIT 20

static void *print_even(void *arg)
{
    (void)arg;
    for (int i = 2; i <= LIMIT; i += 2) {
        printf("[even ] %d\n", i);
        usleep(50000);
    }
    return NULL;
}

static void *print_odd(void *arg)
{
    (void)arg;
    for (int i = 1; i <= LIMIT; i += 2) {
        printf("[odd  ] %d\n", i);
        usleep(50000);
    }
    return NULL;
}

static int is_prime(int n)
{
    if (n < 2)
        return 0;
    for (int d = 2; d * d <= n; d++)
        if (n % d == 0)
            return 0;
    return 1;
}

static void *print_prime(void *arg)
{
    (void)arg;
    for (int i = 2; i <= LIMIT; i++) {
        if (is_prime(i)) {
            printf("[prime] %d\n", i);
            usleep(50000);
        }
    }
    return NULL;
}

int main(void)
{
    pthread_t t1, t2, t3;
    if (pthread_create(&t1, NULL, print_even, NULL) ||
        pthread_create(&t2, NULL, print_odd, NULL) ||
        pthread_create(&t3, NULL, print_prime, NULL)) {
        fprintf(stderr, "pthread_create failed\n");
        return 1;
    }
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    printf("Main: all three threads joined.\n");
    return 0;
}
