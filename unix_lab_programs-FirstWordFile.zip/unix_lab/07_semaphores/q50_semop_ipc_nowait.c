/*
 * PROBLEM STATEMENT
 * Q50. Call semop() on a semaphore whose value is 0 using IPC_NOWAIT and
 *     print the error message. Explain what happens without IPC_NOWAIT.
 *
 * Q50: semop() on a semaphore whose value is 0, with IPC_NOWAIT, and the
 *      error message. Explanation of the case without IPC_NOWAIT.
 *
 * Compile : gcc q50_semop_ipc_nowait.c -o q50_semop_ipc_nowait
 * Run     : ./q50_semop_ipc_nowait           (IPC_NOWAIT: fails at once with EAGAIN)
 *           ./q50_semop_ipc_nowait block     (no IPC_NOWAIT: blocks; a 3 s alarm
 *                                         interrupts it so the demo can finish)
 *
 * Explanation:
 *   With IPC_NOWAIT, a P operation (-1) on a semaphore whose value is 0 cannot
 *   proceed, so semop() returns -1 immediately with errno = EAGAIN
 *   ("Resource temporarily unavailable").
 *   Without IPC_NOWAIT, the calling process is put to sleep inside semop()
 *   until one of these happens:
 *     - another process performs V, so the value becomes > 0 and the P succeeds;
 *     - the semaphore is removed (semop fails with EIDRM);
 *     - a signal is caught (semop fails with EINTR). The "block" mode below
 *       uses SIGALRM to demonstrate this.
 *   If nothing ever does V, the process would wait forever.
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

static void on_alarm(int sig) { (void)sig; }

int main(int argc, char *argv[])
{
    int block = (argc > 1 && strcmp(argv[1], "block") == 0);

    int id = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (id == -1) { perror("semget"); return 1; }
    union semun a;
    a.val = 0;
    semctl(id, 0, SETVAL, a);
    printf("Semaphore id %d, value = %d\n", id, semctl(id, 0, GETVAL));

    struct sembuf op = { 0, -1, block ? 0 : IPC_NOWAIT };

    if (block) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = on_alarm;           /* no SA_RESTART: semop returns EINTR */
        sigemptyset(&sa.sa_mask);
        sigaction(SIGALRM, &sa, NULL);
        alarm(3);
        printf("P without IPC_NOWAIT: process blocks (alarm in 3 s)...\n");
    } else {
        printf("P with IPC_NOWAIT on a semaphore of value 0...\n");
    }
    fflush(stdout);

    if (semop(id, &op, 1) == -1)
        printf("semop failed: errno = %d (%s)\n", errno, strerror(errno));
    else
        printf("semop succeeded\n");

    semctl(id, 0, IPC_RMID);
    return 0;
}
