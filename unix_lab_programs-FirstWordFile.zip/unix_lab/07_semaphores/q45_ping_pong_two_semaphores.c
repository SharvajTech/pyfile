/*
 * PROBLEM STATEMENT
 * Q45. Two processes print "ping" and "pong" alternately five times each
 *     using two semaphores.
 *
 * Q45: Two processes print "ping" and "pong" alternately, five times each,
 *      using two semaphores (one semaphore set with two semaphores).
 *
 * Compile : gcc q45_ping_pong_two_semaphores.c -o q45_ping_pong_two_semaphores
 * Run     : ./q45_ping_pong_two_semaphores
 *
 * sem 0 = "ping's turn" (starts at 1), sem 1 = "pong's turn" (starts at 0).
 * Each process does P on its own semaphore, prints, then V on the other's.
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <unistd.h>

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

static void sem_op(int id, int num, int delta)
{
    struct sembuf op = { (unsigned short)num, (short)delta, 0 };
    if (semop(id, &op, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    int id = semget(IPC_PRIVATE, 2, IPC_CREAT | 0600);
    if (id == -1) { perror("semget"); return 1; }

    union semun a;
    a.val = 1; semctl(id, 0, SETVAL, a);    /* ping goes first */
    a.val = 0; semctl(id, 1, SETVAL, a);

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                         /* child prints "pong" */
        for (int i = 1; i <= 5; i++) {
            sem_op(id, 1, -1);
            printf("pong %d  (child  PID %d)\n", i, (int)getpid());
            sem_op(id, 0, +1);
        }
        exit(0);
    }
    for (int i = 1; i <= 5; i++) {          /* parent prints "ping" */
        sem_op(id, 0, -1);
        printf("ping %d  (parent PID %d)\n", i, (int)getpid());
        sem_op(id, 1, +1);
    }
    waitpid(pid, NULL, 0);
    semctl(id, 0, IPC_RMID);
    printf("Done, semaphores removed.\n");
    return 0;
}
