/*
 * PROBLEM STATEMENT
 * Q49. Three processes each read a counter from a file, add 1 and write it
 *     back, 10 times each. Protect the read-modify-write with a binary
 *     semaphore and check the final value.
 *
 * Q49: Three processes each read a counter from a file, add 1 and write it
 *      back, 10 times each. A binary semaphore protects the
 *      read-modify-write. The final value should be 30.
 *
 * Compile : gcc q49_counter_file_binary_semaphore.c -o q49_counter_file_binary_semaphore
 * Run     : ./q49_counter_file_binary_semaphore          (with the semaphore: final value 30)
 *           ./q49_counter_file_binary_semaphore nosem    (without it: usually less than 30)
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <unistd.h>

#define FILE_NAME "q49_counter.txt"
#define PROCS 3
#define ROUNDS 10

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

static void sem_op(int id, int delta)
{
    struct sembuf op = { 0, (short)delta, 0 };
    if (semop(id, &op, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

static int read_counter(int fd)
{
    char buf[32] = { 0 };
    pread(fd, buf, sizeof buf - 1, 0);
    return atoi(buf);
}

static void write_counter(int fd, int value)
{
    char buf[32];
    int n = snprintf(buf, sizeof buf, "%10d\n", value);   /* fixed width */
    pwrite(fd, buf, (size_t)n, 0);
}

int main(int argc, char *argv[])
{
    int use_sem = !(argc > 1 && strcmp(argv[1], "nosem") == 0);

    int fd = open(FILE_NAME, O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (fd == -1) { perror("open"); return 1; }
    write_counter(fd, 0);

    int id = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (id == -1) { perror("semget"); return 1; }
    union semun a;
    a.val = 1;                              /* binary semaphore */
    semctl(id, 0, SETVAL, a);

    for (int p = 0; p < PROCS; p++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
            for (int i = 0; i < ROUNDS; i++) {
                if (use_sem) sem_op(id, -1);        /* P */
                int v = read_counter(fd);
                usleep(1000);                       /* widen the race window */
                write_counter(fd, v + 1);
                if (use_sem) sem_op(id, +1);        /* V */
            }
            exit(0);
        }
    }
    for (int p = 0; p < PROCS; p++)
        wait(NULL);

    int final = read_counter(fd);
    printf("Semaphore %s: final counter = %d (expected %d) %s\n",
           use_sem ? "used" : "NOT used", final, PROCS * ROUNDS,
           final == PROCS * ROUNDS ? "-> CORRECT" : "-> WRONG (lost updates)");
    close(fd);
    semctl(id, 0, IPC_RMID);
    return 0;
}
