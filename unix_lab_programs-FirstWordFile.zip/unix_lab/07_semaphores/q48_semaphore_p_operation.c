/*
 * PROBLEM STATEMENT
 * Q48. Write three programs: the first creates the semaphore and prints its
 *     id, the second performs P, the third performs V on the same semaphore.
 *     Run P first and show that it blocks until V is run.
 *
 * Q48 (program 2 of 3): perform P (wait) on the semaphore from q48_semaphore_create_print_id.
 *
 * Compile : gcc q48_semaphore_p_operation.c -o q48_semaphore_p_operation
 * Run     : ./q48_semaphore_create_print_id first, then ./q48_semaphore_p_operation
 *           It blocks (prints "waiting...") until ./q48_semaphore_v_operation is run.
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>

#define SEM_KEY 0x4A48

int main(void)
{
    int id = semget(SEM_KEY, 1, 0666);
    if (id == -1) {
        perror("semget (run ./q48_semaphore_create_print_id first)");
        return 1;
    }
    printf("PID %d: semaphore id %d, value = %d. Doing P, waiting...\n",
           (int)getpid(), id, semctl(id, 0, GETVAL));
    fflush(stdout);

    struct sembuf p = { 0, -1, 0 };         /* blocks while value is 0 */
    if (semop(id, &p, 1) == -1) {
        perror("semop P");
        return 1;
    }
    printf("PID %d: P completed, unblocked by V. Value now = %d\n",
           (int)getpid(), semctl(id, 0, GETVAL));
    return 0;
}
