/*
 * PROBLEM STATEMENT
 * Q47. Implement the producer-consumer problem with a 5-slot buffer using
 *     three semaphores (empty, full, mutex). The producer produces 10 items.
 *
 * Q47: Producer-consumer with a 5-slot buffer and three semaphores
 *      (empty, full, mutex). The producer produces 10 items.
 *
 * Compile : gcc q47_producer_consumer_semaphores.c -o q47_producer_consumer_semaphores
 * Run     : ./q47_producer_consumer_semaphores
 *
 * Design  : System V semaphore set of 3: sem0 = empty (starts 5),
 *           sem1 = full (starts 0), sem2 = mutex (starts 1).
 *           The buffer lives in System V shared memory. The child is the
 *           producer; the parent is the consumer.
 *   Producer: P(empty) P(mutex) put item V(mutex) V(full)
 *   Consumer: P(full)  P(mutex) get item V(mutex) V(empty)
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>

#define SLOTS 5
#define ITEMS 10
#define EMPTY 0
#define FULL  1
#define MUTEX 2

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct buffer {
    int slot[SLOTS];
    int in, out;
};

static void sem_op(int id, int num, int delta)
{
    struct sembuf op = { (unsigned short)num, (short)delta, 0 };
    if (semop(id, &op, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    int sid = semget(IPC_PRIVATE, 3, IPC_CREAT | 0600);
    int mid = shmget(IPC_PRIVATE, sizeof(struct buffer), IPC_CREAT | 0600);
    if (sid == -1 || mid == -1) { perror("semget/shmget"); return 1; }

    struct buffer *buf = shmat(mid, NULL, 0);
    if (buf == (void *)-1) { perror("shmat"); return 1; }
    buf->in = buf->out = 0;

    union semun a;
    a.val = SLOTS; semctl(sid, EMPTY, SETVAL, a);
    a.val = 0;     semctl(sid, FULL,  SETVAL, a);
    a.val = 1;     semctl(sid, MUTEX, SETVAL, a);

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                         /* producer */
        for (int item = 1; item <= ITEMS; item++) {
            sem_op(sid, EMPTY, -1);
            sem_op(sid, MUTEX, -1);
            buf->slot[buf->in] = item;
            printf("Producer: put item %2d in slot %d\n", item, buf->in);
            buf->in = (buf->in + 1) % SLOTS;
            sem_op(sid, MUTEX, +1);
            sem_op(sid, FULL, +1);
        }
        shmdt(buf);
        exit(0);
    }

    for (int i = 0; i < ITEMS; i++) {       /* consumer (slower, so buffer fills up) */
        sleep(1);
        sem_op(sid, FULL, -1);
        sem_op(sid, MUTEX, -1);
        int item = buf->slot[buf->out];
        printf("          Consumer: got item %2d from slot %d\n", item, buf->out);
        buf->out = (buf->out + 1) % SLOTS;
        sem_op(sid, MUTEX, +1);
        sem_op(sid, EMPTY, +1);
    }
    waitpid(pid, NULL, 0);
    shmdt(buf);
    shmctl(mid, IPC_RMID, NULL);
    semctl(sid, 0, IPC_RMID);
    printf("All %d items produced and consumed.\n", ITEMS);
    return 0;
}
