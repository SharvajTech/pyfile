/*
 * PROBLEM STATEMENT
 * Q46. Three child processes each write three lines containing their PID to
 *     the same file. Use a semaphore for mutual exclusion so that the lines
 *     are not mixed.
 *
 * Q46: Three children each write three lines containing their PID to the same
 *      file. A semaphore gives mutual exclusion so lines are not mixed.
 *
 * Compile : gcc q46_semaphore_mutex_file_writes.c -o q46_semaphore_mutex_file_writes
 * Run     : ./q46_semaphore_mutex_file_writes
 * Check   : cat q46_output.txt      (each child's three lines are together)
 *           To see the problem, change USE_SEM to 0, recompile and run again:
 *           the lines of different children interleave.
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <unistd.h>

#define USE_SEM 1

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

static void sem_op(int id, int delta)
{
    struct sembuf op = { 0, (short)delta, 0 };
    if (semop(id, &op, 1) == -1) {
        perror("semop");
        exit(1);
    }
}

int main(void)
{
    int id = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (id == -1) { perror("semget"); return 1; }
    union semun a;
    a.val = 1;                              /* binary semaphore */
    semctl(id, 0, SETVAL, a);

    int fd = open("q46_output.txt", O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0644);
    if (fd == -1) { perror("open"); return 1; }

    for (int c = 0; c < 3; c++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
#if USE_SEM
            sem_op(id, -1);                 /* P: enter critical section */
#endif
            for (int i = 1; i <= 3; i++) {
                char line[128];
                int n = snprintf(line, sizeof line, "Line %d from child PID %d\n",
                                 i, (int)getpid());
                write(fd, line, (size_t)n);
                usleep(200000);             /* gives other children a chance to mix in */
            }
#if USE_SEM
            sem_op(id, +1);                 /* V: leave critical section */
#endif
            exit(0);
        }
    }
    for (int c = 0; c < 3; c++)
        wait(NULL);

    close(fd);
    semctl(id, 0, IPC_RMID);
    printf("Finished. Contents of q46_output.txt:\n");
    fflush(stdout);
    system("cat q46_output.txt");
    return 0;
}
