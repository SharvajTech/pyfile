/*
 * PROBLEM STATEMENT
 * Q48. Write three programs: the first creates the semaphore and prints its
 *     id, the second performs P, the third performs V on the same semaphore.
 *     Run P first and show that it blocks until V is run.
 *
 * Q48 (program 3 of 3): perform V (signal) on the semaphore from q48_semaphore_create_print_id.
 *
 * Compile : gcc q48_semaphore_v_operation.c -o q48_semaphore_v_operation
 * Run     : ./q48_semaphore_v_operation     (while ./q48_semaphore_p_operation is blocked in another terminal)
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <unistd.h>

#define SEM_KEY 0x4A48

int main(void)
{
    int id = semget(SEM_KEY, 1, 0666);
    if (id == -1) {
        perror("semget (run ./q48_semaphore_create_print_id first)");
        return 1;
    }
    struct sembuf v = { 0, +1, 0 };
    if (semop(id, &v, 1) == -1) {
        perror("semop V");
        return 1;
    }
    printf("PID %d: V done on semaphore id %d. Value = %d\n",
           (int)getpid(), id, semctl(id, 0, GETVAL));
    return 0;
}
