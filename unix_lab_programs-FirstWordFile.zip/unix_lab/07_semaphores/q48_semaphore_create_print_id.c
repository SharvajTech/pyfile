/*
 * PROBLEM STATEMENT
 * Q48. Write three programs: the first creates the semaphore and prints its
 *     id, the second performs P, the third performs V on the same semaphore.
 *     Run P first and show that it blocks until V is run.
 *
 * Q48 (program 1 of 3): create the semaphore (value 0) and print its id.
 *
 * Compile : gcc q48_semaphore_create_print_id.c -o q48_semaphore_create_print_id
 *           gcc q48_semaphore_p_operation.c      -o q48_semaphore_p_operation
 *           gcc q48_semaphore_v_operation.c      -o q48_semaphore_v_operation
 * Run     : Terminal 1: ./q48_semaphore_create_print_id        (prints the semaphore id)
 *           Terminal 1: ./q48_semaphore_p_operation             (P: BLOCKS because value is 0)
 *           Terminal 2: ./q48_semaphore_v_operation             (V: q48_semaphore_p_operation wakes up and finishes)
 * Check   : ipcs -s
 * Cleanup : ipcrm -s <id>
 *
 * All three programs find the same semaphore through the fixed key 0x4A48.
 */
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define SEM_KEY 0x4A48

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

int main(void)
{
    int id = semget(SEM_KEY, 1, IPC_CREAT | 0666);
    if (id == -1) { perror("semget"); return 1; }

    union semun a;
    a.val = 0;                              /* P will block until a V happens */
    if (semctl(id, 0, SETVAL, a) == -1) { perror("semctl"); return 1; }

    printf("Semaphore created: key = 0x%X, id = %d, value = %d\n",
           SEM_KEY, id, semctl(id, 0, GETVAL));
    printf("Now run ./q48_semaphore_p_operation, then ./q48_semaphore_v_operation. Remove with: ipcrm -s %d\n", id);
    return 0;
}
