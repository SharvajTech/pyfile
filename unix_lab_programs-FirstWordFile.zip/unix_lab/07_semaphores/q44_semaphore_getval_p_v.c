/*
 * PROBLEM STATEMENT
 * Q44. Create a semaphore with an initial value entered by the user. Print
 *     the value using semctl(GETVAL), then do one P and one V operation and
 *     print the value after each.
 *
 * Q44: System V semaphore with a user-supplied initial value.
 *      Print the value with semctl(GETVAL), do one P and one V, printing the
 *      value after each.
 *
 * Compile : gcc q44_semaphore_getval_p_v.c -o q44_semaphore_getval_p_v
 * Run     : ./q44_semaphore_getval_p_v          then enter e.g. 3
 *           (enter 0 to see that P would block; the program uses IPC_NOWAIT)
 * Check   : ipcs -s               (the semaphore is removed at the end)
 */
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

int main(void)
{
    int init;
    printf("Enter the initial semaphore value: ");
    if (scanf("%d", &init) != 1 || init < 0) {
        fprintf(stderr, "Invalid value\n");
        return 1;
    }

    int id = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    if (id == -1) { perror("semget"); return 1; }

    union semun arg;
    arg.val = init;
    if (semctl(id, 0, SETVAL, arg) == -1) { perror("semctl SETVAL"); return 1; }
    printf("Semaphore id = %d\n", id);
    printf("Initial value (GETVAL)    : %d\n", semctl(id, 0, GETVAL));

    struct sembuf p = { 0, -1, IPC_NOWAIT };    /* P (wait / decrement) */
    if (semop(id, &p, 1) == -1)
        printf("P operation failed: %s (value is 0, it would block)\n", strerror(errno));
    else
        printf("Value after P (decrement) : %d\n", semctl(id, 0, GETVAL));

    struct sembuf v = { 0, +1, 0 };             /* V (signal / increment) */
    if (semop(id, &v, 1) == -1)
        perror("semop V");
    else
        printf("Value after V (increment) : %d\n", semctl(id, 0, GETVAL));

    semctl(id, 0, IPC_RMID);
    printf("Semaphore removed.\n");
    return 0;
}
