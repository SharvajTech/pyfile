/*
 * PROBLEM STATEMENT
 * Q13. Measure the time taken to create 1000 child processes using fork()
 *     and then using vfork() (the child exits immediately). Compare the two
 *     times.
 *
 * Q13: Time to create 1000 children with fork() and with vfork().
 *
 * Compile : gcc q13_fork_vs_vfork_timing.c -o q13_fork_vs_vfork_timing
 * Run     : ./q13_fork_vs_vfork_timing          (parent touches 50 MB first)
 *           ./q13_fork_vs_vfork_timing 200      (use 200 MB; gap grows with size)
 *           ./q13_fork_vs_vfork_timing 0
 *
 * Why vfork() is faster: fork() must copy the parent's page tables (and mark
 * pages copy-on-write), so its cost grows with the parent's memory size.
 * vfork() shares the parent's address space and suspends the parent until
 * the child calls _exit()/exec, so nothing is copied.
 * The child of vfork() must only call _exit() or an exec function.
 */
#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define N 1000

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

int main(int argc, char *argv[])
{
    size_t mb = (argc > 1) ? (size_t)atoi(argv[1]) : 50;
    char *mem = NULL;
    if (mb > 0) {
        mem = malloc(mb * 1024 * 1024);
        if (!mem) { perror("malloc"); return 1; }
        memset(mem, 1, mb * 1024 * 1024);   /* touch pages so they are real */
    }
    printf("Parent memory touched: %zu MB, creating %d children each\n", mb, N);

    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0)
            _exit(0);
        waitpid(pid, NULL, 0);
    }
    double t_fork = now() - t0;

    t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t pid = vfork();
        if (pid < 0) { perror("vfork"); return 1; }
        if (pid == 0)
            _exit(0);
        waitpid(pid, NULL, 0);
    }
    double t_vfork = now() - t0;

    printf("fork() : %.4f s total, %.1f us per child\n", t_fork, t_fork / N * 1e6);
    printf("vfork(): %.4f s total, %.1f us per child\n", t_vfork, t_vfork / N * 1e6);
    if (t_vfork > 0)
        printf("fork() took %.2fx as long as vfork()\n", t_fork / t_vfork);
    free(mem);
    return 0;
}
