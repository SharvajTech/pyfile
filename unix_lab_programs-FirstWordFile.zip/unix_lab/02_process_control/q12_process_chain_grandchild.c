/*
 * PROBLEM STATEMENT
 * Q12. Create a chain of processes: parent, child and grandchild. Each
 *     prints its PID and PPID and waits for its own child.
 *
 * Q12: Chain of processes: parent -> child -> grandchild.
 *      Each prints its PID and PPID and waits for its own child.
 *
 * Compile : gcc q12_process_chain_grandchild.c -o q12_process_chain_grandchild
 * Run     : ./q12_process_chain_grandchild
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("Parent     : PID %d, PPID %d\n", (int)getpid(), (int)getppid());

    pid_t c = fork();
    if (c < 0) { perror("fork"); return 1; }
    if (c == 0) {
        printf("Child      : PID %d, PPID %d\n", (int)getpid(), (int)getppid());
        pid_t g = fork();
        if (g < 0) { perror("fork"); exit(1); }
        if (g == 0) {
            printf("Grandchild : PID %d, PPID %d\n", (int)getpid(), (int)getppid());
            exit(0);
        }
        waitpid(g, NULL, 0);
        printf("Child      : grandchild %d finished\n", (int)g);
        exit(0);
    }
    waitpid(c, NULL, 0);
    printf("Parent     : child %d finished\n", (int)c);
    return 0;
}
