/*
 * PROBLEM STATEMENT
 * Q14. Create three children, each running the same program with a different
 *     command-line argument. Print the exit status of each child using
 *     WEXITSTATUS.
 *
 * Q14 (worker program): exits with the status given as its argument.
 * Used by q14_three_children_exit_status.c.
 *
 * Compile : gcc q14_child_worker_exit_status.c -o q14_child_worker_exit_status
 * Run     : ./q14_child_worker_exit_status 5 ; echo $?
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int code = (argc > 1) ? atoi(argv[1]) : 0;
    printf("  worker PID %d started with argument %d\n", (int)getpid(), code);
    return code;
}
