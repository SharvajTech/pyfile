/*
 * PROBLEM STATEMENT
 * Q14. Create three children, each running the same program with a different
 *     command-line argument. Print the exit status of each child using
 *     WEXITSTATUS.
 *
 * Q14: Three children, each running the same program (q14_child_worker_exit_status) with a
 *      different command-line argument. The parent prints each child's exit
 *      status using WEXITSTATUS.
 *
 * Compile : gcc q14_child_worker_exit_status.c -o q14_child_worker_exit_status
 *           gcc q14_three_children_exit_status.c -o q14_three_children_exit_status
 * Run     : ./q14_three_children_exit_status        (run from the folder holding q14_child_worker_exit_status)
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *argsv[3] = { "10", "20", "30" };
    pid_t pids[3];

    for (int i = 0; i < 3; i++) {
        pids[i] = fork();
        if (pids[i] < 0) { perror("fork"); return 1; }
        if (pids[i] == 0) {
            execl("./q14_child_worker_exit_status", "q14_child_worker_exit_status", argsv[i], (char *)NULL);
            perror("execl (is q14_child_worker_exit_status compiled and in this folder?)");
            _exit(127);
        }
    }
    for (int i = 0; i < 3; i++) {
        int status;
        waitpid(pids[i], &status, 0);
        if (WIFEXITED(status))
            printf("Parent: child %d (arg %s) exit status = %d\n",
                   (int)pids[i], argsv[i], WEXITSTATUS(status));
        else
            printf("Parent: child %d did not exit normally\n", (int)pids[i]);
    }
    return 0;
}
