/*
 * PROBLEM STATEMENT
 * Q6. Create a child using fork(). The child prints even numbers from 1 to
 *     10 and the parent prints odd numbers. The parent must wait for the
 *     child before exiting.
 *
 * Q6: fork(); child prints even numbers 1..10, parent prints odd numbers.
 *     The parent waits for the child before exiting.
 *
 * Compile : gcc q06_fork_even_odd_parent_child.c -o q06_fork_even_odd_parent_child
 * Run     : ./q06_fork_even_odd_parent_child
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {
        for (int i = 2; i <= 10; i += 2) {
            printf("Child  (PID %d): %d\n", (int)getpid(), i);
            usleep(100000);
        }
        exit(0);
    }
    for (int i = 1; i <= 10; i += 2) {
        printf("Parent (PID %d): %d\n", (int)getpid(), i);
        usleep(100000);
    }
    waitpid(pid, NULL, 0);
    printf("Parent: child %d has finished, parent exiting.\n", (int)pid);
    return 0;
}
