/*
 * PROBLEM STATEMENT
 * Q10. Write a program that runs a command given on its command line (for
 *     example ./a.out wc -l file.txt) using execv().
 *
 * Q10: Run a command given on the command line using execv().
 *
 * Compile : gcc q10_run_command_execv.c -o q10_run_command_execv
 * Run     : ./q10_run_command_execv wc -l q10_run_command_execv.c
 *           ./q10_run_command_execv /bin/ls -l
 *           ./q10_run_command_execv echo hello world
 *
 * execv() does not search PATH, so the program looks the command up in PATH
 * itself and passes the full path to execv().
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int find_in_path(const char *cmd, char *out, size_t n)
{
    if (strchr(cmd, '/')) {
        snprintf(out, n, "%s", cmd);
        return access(out, X_OK);
    }
    const char *path = getenv("PATH");
    if (!path)
        path = "/bin:/usr/bin";
    char *copy = strdup(path), *save = NULL;
    if (!copy)
        return -1;
    for (char *d = strtok_r(copy, ":", &save); d; d = strtok_r(NULL, ":", &save)) {
        snprintf(out, n, "%s/%s", d, cmd);
        if (access(out, X_OK) == 0) {
            free(copy);
            return 0;
        }
    }
    free(copy);
    return -1;
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s command [args...]\n", argv[0]);
        return 1;
    }
    char full[1024];
    if (find_in_path(argv[1], full, sizeof full) != 0) {
        fprintf(stderr, "%s: command not found\n", argv[1]);
        return 127;
    }
    execv(full, &argv[1]);
    perror("execv");
    return 1;
}
