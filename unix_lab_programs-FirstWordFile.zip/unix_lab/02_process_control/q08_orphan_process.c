/*
 * PROBLEM STATEMENT
 * Q8. Create an orphan process: the parent exits before the child. The child
 *     prints its PPID before and after. Explain who adopts the orphan.
 *
 * Q8: Create an orphan process.
 *
 * Compile : gcc q08_orphan_process.c -o q08_orphan_process
 * Run     : ./q08_orphan_process
 *           (the shell prompt returns when the parent exits; the child's
 *            second message appears a few seconds later)
 * Check   : ps -o pid,ppid,cmd -p <child PID>
 *
 * Explanation:
 *   The parent exits while the child is still running, so the child becomes
 *   an orphan. The kernel re-parents it to init (PID 1, usually systemd on
 *   modern Linux). On systems with a "subreaper" (e.g. a desktop session's
 *   systemd --user, or a container's init) the adopting PID may be that
 *   process instead of 1. So the PPID printed after the parent dies is the
 *   PID of init/systemd (or the nearest subreaper), not the old parent.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {
        printf("Child : PID %d, PPID before = %d (original parent)\n",
               (int)getpid(), (int)getppid());
        sleep(3);               /* parent exits during this time */
        printf("Child : PID %d, PPID after  = %d (adopted by init/systemd)\n",
               (int)getpid(), (int)getppid());
        exit(0);
    }
    printf("Parent: PID %d exiting now, leaving child %d as an orphan\n",
           (int)getpid(), (int)pid);
    sleep(1);
    exit(0);
}
