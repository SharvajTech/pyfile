/*
 * PROBLEM STATEMENT
 * Q11. Write a mini shell: print a prompt, read a command, run it using
 *     fork(), exec and wait, and stop when the user types exit.
 *
 * Q11: A mini shell: prompt, read a command, fork(), exec and wait.
 *      Stops when the user types "exit". ("cd" is added as a built-in.)
 *
 * Compile : gcc q11_mini_shell.c -o q11_mini_shell
 * Run     : ./q11_mini_shell
 *           myshell> ls -l
 *           myshell> date
 *           myshell> exit
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    char line[1024];
    char *args[64];

    while (1) {
        printf("myshell> ");
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin)) {      /* Ctrl+D */
            putchar('\n');
            break;
        }
        line[strcspn(line, "\n")] = '\0';

        int n = 0;
        for (char *t = strtok(line, " \t"); t && n < 63; t = strtok(NULL, " \t"))
            args[n++] = t;
        args[n] = NULL;

        if (n == 0)
            continue;
        if (strcmp(args[0], "exit") == 0)
            break;
        if (strcmp(args[0], "cd") == 0) {
            if (chdir(n > 1 ? args[1] : getenv("HOME")) != 0)
                perror("cd");
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
        } else if (pid == 0) {
            execvp(args[0], args);
            perror(args[0]);
            _exit(127);
        } else {
            int status;
            waitpid(pid, &status, 0);
        }
    }
    return 0;
}
