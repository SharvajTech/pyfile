/*
 * PROBLEM STATEMENT
 * Q9. The parent creates two children. Child 1 runs ls -l using execl() and
 *     child 2 runs date using execvp(). The parent waits for child 2 first
 *     and then child 1 using waitpid().
 *
 * Q9: Two children: child 1 runs "ls -l" with execl(), child 2 runs "date"
 *     with execvp(). The parent waits for child 2 first, then child 1,
 *     using waitpid().
 *
 * Compile : gcc q09_two_children_execl_execvp_waitpid.c -o q09_two_children_execl_execvp_waitpid
 * Run     : ./q09_two_children_execl_execvp_waitpid
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    int status;

    pid_t c1 = fork();
    if (c1 < 0) { perror("fork"); return 1; }
    if (c1 == 0) {
        execl("/bin/ls", "ls", "-l", (char *)NULL);
        perror("execl");
        _exit(127);
    }

    pid_t c2 = fork();
    if (c2 < 0) { perror("fork"); return 1; }
    if (c2 == 0) {
        char *args[] = { "date", NULL };
        execvp("date", args);
        perror("execvp");
        _exit(127);
    }

    waitpid(c2, &status, 0);
    printf("Parent: child 2 (date, PID %d) finished, status %d\n",
           (int)c2, WEXITSTATUS(status));
    waitpid(c1, &status, 0);
    printf("Parent: child 1 (ls -l, PID %d) finished, status %d\n",
           (int)c1, WEXITSTATUS(status));
    return 0;
}
