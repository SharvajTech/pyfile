/*
 * PROBLEM STATEMENT
 * Q7. Create a zombie process: the child exits at once and the parent sleeps
 *     for 30 seconds without calling wait(). Show the zombie with ps and
 *     explain how it is removed.
 *
 * Q7: Create a zombie process.
 *
 * Compile : gcc q07_zombie_process.c -o q07_zombie_process
 * Run     : ./q07_zombie_process &
 * Show    : (within 30 seconds, in the same or another terminal)
 *             ps -o pid,ppid,stat,cmd --ppid <parent PID>
 *             ps aux | grep defunct
 *           The child shows state "Z" and "<defunct>".
 *
 * Explanation:
 *   The child called exit(), so its memory is freed, but the kernel keeps its
 *   process-table entry (PID, exit status) until the parent reads it with
 *   wait()/waitpid(). The parent never calls wait(), so the child stays a
 *   zombie for the whole 30 seconds.
 *   It is removed when:
 *     (a) the parent calls wait()/waitpid() (reaps it), or
 *     (b) the parent exits: the zombie is re-parented to init/systemd
 *         (PID 1), which reaps it automatically. That is what happens here
 *         after the 30 s sleep.
 *   Note: a zombie cannot be killed with kill -9, it is already dead.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {
        printf("Child  PID %d exiting immediately\n", (int)getpid());
        exit(0);
    }
    printf("Parent PID %d sleeping 30 s without calling wait()\n", (int)getpid());
    printf("Run: ps -o pid,ppid,stat,cmd --ppid %d\n", (int)getpid());
    sleep(30);
    printf("Parent exiting; init/systemd will now reap the zombie.\n");
    return 0;
}
