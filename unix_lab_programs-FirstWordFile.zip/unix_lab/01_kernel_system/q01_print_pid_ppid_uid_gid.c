/*
 * PROBLEM STATEMENT
 * Q1. Write a C program that prints its own PID, PPID, UID and GID. Verify
 *     the values with the ps and id commands.
 *
 * Q1: Print PID, PPID, UID and GID; verify with ps and id.
 *
 * Compile : gcc q01_print_pid_ppid_uid_gid.c -o q01_print_pid_ppid_uid_gid
 * Run     : ./q01_print_pid_ppid_uid_gid &
 * Verify  : ps -o pid,ppid,uid,gid,cmd -p <PID printed by the program>
 *           id            (compare uid= and gid= with the program output)
 *           echo $$       (PPID printed should be your shell's PID)
 */
#include <stdio.h>
#include <unistd.h>

int main(void)
{
    printf("PID  = %d\n", (int)getpid());
    printf("PPID = %d\n", (int)getppid());
    printf("UID  = %d\n", (int)getuid());
    printf("GID  = %d\n", (int)getgid());
    printf("Sleeping 30 s. In another terminal run:\n"
           "  ps -o pid,ppid,uid,gid,cmd -p %d\n", (int)getpid());
    fflush(stdout);
    sleep(30);
    return 0;
}
