/*
 * PROBLEM STATEMENT
 * Q3. Write a C program that prints the number of CPU cores and the memory
 *     page size using sysconf().
 *
 * Q3: Number of CPU cores and memory page size using sysconf().
 *
 * Compile : gcc q03_cpu_cores_page_size_sysconf.c -o q03_cpu_cores_page_size_sysconf
 * Run     : ./q03_cpu_cores_page_size_sysconf
 * Compare : nproc ; getconf PAGESIZE
 */
#include <stdio.h>
#include <unistd.h>

int main(void)
{
    long online = sysconf(_SC_NPROCESSORS_ONLN);
    long conf   = sysconf(_SC_NPROCESSORS_CONF);
    long page   = sysconf(_SC_PAGESIZE);
    long pages  = sysconf(_SC_PHYS_PAGES);

    printf("CPU cores online     : %ld\n", online);
    printf("CPU cores configured : %ld\n", conf);
    printf("Page size            : %ld bytes\n", page);
    if (pages > 0)
        printf("Physical memory      : %.2f MB\n",
               (double)pages * (double)page / (1024.0 * 1024.0));
    return 0;
}
