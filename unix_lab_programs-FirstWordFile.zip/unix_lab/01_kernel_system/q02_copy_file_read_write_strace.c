/*
 * PROBLEM STATEMENT
 * Q2. Write a C program that copies a file to the screen using read() and
 *     write(). Run it under strace and list the system calls in the order
 *     they appear.
 *
 * Q2: Copy a file to the screen using read() and write(); trace with strace.
 *
 * Compile : gcc q02_copy_file_read_write_strace.c -o q02_copy_file_read_write_strace
 * Run     : echo "hello unix" > sample.txt
 *           ./q02_copy_file_read_write_strace sample.txt
 * Trace   : strace ./q02_copy_file_read_write_strace sample.txt 2> trace.txt
 *           (or: strace -e trace=openat,read,write,close ./q02_copy_file_read_write_strace sample.txt)
 *
 * Typical order of system calls in the strace output:
 *   1. execve        - the shell starts the program
 *   2. brk / mmap / access / openat (libc.so.6) / read / fstat / mmap /
 *      close / mprotect / munmap ... - dynamic loader and libc start-up
 *   3. openat("sample.txt", O_RDONLY)  - our open()
 *   4. read(3, "hello unix\n", 4096) = 11  - first read()
 *   5. write(1, "hello unix\n", 11) = 11   - write() to stdout (fd 1)
 *   6. read(3, "", 4096) = 0               - end of file
 *   7. close(3)
 *   8. exit_group(0)
 * (Exact start-up calls differ between systems.)
 */
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s file\n", argv[0]);
        return 1;
    }
    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }
    char buf[4096];
    ssize_t n;
    while ((n = read(fd, buf, sizeof buf)) > 0) {
        if (write(STDOUT_FILENO, buf, (size_t)n) != n) {
            perror("write");
            close(fd);
            return 1;
        }
    }
    if (n < 0)
        perror("read");
    close(fd);
    return 0;
}
