/*
 * PROBLEM STATEMENT
 * Q4. Write a C program that uses uname() to print the OS name, kernel
 *     release and machine type. Compare it with the uname -a command.
 *
 * Q4: OS name, kernel release and machine type using uname().
 *
 * Compile : gcc q04_os_kernel_machine_uname.c -o q04_os_kernel_machine_uname
 * Run     : ./q04_os_kernel_machine_uname
 * Compare : uname -a      (also: uname -s, uname -r, uname -m)
 *   sysname  <-> uname -s     release <-> uname -r     machine <-> uname -m
 */
#include <stdio.h>
#include <sys/utsname.h>

int main(void)
{
    struct utsname u;
    if (uname(&u) == -1) {
        perror("uname");
        return 1;
    }
    printf("OS name        : %s\n", u.sysname);
    printf("Node name      : %s\n", u.nodename);
    printf("Kernel release : %s\n", u.release);
    printf("Kernel version : %s\n", u.version);
    printf("Machine type   : %s\n", u.machine);
    printf("\nCompare with the output of: uname -a\n");
    return 0;
}
