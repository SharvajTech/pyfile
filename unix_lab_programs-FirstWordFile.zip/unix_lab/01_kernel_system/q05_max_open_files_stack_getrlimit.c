/*
 * PROBLEM STATEMENT
 * Q5. Write a C program that uses getrlimit() to print the maximum number of
 *     open files and the stack size allowed for the process.
 *
 * Q5: Maximum open files and stack size using getrlimit().
 *
 * Compile : gcc q05_max_open_files_stack_getrlimit.c -o q05_max_open_files_stack_getrlimit
 * Run     : ./q05_max_open_files_stack_getrlimit
 * Compare : ulimit -n ; ulimit -s     (soft limits, stack in KB)
 *           ulimit -Hn ; ulimit -Hs   (hard limits)
 */
#include <stdio.h>
#include <sys/resource.h>

static void show(const char *name, int res, const char *unit)
{
    struct rlimit r;
    if (getrlimit(res, &r) == -1) {
        perror("getrlimit");
        return;
    }
    printf("%s\n", name);
    if (r.rlim_cur == RLIM_INFINITY)
        printf("  soft limit : unlimited\n");
    else
        printf("  soft limit : %llu %s\n", (unsigned long long)r.rlim_cur, unit);
    if (r.rlim_max == RLIM_INFINITY)
        printf("  hard limit : unlimited\n");
    else
        printf("  hard limit : %llu %s\n", (unsigned long long)r.rlim_max, unit);
}

int main(void)
{
    show("Maximum open files (RLIMIT_NOFILE)", RLIMIT_NOFILE, "files");
    show("Stack size (RLIMIT_STACK)", RLIMIT_STACK, "bytes");
    return 0;
}
