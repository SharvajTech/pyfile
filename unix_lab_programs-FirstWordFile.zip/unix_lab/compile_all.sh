#!/bin/bash
# Compile every C program in unix_lab. Run from the unix_lab folder:
#     chmod +x compile_all.sh && ./compile_all.sh
# Each q??_name.c becomes an executable q??_name in the same folder.
# Remove them again with:  ./compile_all.sh clean
cd "$(dirname "$0")" || exit 1

if [ "$1" = "clean" ]; then
    for f in 0*/*.c; do rm -f "${f%.c}"; done
    echo "Executables removed."
    exit 0
fi

ok=0; bad=0
for f in 0*/*.c; do
    if gcc -Wall -Wextra -o "${f%.c}" "$f" -pthread 2>/tmp/gcc_err.txt; then
        ok=$((ok+1))
    else
        bad=$((bad+1)); echo "FAILED: $f"; cat /tmp/gcc_err.txt
    fi
done
echo "Compiled OK: $ok   Failed: $bad"
