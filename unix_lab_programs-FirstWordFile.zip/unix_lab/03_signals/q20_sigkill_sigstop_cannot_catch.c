/*
 * PROBLEM STATEMENT
 * Q20. Show that SIGKILL and SIGSTOP cannot be caught: try to register
 *     handlers for them and print the return value and the error message.
 *
 * Q20: SIGKILL and SIGSTOP cannot be caught.
 *      Try to register handlers; print the return value and error message.
 *
 * Compile : gcc q20_sigkill_sigstop_cannot_catch.c -o q20_sigkill_sigstop_cannot_catch
 * Run     : ./q20_sigkill_sigstop_cannot_catch
 * Expected: both calls return -1 with errno = EINVAL ("Invalid argument").
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

static void handler(int sig) { (void)sig; }

static void try_catch(int sig, const char *name)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);

    int rc = sigaction(sig, &sa, NULL);
    printf("sigaction(%s): return value = %d", name, rc);
    if (rc == -1)
        printf(", errno = %d (%s)", errno, strerror(errno));
    printf("\n");

    errno = 0;
    if (signal(sig, handler) == SIG_ERR)
        printf("signal(%s)   : returned SIG_ERR, errno = %d (%s)\n",
               name, errno, strerror(errno));
}

int main(void)
{
    try_catch(SIGKILL, "SIGKILL");
    try_catch(SIGSTOP, "SIGSTOP");
    printf("Neither SIGKILL nor SIGSTOP can be caught, blocked or ignored.\n");
    return 0;
}
