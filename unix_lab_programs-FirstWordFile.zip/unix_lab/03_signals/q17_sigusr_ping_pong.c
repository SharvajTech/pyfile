/*
 * PROBLEM STATEMENT
 * Q17. The parent and child play ping-pong: the parent sends SIGUSR1, the
 *     child replies with SIGUSR2. Repeat for five rounds.
 *
 * Q17: Parent and child play ping-pong with signals.
 *      Parent sends SIGUSR1, child replies with SIGUSR2; five rounds.
 *
 * Compile : gcc q17_sigusr_ping_pong.c -o q17_sigusr_ping_pong
 * Run     : ./q17_sigusr_ping_pong
 */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static volatile sig_atomic_t got1 = 0, got2 = 0;

static void h1(int s) { (void)s; got1 = 1; }
static void h2(int s) { (void)s; got2 = 1; }

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);
    sa.sa_handler = h1;
    sigaction(SIGUSR1, &sa, NULL);
    sa.sa_handler = h2;
    sigaction(SIGUSR2, &sa, NULL);

    /* Block both signals before fork so none can be lost. */
    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGUSR1);
    sigaddset(&block, SIGUSR2);
    sigprocmask(SIG_BLOCK, &block, &old);

    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }

    if (pid == 0) {                         /* child: waits for ping, sends pong */
        pid_t parent = getppid();
        for (int r = 1; r <= 5; r++) {
            while (!got1)
                sigsuspend(&old);
            got1 = 0;
            printf("        child : got SIGUSR1 (ping %d), replying SIGUSR2\n", r);
            kill(parent, SIGUSR2);
        }
        exit(0);
    }

    for (int r = 1; r <= 5; r++) {          /* parent: sends ping, waits for pong */
        printf("parent: round %d, sending SIGUSR1\n", r);
        kill(pid, SIGUSR1);
        while (!got2)
            sigsuspend(&old);
        got2 = 0;
        printf("parent: got SIGUSR2 (pong %d)\n", r);
    }
    waitpid(pid, NULL, 0);
    printf("Ping-pong finished.\n");
    return 0;
}
