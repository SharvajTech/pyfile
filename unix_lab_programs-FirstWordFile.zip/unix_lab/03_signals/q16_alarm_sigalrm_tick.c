/*
 * PROBLEM STATEMENT
 * Q16. Use alarm() and a SIGALRM handler so that the program prints "tick"
 *     every 2 seconds, five times, and then exits.
 *
 * Q16: alarm() + SIGALRM handler: print "tick" every 2 seconds, five times.
 *
 * Compile : gcc q16_alarm_sigalrm_tick.c -o q16_alarm_sigalrm_tick
 * Run     : ./q16_alarm_sigalrm_tick
 */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t ticked = 0;

static void handler(int sig)
{
    (void)sig;
    ticked = 1;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGALRM, &sa, NULL);

    /* Block SIGALRM, then wait with sigsuspend() so no alarm is ever missed. */
    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGALRM);
    sigprocmask(SIG_BLOCK, &block, &old);

    for (int i = 1; i <= 5; i++) {
        alarm(2);
        while (!ticked)
            sigsuspend(&old);
        ticked = 0;
        printf("tick (%d)\n", i);
        fflush(stdout);
    }
    printf("Done.\n");
    return 0;
}
