/*
 * PROBLEM STATEMENT
 * Q22. The parent creates three children that sleep for different times.
 *     Reap them inside a SIGCHLD handler using waitpid() with WNOHANG.
 *
 * Q22: Three children sleep for different times. The parent reaps them in a
 *      SIGCHLD handler using waitpid() with WNOHANG.
 *
 * Compile : gcc q22_sigchld_handler_waitpid_wnohang.c -o q22_sigchld_handler_waitpid_wnohang
 * Run     : ./q22_sigchld_handler_waitpid_wnohang
 *
 * The handler loops with WNOHANG because several SIGCHLDs can be merged into
 * one signal; the loop reaps every child that has already finished.
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static volatile sig_atomic_t nreaped = 0;
static volatile pid_t rpid[3];
static volatile int rstat[3];

static void handler(int sig)
{
    (void)sig;
    int saved = errno, st;
    pid_t p;
    while ((p = waitpid(-1, &st, WNOHANG)) > 0) {
        if (nreaped < 3) {
            rpid[nreaped] = p;
            rstat[nreaped] = st;
        }
        nreaped++;
    }
    errno = saved;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    int delays[3] = { 1, 3, 5 };
    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
            printf("Child %d (PID %d) sleeping %d s\n", i + 1, (int)getpid(), delays[i]);
            sleep(delays[i]);
            exit(i + 1);
        }
    }

    while (nreaped < 3) {
        printf("Parent: doing other work, reaped so far = %d\n", (int)nreaped);
        sleep(1);                           /* interrupted early by SIGCHLD */
    }
    for (int i = 0; i < 3; i++)
        printf("Reaped child PID %d, exit status %d\n",
               (int)rpid[i], WEXITSTATUS(rstat[i]));
    printf("All children reaped inside the SIGCHLD handler.\n");
    return 0;
}
