/*
 * PROBLEM STATEMENT
 * Q19. Write one program that prints its PID and waits with pause(). Write a
 *     second program that takes the PID as an argument and sends SIGUSR1
 *     using kill().
 *
 * Q19 (program 2 of 2): send SIGUSR1 to the PID given as argument, using kill().
 *
 * Compile : gcc q19_kill_send_sigusr1_sender.c -o q19_kill_send_sigusr1_sender
 * Run     : ./q19_kill_send_sigusr1_sender <PID of q19_pause_wait_sigusr1_receiver>
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <pid>\n", argv[0]);
        return 1;
    }
    pid_t pid = (pid_t)atoi(argv[1]);
    if (kill(pid, SIGUSR1) == -1) {
        fprintf(stderr, "kill failed: %s\n", strerror(errno));
        return 1;
    }
    printf("Sent SIGUSR1 to PID %d\n", (int)pid);
    return 0;
}
