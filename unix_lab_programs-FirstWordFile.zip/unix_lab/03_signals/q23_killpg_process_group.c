/*
 * PROBLEM STATEMENT
 * Q23. Create three children in the same process group. The parent sends
 *     SIGUSR1 to the whole group using killpg() and each child prints its
 *     PID in the handler.
 *
 * Q23: Three children in the same process group. The parent sends SIGUSR1 to
 *      the whole group with killpg(); each child prints its PID in the handler.
 *
 * Compile : gcc q23_killpg_process_group.c -o q23_killpg_process_group
 * Run     : ./q23_killpg_process_group
 *
 * Child 1 becomes the group leader (pgid = its PID); children 2 and 3 join
 * that group. The parent is NOT in the group, so it does not get the signal.
 * (snprintf in the handler is not strictly async-signal-safe; it is used
 *  here for readability in a short demo.)
 */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static volatile sig_atomic_t got = 0;

static void handler(int sig)
{
    (void)sig;
    char buf[96];
    int n = snprintf(buf, sizeof buf, "  [handler] child PID %d (pgid %d) got SIGUSR1\n",
                     (int)getpid(), (int)getpgrp());
    write(STDOUT_FILENO, buf, (size_t)n);
    got = 1;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);

    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGUSR1);
    sigprocmask(SIG_BLOCK, &block, &old);   /* children inherit: no lost signal */

    pid_t leader = 0;
    pid_t kids[3];
    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
            setpgid(0, i == 0 ? 0 : leader);
            while (!got)
                sigsuspend(&old);
            exit(0);
        }
        kids[i] = pid;
        if (i == 0)
            leader = pid;
        setpgid(pid, leader);               /* also set by parent to avoid a race */
    }

    printf("Parent PID %d (pgid %d); children group id = %d\n",
           (int)getpid(), (int)getpgrp(), (int)leader);
    sleep(1);
    printf("Parent: killpg(%d, SIGUSR1)\n", (int)leader);
    if (killpg(leader, SIGUSR1) == -1)
        perror("killpg");

    for (int i = 0; i < 3; i++)
        waitpid(kids[i], NULL, 0);
    printf("Parent: all three children finished.\n");
    return 0;
}
