/*
 * PROBLEM STATEMENT
 * Q19. Write one program that prints its PID and waits with pause(). Write a
 *     second program that takes the PID as an argument and sends SIGUSR1
 *     using kill().
 *
 * Q19 (program 1 of 2): print own PID and wait with pause() for SIGUSR1.
 *
 * Compile : gcc q19_pause_wait_sigusr1_receiver.c -o q19_pause_wait_sigusr1_receiver
 *           gcc q19_kill_send_sigusr1_sender.c   -o q19_kill_send_sigusr1_sender
 * Run     : Terminal 1: ./q19_pause_wait_sigusr1_receiver          (note the PID it prints)
 *           Terminal 2: ./q19_kill_send_sigusr1_sender <PID>
 */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t got = 0;

static void handler(int sig)
{
    (void)sig;
    got = 1;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);

    printf("Receiver PID = %d, waiting for SIGUSR1 with pause()...\n", (int)getpid());
    fflush(stdout);
    while (!got)
        pause();
    printf("Receiver: SIGUSR1 received, exiting.\n");
    return 0;
}
