/*
 * PROBLEM STATEMENT
 * Q18. Ignore SIGINT using SIG_IGN for 10 seconds and then restore the
 *     default action using SIG_DFL. Show the behaviour before and after.
 *
 * Q18: Ignore SIGINT (SIG_IGN) for 10 s, then restore SIG_DFL.
 *
 * Compile : gcc q18_sigint_ignore_then_default.c -o q18_sigint_ignore_then_default
 * Run     : ./q18_sigint_ignore_then_default
 *   Phase 1 (10 s): press Ctrl+C -> nothing happens (signal ignored).
 *   Phase 2 (10 s): press Ctrl+C -> program is killed (default action).
 */
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);

    signal(SIGINT, SIG_IGN);
    printf("Phase 1: SIGINT is IGNORED for 10 s. Try pressing Ctrl+C...\n");
    sleep(10);

    signal(SIGINT, SIG_DFL);
    printf("Phase 2: default action restored for 10 s. Press Ctrl+C to terminate.\n");
    sleep(10);

    printf("You did not press Ctrl+C in phase 2, so the program ends normally.\n");
    return 0;
}
