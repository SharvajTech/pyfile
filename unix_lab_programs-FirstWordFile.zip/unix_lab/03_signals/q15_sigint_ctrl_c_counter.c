/*
 * PROBLEM STATEMENT
 * Q15. Catch SIGINT and print how many times Ctrl+C has been pressed.
 *     Terminate the program on the fourth press.
 *
 * Q15: Catch SIGINT and count Ctrl+C presses; terminate on the 4th press.
 *
 * Compile : gcc q15_sigint_ctrl_c_counter.c -o q15_sigint_ctrl_c_counter
 * Run     : ./q15_sigint_ctrl_c_counter      then press Ctrl+C four times
 */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t count = 0;

static void handler(int sig)
{
    (void)sig;
    count++;
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("sigaction");
        return 1;
    }
    printf("PID %d: press Ctrl+C (program ends on the 4th press)\n", (int)getpid());
    while (1) {
        pause();
        printf("Ctrl+C pressed %d time(s)\n", (int)count);
        if (count >= 4) {
            printf("Fourth Ctrl+C - terminating.\n");
            break;
        }
    }
    return 0;
}
