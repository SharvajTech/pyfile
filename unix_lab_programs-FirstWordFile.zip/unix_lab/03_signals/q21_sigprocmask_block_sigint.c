/*
 * PROBLEM STATEMENT
 * Q21. Block SIGINT using sigprocmask() during a 5-second critical section.
 *     Press Ctrl+C during that time and show that the signal is delivered
 *     after it is unblocked.
 *
 * Q21: Block SIGINT with sigprocmask() during a 5-second critical section.
 *      Press Ctrl+C during that time; the signal is delivered only after
 *      it is unblocked.
 *
 * Compile : gcc q21_sigprocmask_block_sigint.c -o q21_sigprocmask_block_sigint
 * Run     : ./q21_sigprocmask_block_sigint      and press Ctrl+C within the 5 seconds
 */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static void handler(int sig)
{
    (void)sig;
    const char msg[] = "  [handler] SIGINT delivered NOW (after unblocking)\n";
    write(STDOUT_FILENO, msg, sizeof msg - 1);
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);

    sigset_t block, old;
    sigemptyset(&block);
    sigaddset(&block, SIGINT);

    sigprocmask(SIG_BLOCK, &block, &old);
    printf("Critical section: SIGINT BLOCKED for 5 s. Press Ctrl+C now...\n");
    sleep(5);

    sigset_t pending;
    sigpending(&pending);
    printf("End of critical section. SIGINT pending? %s\n",
           sigismember(&pending, SIGINT) ? "YES" : "no");

    printf("Unblocking SIGINT...\n");
    sigprocmask(SIG_SETMASK, &old, NULL);   /* pending signal is delivered here */
    printf("After unblock. Program finished.\n");
    return 0;
}
