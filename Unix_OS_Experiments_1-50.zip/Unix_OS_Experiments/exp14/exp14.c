/* Q14. Implement a UDP client-server program where the client sends numbers and the
 *      server responds with their factorial.
 * Compile: gcc exp14.c -o exp14
 * Run    : Terminal 1: ./exp14 server      Terminal 2: ./exp14 client
 *          (enter numbers 0-20, Ctrl+D to stop)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 9001
unsigned long long fact(unsigned int n) { return n <= 1 ? 1 : n * fact(n - 1); }
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server|client\n", argv[0]); return 1; }
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(PORT);
    if (strcmp(argv[1], "server") == 0) {
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        bind(sock, (struct sockaddr *)&addr, sizeof(addr));
        printf("UDP factorial server on port %d\n", PORT);
        while (1) {
            unsigned int n; struct sockaddr_in cli; socklen_t len = sizeof(cli);
            recvfrom(sock, &n, sizeof(n), 0, (struct sockaddr *)&cli, &len);
            unsigned long long r = fact(n);
            printf("Computed %u! = %llu\n", n, r);
            sendto(sock, &r, sizeof(r), 0, (struct sockaddr *)&cli, len);
        }
    }
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    unsigned int n; unsigned long long r;
    while (scanf("%u", &n) == 1) {
        sendto(sock, &n, sizeof(n), 0, (struct sockaddr *)&addr, sizeof(addr));
        recvfrom(sock, &r, sizeof(r), 0, NULL, NULL);
        printf("%u! = %llu\n", n, r);
    }
    close(sock);
    return 0;
}
