/* Q9. Write a program where one process writes characters A-Z into shared memory,
 *     and another process writes the same data into a file.
 * Compile: gcc exp09.c -o exp09
 * Run    : ./exp09        (creates output9.txt)
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#define KEY 0x0909
#define N 26
int main(void) {
    int id = shmget(KEY, N + 1, 0666 | IPC_CREAT);
    char *shm = shmat(id, NULL, 0);
    for (int i = 0; i < N; i++) shm[i] = 'A' + i;      /* Process 1: write to shm */
    shm[N] = '\0';
    printf("Process 1 wrote to shared memory: %s\n", shm);
    if (fork() == 0) {                                  /* Process 2: shm -> file */
        FILE *fp = fopen("output9.txt", "w");
        fprintf(fp, "%s\n", shm);
        fclose(fp);
        printf("Process 2 wrote data to output9.txt\n");
        exit(0);
    }
    wait(NULL);
    shmdt(shm); shmctl(id, IPC_RMID, NULL);
    return 0;
}
