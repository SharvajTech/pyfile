/* Q17. Priority-based messaging: Implement a system where multiple clients send
 *      messages with different priorities, and the server displays them in priority order.
 * Compile: gcc exp17.c -o exp17
 * Run    : ./exp17 send 3 "Normal message"
 *          ./exp17 send 1 "Urgent message"
 *          ./exp17 recv          (server: displays in priority order, 1 = highest)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#define KEY 0x1701
#define MAXPRIO 10
struct msg { long mtype; char text[100]; };
int main(int argc, char *argv[]) {
    int qid = msgget(KEY, 0666 | IPC_CREAT);
    struct msg m;
    if (argc == 4 && strcmp(argv[1], "send") == 0) {          /* client */
        int p = atoi(argv[2]);
        if (p < 1 || p > MAXPRIO) { printf("Priority must be 1-%d\n", MAXPRIO); return 1; }
        m.mtype = p;
        strncpy(m.text, argv[3], 99); m.text[99] = '\0';
        msgsnd(qid, &m, strlen(m.text) + 1, 0);
        printf("Sent [prio %d]: %s\n", p, m.text);
    } else if (argc == 2 && strcmp(argv[1], "recv") == 0) {   /* server */
        printf("Messages in priority order:\n");
        /* -MAXPRIO => returns the lowest type <= MAXPRIO first (highest priority) */
        while (msgrcv(qid, &m, sizeof(m.text), -MAXPRIO, IPC_NOWAIT) != -1)
            printf("[prio %ld] %s\n", m.mtype, m.text);
        msgctl(qid, IPC_RMID, NULL);
    } else {
        printf("Usage:\n  %s send <1-10> \"message\"\n  %s recv\n", argv[0], argv[0]);
    }
    return 0;
}
