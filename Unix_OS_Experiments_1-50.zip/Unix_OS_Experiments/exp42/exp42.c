/* Q42. Create a program that spawns three threads: one prints even numbers, another
 *      prints odd numbers, and the third prints prime numbers.
 * Compile: gcc -pthread exp42.c -o exp42
 * Run    : ./exp42 20
 */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
int N;
static int is_prime(int n) { if (n < 2) return 0; for (int i = 2; i * i <= n; i++) if (n % i == 0) return 0; return 1; }
void *print_even(void *a)  { (void)a; for (int i = 2; i <= N; i += 2) printf("[Even ] %d\n", i); return NULL; }
void *print_odd(void *a)   { (void)a; for (int i = 1; i <= N; i += 2) printf("[Odd  ] %d\n", i); return NULL; }
void *print_prime(void *a) { (void)a; for (int i = 2; i <= N; i++) if (is_prime(i)) printf("[Prime] %d\n", i); return NULL; }
int main(int argc, char *argv[]) {
    N = argc > 1 ? atoi(argv[1]) : 20;
    pthread_t t[3];
    pthread_create(&t[0], NULL, print_even, NULL);
    pthread_create(&t[1], NULL, print_odd, NULL);
    pthread_create(&t[2], NULL, print_prime, NULL);
    for (int i = 0; i < 3; i++) pthread_join(t[i], NULL);
    return 0;
}
