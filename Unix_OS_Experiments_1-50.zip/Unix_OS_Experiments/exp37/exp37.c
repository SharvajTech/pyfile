/* Q37. Implement a program that uses alarm() and signal handling to require user input
 *      within a specified time limit.
 * Compile: gcc exp37.c -o exp37
 * Run    : ./exp37
 */
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
volatile sig_atomic_t timed_out = 0;
static void on_alarm(int sig) { (void)sig; timed_out = 1; }
int main(void) {
    char buf[100];
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_alarm;
    sa.sa_flags = 0;                       /* no SA_RESTART: fgets is interrupted */
    sigaction(SIGALRM, &sa, NULL);
    printf("Enter your name within 5 seconds: "); fflush(stdout);
    alarm(5);
    if (fgets(buf, sizeof(buf), stdin) != NULL && !timed_out) {
        alarm(0);
        buf[strcspn(buf, "\n")] = '\0';
        printf("Hello, %s!\n", buf);
    } else {
        printf("\nTime's up! No input received.\n");
    }
    return 0;
}
