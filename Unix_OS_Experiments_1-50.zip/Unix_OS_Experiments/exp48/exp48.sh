#!/bin/bash
# Q48. Write a shell script to sort ten given numbers in ascending order.
# Run: chmod +x exp48.sh && ./exp48.sh
nums=()
for i in $(seq 1 10); do
    read -p "Enter number $i: " n
    nums+=("$n")
done
# bubble sort (ascending)
for ((i = 0; i < 9; i++)); do
    for ((j = 0; j < 9 - i; j++)); do
        if (( nums[j] > nums[j+1] )); then
            t=${nums[j]}; nums[j]=${nums[j+1]}; nums[j+1]=$t
        fi
    done
done
echo "Sorted (ascending): ${nums[*]}"
