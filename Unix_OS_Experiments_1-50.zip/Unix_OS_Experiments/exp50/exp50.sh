#!/bin/bash
# Q50. Write a shell script that checks whether a specified file exists in a given
#      folder or drive.
# Run: chmod +x exp50.sh && ./exp50.sh <folder_or_drive_path> <filename>
#      e.g. ./exp50.sh /etc passwd
if [ $# -ne 2 ]; then echo "Usage: $0 <folder> <filename>"; exit 1; fi
if [ -f "$1/$2" ]; then
    echo "File '$2' EXISTS in '$1'"
else
    echo "File '$2' NOT found in '$1'"
fi
