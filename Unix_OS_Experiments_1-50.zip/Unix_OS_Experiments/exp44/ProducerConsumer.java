// Q44. Implement the producer-consumer problem using multithreading in Java.
// Compile: javac ProducerConsumer.java
// Run    : java ProducerConsumer

class Buffer {
    private final int[] data = new int[5];
    private int count = 0, in = 0, out = 0;

    synchronized void put(int v) throws InterruptedException {
        while (count == data.length) wait();
        data[in] = v; in = (in + 1) % data.length; count++;
        System.out.println("Produced " + v);
        notifyAll();
    }

    synchronized int get() throws InterruptedException {
        while (count == 0) wait();
        int v = data[out]; out = (out + 1) % data.length; count--;
        System.out.println("Consumed " + v);
        notifyAll();
        return v;
    }
}

public class ProducerConsumer {
    public static void main(String[] args) {
        Buffer b = new Buffer();
        Thread producer = new Thread(() -> {
            try { for (int i = 1; i <= 10; i++) b.put(i * i); } catch (InterruptedException e) { }
        });
        Thread consumer = new Thread(() -> {
            try { for (int i = 1; i <= 10; i++) b.get(); } catch (InterruptedException e) { }
        });
        producer.start();
        consumer.start();
    }
}
