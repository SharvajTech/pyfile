#!/bin/bash
# Q45. Write a shell script that implements a simple calculator.
# Run: chmod +x exp45.sh && ./exp45.sh
read -p "Enter first number: " a
read -p "Enter operator (+, -, x, /, %): " op
read -p "Enter second number: " b
case "$op" in
    +) echo "Result: $((a + b))" ;;
    -) echo "Result: $((a - b))" ;;
    x|\*) echo "Result: $((a * b))" ;;
    /) if [ "$b" -eq 0 ]; then echo "Error: division by zero"
       else echo "Result: $(awk -v a="$a" -v b="$b" 'BEGIN{printf "%.2f", a/b}')"; fi ;;
    %) echo "Result: $((a % b))" ;;
    *) echo "Invalid operator" ;;
esac
