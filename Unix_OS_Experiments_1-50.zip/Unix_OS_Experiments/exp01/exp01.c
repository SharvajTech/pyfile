/* Q1. Write a program to transfer the contents of a file from the parent process
 *     to the child process using an unnamed pipe.
 * Compile: gcc exp01.c -o exp01
 * Run    : ./exp01 input.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[]) {
    if (argc < 2) { fprintf(stderr, "Usage: %s <file>\n", argv[0]); return 1; }
    int fd[2]; char buf[256]; ssize_t n;
    FILE *fp = fopen(argv[1], "r");
    if (!fp) { perror("fopen"); return 1; }
    if (pipe(fd) == -1) { perror("pipe"); return 1; }
    pid_t pid = fork();
    if (pid == 0) {                       /* child: read from pipe */
        close(fd[1]);
        printf("Child received:\n");
        while ((n = read(fd[0], buf, sizeof(buf))) > 0) write(STDOUT_FILENO, buf, n);
        close(fd[0]);
        exit(0);
    }
    close(fd[0]);                         /* parent: write file into pipe */
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) write(fd[1], buf, n);
    close(fd[1]); fclose(fp);
    wait(NULL);
    return 0;
}
