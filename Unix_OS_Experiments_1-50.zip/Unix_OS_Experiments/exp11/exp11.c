/* Q11. Implement the Producer-Consumer problem using shared memory and semaphores.
 * Compile: gcc -pthread exp11.c -o exp11
 * Run    : ./exp11
 */
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#define BUF 5
#define ITEMS 10
struct shared { int buf[BUF]; int in, out; sem_t empty, full, mutex; };
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    struct shared *s = mmap(NULL, sizeof(*s), PROT_READ | PROT_WRITE,
                            MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    s->in = s->out = 0;
    sem_init(&s->empty, 1, BUF); sem_init(&s->full, 1, 0); sem_init(&s->mutex, 1, 1);
    if (fork() == 0) {                    /* consumer */
        for (int i = 0; i < ITEMS; i++) {
            sem_wait(&s->full); sem_wait(&s->mutex);
            int v = s->buf[s->out]; s->out = (s->out + 1) % BUF;
            sem_post(&s->mutex); sem_post(&s->empty);
            printf("Consumed: %d\n", v);
        }
        exit(0);
    }
    for (int i = 1; i <= ITEMS; i++) {    /* producer */
        sem_wait(&s->empty); sem_wait(&s->mutex);
        s->buf[s->in] = i * i; s->in = (s->in + 1) % BUF;
        sem_post(&s->mutex); sem_post(&s->full);
        printf("Produced: %d\n", i * i);
    }
    wait(NULL);
    return 0;
}
