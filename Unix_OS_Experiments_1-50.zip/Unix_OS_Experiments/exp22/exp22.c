/* Q22. Producer-Consumer with bounded buffer: Use shared memory and semaphores to
 *      implement multiple producers and multiple consumers.
 * Compile: gcc -pthread exp22.c -o exp22
 * Run    : ./exp22
 */
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#define BUF 5
#define PRODUCERS 2
#define CONSUMERS 2
#define PER_PRODUCER 5
struct shared { int buf[BUF]; int in, out; sem_t empty, full, mutex; };
void producer(struct shared *s, int id) {
    for (int k = 1; k <= PER_PRODUCER; k++) {
        int item = id * 100 + k;
        sem_wait(&s->empty); sem_wait(&s->mutex);
        s->buf[s->in] = item; s->in = (s->in + 1) % BUF;
        printf("Producer %d produced %d\n", id, item);
        sem_post(&s->mutex); sem_post(&s->full);
        usleep(100000);
    }
    exit(0);
}
void consumer(struct shared *s, int id) {
    for (int k = 0; k < PER_PRODUCER * PRODUCERS / CONSUMERS; k++) {
        sem_wait(&s->full); sem_wait(&s->mutex);
        int item = s->buf[s->out]; s->out = (s->out + 1) % BUF;
        printf("Consumer %d consumed %d\n", id, item);
        sem_post(&s->mutex); sem_post(&s->empty);
        usleep(150000);
    }
    exit(0);
}
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    struct shared *s = mmap(NULL, sizeof(*s), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    s->in = s->out = 0;
    sem_init(&s->empty, 1, BUF); sem_init(&s->full, 1, 0); sem_init(&s->mutex, 1, 1);
    for (int i = 1; i <= PRODUCERS; i++) if (fork() == 0) producer(s, i);
    for (int i = 1; i <= CONSUMERS; i++) if (fork() == 0) consumer(s, i);
    while (wait(NULL) > 0);
    return 0;
}
