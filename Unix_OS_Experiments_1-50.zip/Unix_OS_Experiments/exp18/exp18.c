/* Q18. Shared memory calculator: One process writes two operands and an operator into
 *      shared memory. Another process reads the request, performs the calculation, and
 *      writes back the result.
 * Compile: gcc exp18.c -o exp18
 * Run    : ./exp18
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#define KEY 0x1801
struct calc { double a, b; char op; double result; int status; };   /* status: 1 ok, 0 error */
int main(void) {
    int id = shmget(KEY, sizeof(struct calc), 0666 | IPC_CREAT);
    struct calc *c = shmat(id, NULL, 0);
    printf("Enter operand 1: "); scanf("%lf", &c->a);
    printf("Enter operand 2: "); scanf("%lf", &c->b);
    printf("Enter operator (+ - * /): "); scanf(" %c", &c->op);
    if (fork() == 0) {                    /* Process 2: calculate and write result */
        c->status = 1;
        switch (c->op) {
            case '+': c->result = c->a + c->b; break;
            case '-': c->result = c->a - c->b; break;
            case '*': c->result = c->a * c->b; break;
            case '/': if (c->b == 0) c->status = 0; else c->result = c->a / c->b; break;
            default:  c->status = 0;
        }
        exit(0);
    }
    wait(NULL);
    if (c->status) printf("Result: %.2lf %c %.2lf = %.2lf\n", c->a, c->op, c->b, c->result);
    else printf("Error: invalid operator or divide by zero\n");
    shmdt(c); shmctl(id, IPC_RMID, NULL);
    return 0;
}
