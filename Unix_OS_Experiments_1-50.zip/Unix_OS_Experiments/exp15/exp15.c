/* Q15. Write a program to implement an Echo Server using TCP sockets
 *      (both iterative and concurrent versions).
 * Compile: gcc exp15.c -o exp15
 * Run    : ./exp15 server i     (iterative)     or    ./exp15 server c   (concurrent)
 *          ./exp15 client       (in another terminal)
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 8888
static void echo_loop(int c) {
    char buf[1024]; int n;
    while ((n = recv(c, buf, sizeof(buf), 0)) > 0) send(c, buf, n, 0);
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server [i|c] | client\n", argv[0]); return 1; }
    if (strcmp(argv[1], "client") == 0) {
        char line[1024], buf[1024];
        int s = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in addr = {0};
        addr.sin_family = AF_INET; addr.sin_port = htons(PORT);
        inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
        if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) { perror("connect"); return 1; }
        printf("Enter message: "); fgets(line, sizeof(line), stdin);
        send(s, line, strlen(line), 0);
        int n = recv(s, buf, sizeof(buf) - 1, 0); buf[n > 0 ? n : 0] = '\0';
        printf("Echo from server: %s", buf);
        close(s);
        return 0;
    }
    int concurrent = (argc > 2 && argv[2][0] == 'c');
    int ss = socket(AF_INET, SOCK_STREAM, 0), opt = 1;
    setsockopt(ss, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(PORT);
    bind(ss, (struct sockaddr *)&addr, sizeof(addr));
    listen(ss, 10);
    if (concurrent) signal(SIGCHLD, SIG_IGN);       /* auto-reap children */
    printf("Echo server (%s) on port %d\n", concurrent ? "concurrent" : "iterative", PORT);
    while (1) {
        int c = accept(ss, NULL, NULL);
        if (concurrent) {
            if (fork() == 0) { close(ss); echo_loop(c); close(c); exit(0); }
            close(c);
        } else {
            echo_loop(c); close(c);
        }
    }
}
