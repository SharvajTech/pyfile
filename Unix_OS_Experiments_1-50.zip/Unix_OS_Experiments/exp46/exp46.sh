#!/bin/bash
# Q46. Implement a digital clock using a shell script.
# Run: chmod +x exp46.sh && ./exp46.sh      (Ctrl+C to stop)
trap 'clear; exit 0' INT
while true; do
    clear
    echo "=============================="
    echo "         $(date +%H:%M:%S)"
    echo "   $(date '+%A, %d %B %Y')"
    echo "=============================="
    sleep 1
done
