/* Q36. Write a program that uses kill() to send signals between related processes
 *      (created with fork()).
 * Compile: gcc exp36.c -o exp36
 * Run    : ./exp36
 */
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static void child_handler(int sig) {
    static const char msg[] = "Child: received SIGUSR1\n";
    (void)sig;
    write(STDOUT_FILENO, msg, sizeof(msg) - 1);
}
int main(void) {
    pid_t pid = fork();
    if (pid == 0) {
        signal(SIGUSR1, child_handler);
        printf("Child (pid %d) waiting for signals\n", getpid()); fflush(stdout);
        while (1) pause();
    }
    sleep(1);
    printf("Parent: sending SIGUSR1 twice\n");
    kill(pid, SIGUSR1); sleep(1);
    kill(pid, SIGUSR1); sleep(1);
    printf("Parent: sending SIGKILL to child\n");
    kill(pid, SIGKILL);
    int status;
    waitpid(pid, &status, 0);
    if (WIFSIGNALED(status)) printf("Parent: child killed by signal %d\n", WTERMSIG(status));
    return 0;
}
