/* Q35. Write a program that uses kill() to send signals between two unrelated processes.
 * Compile: gcc exp35.c -o exp35
 * Run    : Terminal 1: ./exp35 recv        (note the PID printed)
 *          Terminal 2: ./exp35 send <PID>
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
static void handler(int sig) {
    const char *m = (sig == SIGUSR1) ? "Receiver: got SIGUSR1\n" : "Receiver: got SIGUSR2\n";
    write(STDOUT_FILENO, m, strlen(m));
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s recv | send <pid>\n", argv[0]); return 1; }
    if (strcmp(argv[1], "recv") == 0) {
        printf("Receiver PID = %d (press Ctrl+C to stop)\n", getpid());
        signal(SIGUSR1, handler);
        signal(SIGUSR2, handler);
        while (1) pause();
    } else if (argc == 3) {
        pid_t pid = atoi(argv[2]);
        kill(pid, SIGUSR1); printf("Sender: sent SIGUSR1 to %d\n", pid);
        sleep(1);
        kill(pid, SIGUSR2); printf("Sender: sent SIGUSR2 to %d\n", pid);
    }
    return 0;
}
