/* Q3. Write a program using a pipe filter that converts text from uppercase to
 *     lowercase before printing.
 * Compile: gcc exp03.c -o exp03
 * Run    : echo "HELLO WORLD" | ./exp03        (or: cat file.txt | ./exp03)
 */
#include <stdio.h>
#include <ctype.h>
int main(void) {
    int c;
    while ((c = getchar()) != EOF) putchar(tolower(c));
    return 0;
}
