/* Q2. Implement a program using named pipe (FIFO) to allow one process to send input
 *     text and another process to receive and display it.
 * Compile: gcc exp02.c -o exp02
 * Run    : Terminal 1: ./exp02 r      Terminal 2: ./exp02 w
 */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#define FIFO "/tmp/exp02_fifo"
int main(int argc, char *argv[]) {
    char buf[256];
    if (argc < 2) { printf("Usage: %s w|r\n", argv[0]); return 1; }
    mkfifo(FIFO, 0666);
    if (argv[1][0] == 'w') {              /* sender */
        int fd = open(FIFO, O_WRONLY);
        printf("Enter text (Ctrl+D to finish):\n");
        while (fgets(buf, sizeof(buf), stdin)) write(fd, buf, strlen(buf));
        close(fd);
    } else {                              /* receiver */
        int fd = open(FIFO, O_RDONLY);
        ssize_t n;
        printf("Received:\n");
        while ((n = read(fd, buf, sizeof(buf))) > 0) write(STDOUT_FILENO, buf, n);
        close(fd);
        unlink(FIFO);
    }
    return 0;
}
