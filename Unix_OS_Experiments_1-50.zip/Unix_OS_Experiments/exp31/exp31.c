/* Q31. Write a program that launches an application using the vfork() system call.
 * Compile: gcc exp31.c -o exp31
 * Run    : ./exp31 ls -l
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s <application> [args]\n", argv[0]); return 1; }
    pid_t pid = vfork();
    if (pid < 0) { perror("vfork"); return 1; }
    if (pid == 0) {                 /* child must only exec or _exit after vfork */
        execvp(argv[1], &argv[1]);
        perror("exec failed"); _exit(1);
    }
    int status;
    waitpid(pid, &status, 0);
    printf("Application exited with status %d\n", WEXITSTATUS(status));
    return 0;
}
