# Unix OS Practical – Experiments 1 to 50

Each experiment is in its own folder `expNN/`. Run commands from inside that folder.
Compile flags: `-pthread` is needed for programs using pthreads/POSIX semaphores.
Java: `javac *.java` first. Shell scripts: `chmod +x <script>` first.

| No | Commands |
|----|----------|
| 1  | `echo "hello pipe" > input.txt && gcc exp01.c -o exp01 && ./exp01 input.txt` |
| 2  | `gcc exp02.c -o exp02` → Terminal 1: `./exp02 r` ; Terminal 2: `./exp02 w` |
| 3  | `gcc exp03.c -o exp03 && echo "HELLO World" \| ./exp03` |
| 4  | `gcc exp04.c -o exp04 && ./exp04 s` then `./exp04 r` |
| 5  | `gcc exp05.c -o exp05` → Terminal 1: `./exp05 1` ; Terminal 2: `./exp05 2` |
| 6  | `gcc exp06.c -o exp06 && ./exp06 10` |
| 7  | `gcc exp07.c -o exp07` → `./exp07 w` then `./exp07 r` |
| 8  | `gcc exp08.c -o exp08 && ./exp08` |
| 9  | `gcc exp09.c -o exp09 && ./exp09` (creates output9.txt) |
| 10 | `gcc -pthread exp10.c -o exp10 && ./exp10` |
| 11 | `gcc -pthread exp11.c -o exp11 && ./exp11` |
| 12 | `gcc -pthread exp12.c -o exp12 && ./exp12` |
| 13 | `gcc exp13.c -o exp13` → Terminal 1: `./exp13 server` ; Terminal 2: `./exp13 client` |
| 14 | `gcc exp14.c -o exp14` → Terminal 1: `./exp14 server` ; Terminal 2: `./exp14 client` |
| 15 | `gcc exp15.c -o exp15` → `./exp15 server i` (or `c`) ; client: `./exp15 client` |
| 16 | `gcc exp16.c -o exp16` → `./exp16 server` ; `./exp16 client fact 5` ; stop: `./exp16 client quit 0` |
| 17 | `gcc exp17.c -o exp17` → `./exp17 send 3 "Normal"` ; `./exp17 send 1 "Urgent"` ; `./exp17 recv` |
| 18 | `gcc exp18.c -o exp18 && ./exp18` |
| 19 | `gcc -pthread exp19.c -o exp19 && ./exp19 5 3 9 1 7` |
| 20 | `gcc -pthread exp20.c -o exp20 && ./exp20 input.txt` (creates received_input.txt) |
| 21 | `gcc -pthread exp21.c -o exp21 && ./exp21` |
| 22 | `gcc -pthread exp22.c -o exp22 && ./exp22` |
| 23 | `gcc -pthread exp23.c -o exp23 && ./exp23` |
| 24 | `gcc -pthread exp24.c -o exp24` → `./exp24 server` ; client: `./exp24 client` |
| 25 | `gcc exp25.c -o exp25` → `./exp25 server` ; `./exp25 client input.txt` |
| 26 | `gcc exp26.c -o exp26` → `./exp26 server` ; `./exp26 client` |
| 27 | `gcc -pthread exp27.c -o exp27` → `./exp27 server` ; `./exp27 client Alice` ; `./exp27 client Bob` |
| 28 | `gcc exp28.c -o exp28 && ./exp28` |
| 29 | `gcc exp29.c -o exp29 && ./exp29` |
| 30 | `gcc exp30.c -o exp30 && ./exp30 ls -l` |
| 31 | `gcc exp31.c -o exp31 && ./exp31 ls -l` |
| 32 | `gcc exp32.c -o exp32 && ./exp32` |
| 33 | `gcc exp33.c -o exp33 && ./exp33` |
| 34 | `gcc exp34.c -o exp34 && ./exp34` |
| 35 | `gcc exp35.c -o exp35` → Terminal 1: `./exp35 recv` (note PID) ; Terminal 2: `./exp35 send <PID>` |
| 36 | `gcc exp36.c -o exp36 && ./exp36` |
| 37 | `gcc exp37.c -o exp37 && ./exp37` |
| 38 | `gcc exp38.c -o exp38 && ./exp38 5` |
| 39 | `gcc exp39.c -o exp39 && ./exp39 input.txt` |
| 40 | `gcc exp40.c -o exp40 && ./exp40 input.txt` |
| 41 | `javac *.java` → Terminal 1: `java ChatServer` ; Terminal 2: `java ChatClient Alice` |
| 42 | `gcc -pthread exp42.c -o exp42 && ./exp42 20` |
| 43 | `gcc -pthread exp43.c -o exp43 && ./exp43` |
| 44 | `javac ProducerConsumer.java && java ProducerConsumer` |
| 45 | `chmod +x exp45.sh && ./exp45.sh` |
| 46 | `chmod +x exp46.sh && ./exp46.sh` |
| 47 | `chmod +x exp47.sh && ./exp47.sh 8.8.8.8` |
| 48 | `chmod +x exp48.sh && ./exp48.sh` |
| 49 | `chmod +x exp49.sh && ./exp49.sh` |
| 50 | `chmod +x exp50.sh && ./exp50.sh /etc passwd` |
