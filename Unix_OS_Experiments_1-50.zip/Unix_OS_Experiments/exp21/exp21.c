/* Q21. Dining philosophers problem: Implement the classical dining philosophers
 *      synchronization problem using semaphores.
 * Compile: gcc -pthread exp21.c -o exp21
 * Run    : ./exp21
 */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#define N 5
sem_t forks[N];
void *philosopher(void *arg) {
    int id = *(int *)arg;
    int left = id, right = (id + 1) % N;
    /* pick up the lower-numbered fork first to avoid deadlock */
    int first = left < right ? left : right;
    int second = left < right ? right : left;
    for (int meal = 1; meal <= 3; meal++) {
        printf("Philosopher %d is THINKING\n", id); usleep(200000);
        sem_wait(&forks[first]); sem_wait(&forks[second]);
        printf("Philosopher %d is EATING (meal %d)\n", id, meal); usleep(300000);
        sem_post(&forks[second]); sem_post(&forks[first]);
    }
    printf("Philosopher %d finished eating\n", id);
    return NULL;
}
int main(void) {
    pthread_t t[N]; int ids[N];
    for (int i = 0; i < N; i++) sem_init(&forks[i], 0, 1);
    for (int i = 0; i < N; i++) { ids[i] = i; pthread_create(&t[i], NULL, philosopher, &ids[i]); }
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    return 0;
}
