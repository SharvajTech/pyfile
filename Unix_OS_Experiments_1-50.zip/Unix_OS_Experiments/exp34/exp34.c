/* Q34. Create a program that demonstrates exit() combined with wait() and fork()
 *      (showing how children terminate and how parents collect status).
 * Compile: gcc exp34.c -o exp34
 * Run    : ./exp34
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    for (int i = 1; i <= 3; i++) {
        if (fork() == 0) {
            printf("Child %d (pid %d) exiting with status %d\n", i, getpid(), i * 10);
            exit(i * 10);
        }
    }
    int status; pid_t pid;
    while ((pid = wait(&status)) > 0) {
        if (WIFEXITED(status))
            printf("Parent collected child %d: exited normally, status = %d\n", pid, WEXITSTATUS(status));
        else
            printf("Child %d terminated abnormally\n", pid);
    }
    printf("No more children. Parent exiting.\n");
    return 0;
}
