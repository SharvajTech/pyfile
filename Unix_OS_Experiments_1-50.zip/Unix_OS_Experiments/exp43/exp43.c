/* Q43. Write a multithreaded program on Linux that uses the pthread library.
 * Compile: gcc -pthread exp43.c -o exp43
 * Run    : ./exp43
 */
#include <stdio.h>
#include <pthread.h>
#define NTHREADS 4
#define RANGE 25
typedef struct { int id, start, end; long sum; } task_t;
void *worker(void *arg) {
    task_t *t = (task_t *)arg;
    t->sum = 0;
    for (int i = t->start; i <= t->end; i++) t->sum += i;
    printf("Thread %d (tid %lu): sum of %d..%d = %ld\n",
           t->id, (unsigned long)pthread_self(), t->start, t->end, t->sum);
    return NULL;
}
int main(void) {
    pthread_t th[NTHREADS]; task_t tasks[NTHREADS]; long total = 0;
    for (int i = 0; i < NTHREADS; i++) {
        tasks[i].id = i + 1; tasks[i].start = i * RANGE + 1; tasks[i].end = (i + 1) * RANGE;
        pthread_create(&th[i], NULL, worker, &tasks[i]);
    }
    for (int i = 0; i < NTHREADS; i++) { pthread_join(th[i], NULL); total += tasks[i].sum; }
    printf("Total sum of 1..%d = %ld\n", NTHREADS * RANGE, total);
    return 0;
}
