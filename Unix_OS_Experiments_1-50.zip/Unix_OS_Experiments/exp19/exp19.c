/* Q19. Multi-process shared memory sort: 
 *   a. Process 1 writes an array of numbers to shared memory.
 *   b. Process 2 sorts the numbers.
 *   c. Process 3 computes the median and mean.
 *   d. Process 4 displays the final results.
 *   Synchronize using semaphores.
 * Compile: gcc -pthread exp19.c -o exp19
 * Run    : ./exp19 5 3 9 1 7 2
 */
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#define MAX 100
struct shared { int n; int a[MAX]; double mean, median; sem_t s_written, s_sorted, s_computed; };
int cmp(const void *x, const void *y) { return *(const int *)x - *(const int *)y; }
int main(int argc, char *argv[]) {
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc < 2) { printf("Usage: %s n1 n2 n3 ...\n", argv[0]); return 1; }
    struct shared *s = mmap(NULL, sizeof(*s), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_init(&s->s_written, 1, 0); sem_init(&s->s_sorted, 1, 0); sem_init(&s->s_computed, 1, 0);
    /* Process 1: write array */
    s->n = argc - 1 > MAX ? MAX : argc - 1;
    for (int i = 0; i < s->n; i++) s->a[i] = atoi(argv[i + 1]);
    printf("P1: wrote %d numbers to shared memory\n", s->n);
    sem_post(&s->s_written);
    if (fork() == 0) {                    /* Process 2: sort */
        sem_wait(&s->s_written);
        qsort(s->a, s->n, sizeof(int), cmp);
        printf("P2: sorted the numbers\n");
        sem_post(&s->s_sorted);
        exit(0);
    }
    if (fork() == 0) {                    /* Process 3: median & mean */
        sem_wait(&s->s_sorted);
        double sum = 0;
        for (int i = 0; i < s->n; i++) sum += s->a[i];
        s->mean = sum / s->n;
        s->median = (s->n % 2) ? s->a[s->n / 2] : (s->a[s->n / 2 - 1] + s->a[s->n / 2]) / 2.0;
        printf("P3: computed median and mean\n");
        sem_post(&s->s_computed);
        exit(0);
    }
    if (fork() == 0) {                    /* Process 4: display */
        sem_wait(&s->s_computed);
        printf("P4: sorted list:");
        for (int i = 0; i < s->n; i++) printf(" %d", s->a[i]);
        printf("\nP4: mean = %.2f\nP4: median = %.2f\n", s->mean, s->median);
        exit(0);
    }
    while (wait(NULL) > 0);
    return 0;
}
