/* Q23. Reader-Writer with priority: Implement the reader-writer problem using semaphores
 *      such that writers are given higher priority than readers.
 * Compile: gcc -pthread exp23.c -o exp23
 * Run    : ./exp23
 */
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
sem_t mutex1, mutex2, readTry, roomEmpty;
int readcount = 0, writecount = 0, shared_data = 0;
void *reader(void *arg) {
    int id = *(int *)arg;
    for (int k = 0; k < 3; k++) {
        sem_wait(&readTry);                       /* blocked while a writer waits */
        sem_wait(&mutex1); readcount++;
        if (readcount == 1) sem_wait(&roomEmpty);
        sem_post(&mutex1);
        sem_post(&readTry);
        printf("Reader %d reads %d\n", id, shared_data); usleep(200000);
        sem_wait(&mutex1); readcount--;
        if (readcount == 0) sem_post(&roomEmpty);
        sem_post(&mutex1);
        usleep(100000);
    }
    return NULL;
}
void *writer(void *arg) {
    int id = *(int *)arg;
    for (int k = 0; k < 3; k++) {
        sem_wait(&mutex2); writecount++;
        if (writecount == 1) sem_wait(&readTry); /* first writer blocks new readers */
        sem_post(&mutex2);
        sem_wait(&roomEmpty);
        shared_data++; printf("Writer %d writes %d\n", id, shared_data); usleep(300000);
        sem_post(&roomEmpty);
        sem_wait(&mutex2); writecount--;
        if (writecount == 0) sem_post(&readTry);
        sem_post(&mutex2);
        usleep(100000);
    }
    return NULL;
}
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    pthread_t r[3], w[2]; int rid[3] = {1, 2, 3}, wid[2] = {1, 2};
    sem_init(&mutex1, 0, 1); sem_init(&mutex2, 0, 1);
    sem_init(&readTry, 0, 1); sem_init(&roomEmpty, 0, 1);
    for (int i = 0; i < 3; i++) pthread_create(&r[i], NULL, reader, &rid[i]);
    for (int i = 0; i < 2; i++) pthread_create(&w[i], NULL, writer, &wid[i]);
    for (int i = 0; i < 3; i++) pthread_join(r[i], NULL);
    for (int i = 0; i < 2; i++) pthread_join(w[i], NULL);
    return 0;
}
