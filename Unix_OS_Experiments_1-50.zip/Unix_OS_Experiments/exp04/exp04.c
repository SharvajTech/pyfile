/* Q4. Write a program using System V message queues to send and receive messages
 *     between two processes.
 * Compile: gcc exp04.c -o exp04
 * Run    : ./exp04 s     (sender, type message)
 *          ./exp04 r     (receiver, displays message)
 */
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#define KEY 0x0404
struct msgbuf { long mtype; char mtext[256]; };
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s s|r\n", argv[0]); return 1; }
    int qid = msgget(KEY, 0666 | IPC_CREAT);
    struct msgbuf m;
    if (argv[1][0] == 's') {
        m.mtype = 1;
        printf("Enter message: ");
        fgets(m.mtext, sizeof(m.mtext), stdin);
        msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
        printf("Message sent.\n");
    } else {
        msgrcv(qid, &m, sizeof(m.mtext), 1, 0);
        printf("Received: %s", m.mtext);
        msgctl(qid, IPC_RMID, NULL);
    }
    return 0;
}
