/* Q27. Multi-user chat server: Implement a group chat system using TCP sockets where
 *      multiple clients can join, send messages, and receive broadcasts from the server.
 * Compile: gcc -pthread exp27.c -o exp27
 * Run    : Terminal 1: ./exp27 server
 *          Terminal 2: ./exp27 client Alice      Terminal 3: ./exp27 client Bob
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 9027
#define MAXC 50
int clients[MAXC]; int count = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static void broadcast(const char *msg, int sender) {
    pthread_mutex_lock(&lock);
    for (int i = 0; i < count; i++)
        if (clients[i] != sender) send(clients[i], msg, strlen(msg), 0);
    pthread_mutex_unlock(&lock);
}
static void *client_thread(void *arg) {
    int c = *(int *)arg; free(arg);
    char buf[600]; int n;
    while ((n = recv(c, buf, sizeof(buf) - 1, 0)) > 0) {
        buf[n] = '\0'; printf("%s", buf);
        broadcast(buf, c);
    }
    pthread_mutex_lock(&lock);
    for (int i = 0; i < count; i++) if (clients[i] == c) { clients[i] = clients[--count]; break; }
    pthread_mutex_unlock(&lock);
    close(c);
    return NULL;
}
static void *receiver(void *arg) {
    int s = *(int *)arg; char buf[600]; int n;
    while ((n = recv(s, buf, sizeof(buf) - 1, 0)) > 0) { buf[n] = '\0'; printf("%s", buf); fflush(stdout); }
    printf("\nDisconnected from server.\n"); exit(0);
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server | client <name>\n", argv[0]); return 1; }
    if (!strcmp(argv[1], "server")) {
        int ss = socket(AF_INET, SOCK_STREAM, 0), opt = 1;
        setsockopt(ss, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        struct sockaddr_in addr = {0};
        addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(PORT);
        bind(ss, (struct sockaddr *)&addr, sizeof(addr)); listen(ss, 10);
        printf("Group chat server on port %d\n", PORT);
        while (1) {
            int c = accept(ss, NULL, NULL);
            pthread_mutex_lock(&lock);
            if (count < MAXC) clients[count++] = c;
            pthread_mutex_unlock(&lock);
            int *arg = malloc(sizeof(int)); *arg = c;
            pthread_t t; pthread_create(&t, NULL, client_thread, arg); pthread_detach(t);
            printf("New client joined (total %d)\n", count);
        }
    }
    if (argc < 3) { printf("Usage: %s client <name>\n", argv[0]); return 1; }
    char *name = argv[2];
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) { perror("connect"); return 1; }
    printf("Joined as %s. Type messages:\n", name);
    pthread_t rt; pthread_create(&rt, NULL, receiver, &s); pthread_detach(rt);
    char line[512], out[600];
    while (fgets(line, sizeof(line), stdin)) {
        snprintf(out, sizeof(out), "%s: %s", name, line);
        send(s, out, strlen(out), 0);
    }
    close(s);
    return 0;
}
