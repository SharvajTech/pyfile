/* Q33. Write a program to illustrate different variants of the exec() family of system calls.
 * Compile: gcc exp33.c -o exp33
 * Run    : ./exp33
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    char *args[] = {"ls", "-l", NULL};
    char *env[] = {"MYVAR=hello", NULL};
    for (int i = 1; i <= 6; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            printf("\n--- exec variant %d ---\n", i); fflush(stdout);
            switch (i) {
                case 1: execl("/bin/ls", "ls", "-l", NULL); break;          /* execl  */
                case 2: execlp("ls", "ls", "-l", NULL); break;             /* execlp */
                case 3: execv("/bin/ls", args); break;                     /* execv  */
                case 4: execvp("ls", args); break;                         /* execvp */
                case 5: execle("/usr/bin/env", "env", NULL, env); break;   /* execle */
                case 6: { char *a[] = {"date", NULL};
                          execve("/bin/date", a, env); break; }            /* execve */
            }
            perror("exec failed"); exit(1);
        }
        waitpid(pid, NULL, 0);
    }
    return 0;
}
