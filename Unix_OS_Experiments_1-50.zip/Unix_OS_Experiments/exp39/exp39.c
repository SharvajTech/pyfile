/* Q39. Write a program that reports file statistics using stat() (include important
 *      fields such as file access permissions, file type, etc.)
 * Compile: gcc exp39.c -o exp39
 * Run    : ./exp39 input.txt
 */
#include <stdio.h>
#include <time.h>
#include <sys/stat.h>
static void print_type(mode_t m) {
    if (S_ISREG(m))  printf("Regular file\n");
    else if (S_ISDIR(m))  printf("Directory\n");
    else if (S_ISLNK(m))  printf("Symbolic link\n");
    else if (S_ISCHR(m))  printf("Character device\n");
    else if (S_ISBLK(m))  printf("Block device\n");
    else if (S_ISFIFO(m)) printf("FIFO / named pipe\n");
    else if (S_ISSOCK(m)) printf("Socket\n");
    else printf("Unknown\n");
}
static void print_perm(mode_t m) {
    const char *rwx = "rwxrwxrwx";
    printf("Permissions: ");
    for (int i = 0; i < 9; i++) putchar((m & (1 << (8 - i))) ? rwx[i] : '-');
    printf("  (octal %o)\n", m & 0777);
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s <file>\n", argv[0]); return 1; }
    struct stat st;
    if (stat(argv[1], &st) == -1) { perror("stat"); return 1; }
    printf("File: %s\n", argv[1]);
    printf("Type: "); print_type(st.st_mode);
    print_perm(st.st_mode);
    printf("Size: %ld bytes\n", (long)st.st_size);
    printf("Inode: %ld   Hard links: %ld\n", (long)st.st_ino, (long)st.st_nlink);
    printf("Owner UID: %d   Group GID: %d\n", st.st_uid, st.st_gid);
    printf("Last modified: %s", ctime(&st.st_mtime));
    printf("Last accessed: %s", ctime(&st.st_atime));
    return 0;
}
