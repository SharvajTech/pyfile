/* Q24. Concurrent TCP echo server: Implement an echo server using TCP sockets that
 *      handles multiple clients concurrently using fork() or threads.
 * Compile: gcc -pthread exp24.c -o exp24
 * Run    : Terminal 1: ./exp24 server      Terminal 2,3: ./exp24 client
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 9024
void *handle_client(void *arg) {
    int c = (int)(long)arg; char buf[1024]; int n;
    printf("Client connected (socket %d)\n", c);
    while ((n = recv(c, buf, sizeof(buf), 0)) > 0) send(c, buf, n, 0);
    close(c);
    return NULL;
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server|client\n", argv[0]); return 1; }
    if (strcmp(argv[1], "server") == 0) {
        int ss = socket(AF_INET, SOCK_STREAM, 0), opt = 1;
        setsockopt(ss, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        struct sockaddr_in a = {0};
        a.sin_family = AF_INET; a.sin_addr.s_addr = htonl(INADDR_ANY); a.sin_port = htons(PORT);
        bind(ss, (struct sockaddr *)&a, sizeof(a)); listen(ss, 10);
        printf("Concurrent echo server on port %d\n", PORT);
        while (1) {
            int c = accept(ss, NULL, NULL);
            pthread_t t;
            pthread_create(&t, NULL, handle_client, (void *)(long)c);
            pthread_detach(t);
        }
    }
    char line[1024], buf[1024];
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET; a.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("connect"); return 1; }
    while (fgets(line, sizeof(line), stdin)) {
        send(s, line, strlen(line), 0);
        int n = recv(s, buf, sizeof(buf) - 1, 0);
        if (n <= 0) break;
        buf[n] = '\0'; printf("Echo: %s", buf);
    }
    close(s);
    return 0;
}
