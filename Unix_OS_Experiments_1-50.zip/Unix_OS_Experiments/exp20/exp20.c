/* Q20. Shared memory file transfer: Implement a program where one process reads data
 *      from a file and writes into shared memory in chunks, and another process
 *      reconstructs the file.
 * Compile: gcc -pthread exp20.c -o exp20
 * Run    : ./exp20 input.txt          (creates received_input.txt)
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#define CHUNK 256
struct shared { int len; char data[CHUNK]; sem_t empty, full; };
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s <file>\n", argv[0]); return 1; }
    FILE *in = fopen(argv[1], "rb");
    if (!in) { perror("fopen"); return 1; }
    struct shared *s = mmap(NULL, sizeof(*s), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_init(&s->empty, 1, 1); sem_init(&s->full, 1, 0);
    char outname[300];
    snprintf(outname, sizeof(outname), "received_%s", argv[1]);
    if (fork() == 0) {                    /* Process 2: rebuild file */
        FILE *out = fopen(outname, "wb");
        while (1) {
            sem_wait(&s->full);
            if (s->len == 0) { sem_post(&s->empty); break; }
            fwrite(s->data, 1, s->len, out);
            sem_post(&s->empty);
        }
        fclose(out);
        printf("Process 2: file rebuilt as %s\n", outname);
        exit(0);
    }
    char tmp[CHUNK];                      /* Process 1: read chunks into shm */
    while (1) {
        size_t n = fread(tmp, 1, CHUNK, in);
        sem_wait(&s->empty);
        memcpy(s->data, tmp, n); s->len = (int)n;
        sem_post(&s->full);
        if (n == 0) break;
    }
    fclose(in);
    wait(NULL);
    return 0;
}
