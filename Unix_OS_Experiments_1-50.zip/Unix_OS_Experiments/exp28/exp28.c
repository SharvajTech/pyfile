/* Q28. Implement a program that uses the fork() system call to create five child
 *      processes and assigns a distinct operation to each child.
 * Compile: gcc exp28.c -o exp28
 * Run    : ./exp28
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
long long fact(int n) { long long r = 1; for (int i = 2; i <= n; i++) r *= i; return r; }
int fib(int n) { int a = 0, b = 1; for (int i = 0; i < n; i++) { int t = a + b; a = b; b = t; } return a; }
int is_prime(int n) { if (n < 2) return 0; for (int i = 2; i * i <= n; i++) if (n % i == 0) return 0; return 1; }
void reverse_str(char *s) { int n = strlen(s); for (int i = 0; i < n / 2; i++) { char t = s[i]; s[i] = s[n-1-i]; s[n-1-i] = t; } }
int main(void) {
    for (int i = 1; i <= 5; i++) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); exit(1); }
        if (pid == 0) {
            switch (i) {
                case 1: { int s = 0; for (int k = 1; k <= 10; k++) s += k;
                          printf("Child 1 (pid %d): sum of 1..10 = %d\n", getpid(), s); break; }
                case 2: printf("Child 2 (pid %d): 5! = %lld\n", getpid(), fact(5)); break;
                case 3: printf("Child 3 (pid %d): 10th Fibonacci = %d\n", getpid(), fib(10)); break;
                case 4: printf("Child 4 (pid %d): is 97 prime? %s\n", getpid(), is_prime(97) ? "yes" : "no"); break;
                case 5: { char s[] = "hello"; reverse_str(s);
                          printf("Child 5 (pid %d): reversed string = %s\n", getpid(), s); break; }
            }
            exit(0);
        }
    }
    for (int i = 0; i < 5; i++) wait(NULL);
    printf("Parent: all five children finished\n");
    return 0;
}
