/* Q32. Demonstrate the use of wait() with vfork() by writing a program that shows
 *      parent-child synchronization.
 * Compile: gcc exp32.c -o exp32
 * Run    : ./exp32
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void) {
    printf("Parent (pid %d): creating child with vfork()\n", getpid());
    pid_t pid = vfork();
    if (pid == 0) {                              /* child runs first, parent suspended */
        printf("Child (pid %d): doing work, will exit with code 3\n", getpid());
        fflush(stdout);
        _exit(3);
    }
    int status;
    pid_t w = wait(&status);                     /* parent waits for child */
    printf("Parent: child %d finished with exit code %d\n", w, WEXITSTATUS(status));
    return 0;
}
