/* Q38. Create an alarm clock program using alarm() and signal handlers.
 * Compile: gcc exp38.c -o exp38
 * Run    : ./exp38 5        (rings after 5 seconds)
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
volatile sig_atomic_t ringing = 0;
static void ring(int sig) { (void)sig; ringing = 1; }
int main(int argc, char *argv[]) {
    int secs = argc > 1 ? atoi(argv[1]) : 5;
    signal(SIGALRM, ring);
    printf("Alarm set for %d seconds...\n", secs);
    alarm(secs);
    while (!ringing) {
        sleep(1);
        if (!ringing) printf("tick\n");
    }
    printf("\n*** RING RING! Time to wake up! ***\n");
    return 0;
}
