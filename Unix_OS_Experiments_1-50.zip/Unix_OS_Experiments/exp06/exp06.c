/* Q6. Write a program where one process sends a sequence of numbers using message
 *     queues, and another process computes and prints their sum.
 * Compile: gcc exp06.c -o exp06
 * Run    : ./exp06 10
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
#include <unistd.h>
#define KEY 0x0606
struct msg { long mtype; int value; };
int main(int argc, char *argv[]) {
    int count = argc > 1 ? atoi(argv[1]) : 10;
    int qid = msgget(KEY, 0666 | IPC_CREAT);
    if (fork() == 0) {                    /* sender: 1..count */
        struct msg m; m.mtype = 1;
        for (int i = 1; i <= count; i++) {
            m.value = i; msgsnd(qid, &m, sizeof(int), 0);
            printf("Sent %d\n", i);
        }
        exit(0);
    }
    struct msg m; long sum = 0;          /* receiver: sum */
    for (int i = 0; i < count; i++) { msgrcv(qid, &m, sizeof(int), 1, 0); sum += m.value; }
    wait(NULL);
    printf("Sum of %d numbers = %ld\n", count, sum);
    msgctl(qid, IPC_RMID, NULL);
    return 0;
}
