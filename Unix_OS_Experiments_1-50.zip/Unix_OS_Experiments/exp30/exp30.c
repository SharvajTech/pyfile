/* Q30. Write a program that launches an application using the fork() system call.
 * Compile: gcc exp30.c -o exp30
 * Run    : ./exp30 ls -l          (any application + its arguments, e.g. ./exp30 gedit)
 */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s <application> [args]\n", argv[0]); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        execvp(argv[1], &argv[1]);
        perror("exec failed"); _exit(1);
    }
    int status;
    waitpid(pid, &status, 0);
    printf("Application exited with status %d\n", WEXITSTATUS(status));
    return 0;
}
