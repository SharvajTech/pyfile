/* Q12. Implement the Reader-Writer problem using semaphores to control access.
 * Compile: gcc -pthread exp12.c -o exp12
 * Run    : ./exp12
 */
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
struct shared { int readcount; int data; sem_t mutex, wrt; };
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    struct shared *s = mmap(NULL, sizeof(*s), PROT_READ | PROT_WRITE,
                            MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    s->readcount = 0; s->data = 0;
    sem_init(&s->mutex, 1, 1); sem_init(&s->wrt, 1, 1);
    for (int i = 0; i < 2; i++) if (fork() == 0) {          /* writers */
        for (int k = 0; k < 3; k++) {
            sem_wait(&s->wrt);
            s->data++; printf("Writer %d wrote %d\n", i + 1, s->data);
            sleep(1);
            sem_post(&s->wrt);
        }
        exit(0);
    }
    for (int i = 0; i < 3; i++) if (fork() == 0) {          /* readers */
        for (int k = 0; k < 3; k++) {
            sem_wait(&s->mutex); s->readcount++;
            if (s->readcount == 1) sem_wait(&s->wrt);
            sem_post(&s->mutex);
            printf("Reader %d read %d\n", i + 1, s->data);
            sleep(1);
            sem_wait(&s->mutex); s->readcount--;
            if (s->readcount == 0) sem_post(&s->wrt);
            sem_post(&s->mutex);
        }
        exit(0);
    }
    while (wait(NULL) > 0);
    return 0;
}
