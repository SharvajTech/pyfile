/* Q25. UDP file transfer: Implement a client-server application where the client requests
 *      a file and the server sends it via UDP in chunks, with acknowledgments.
 * Compile: gcc exp25.c -o exp25
 * Run    : Terminal 1: ./exp25 server
 *          Terminal 2: ./exp25 client input.txt     (creates received_input.txt)
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 9025
#define CHUNK 1024
struct packet { int seq; int len; char data[CHUNK]; };
struct ack { int seq; };
static void server(void) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in addr = {0}, cli; socklen_t clen = sizeof(cli);
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(PORT);
    bind(sock, (struct sockaddr *)&addr, sizeof(addr));
    char fname[256] = {0};
    recvfrom(sock, fname, sizeof(fname) - 1, 0, (struct sockaddr *)&cli, &clen);
    struct timeval tv = {1, 0};                       /* 1s timeout for retransmission */
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    FILE *fp = fopen(fname, "rb");
    if (!fp) { printf("File not found: %s\n", fname); return; }
    printf("Sending %s\n", fname);
    struct packet p; struct ack a; int seq = 0;
    while (1) {
        p.seq = seq; p.len = (int)fread(p.data, 1, CHUNK, fp);
        int acked = 0;
        while (!acked) {                              /* stop-and-wait */
            sendto(sock, &p, sizeof(p), 0, (struct sockaddr *)&cli, clen);
            if (recvfrom(sock, &a, sizeof(a), 0, NULL, NULL) > 0 && a.seq == seq) acked = 1;
        }
        if (p.len == 0) break;                        /* zero-length = EOF */
        seq++;
    }
    fclose(fp);
    printf("Transfer complete\n");
    close(sock);
}
static void client(const char *fname) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in srv = {0};
    srv.sin_family = AF_INET; srv.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &srv.sin_addr);
    sendto(sock, fname, strlen(fname) + 1, 0, (struct sockaddr *)&srv, sizeof(srv));
    char outname[300]; snprintf(outname, sizeof(outname), "received_%s", fname);
    FILE *fp = fopen(outname, "wb");
    struct packet p; struct ack a; int expected = 0;
    while (1) {
        socklen_t slen = sizeof(srv);
        if (recvfrom(sock, &p, sizeof(p), 0, (struct sockaddr *)&srv, &slen) <= 0) continue;
        if (p.seq == expected) {
            if (p.len == 0) { a.seq = p.seq; sendto(sock, &a, sizeof(a), 0, (struct sockaddr *)&srv, sizeof(srv)); break; }
            fwrite(p.data, 1, p.len, fp); expected++;
        }
        a.seq = p.seq;                                /* ack (also re-ack duplicates) */
        sendto(sock, &a, sizeof(a), 0, (struct sockaddr *)&srv, sizeof(srv));
    }
    fclose(fp);
    printf("Received file saved as %s\n", outname);
    close(sock);
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server | client <file>\n", argv[0]); return 1; }
    if (strcmp(argv[1], "server") == 0) server();
    else if (argc == 3) client(argv[2]);
    return 0;
}
