/* Q13. Write a TCP client-server program in C where the client sends a message and
 *      the server replies with the reversed string.
 * Compile: gcc exp13.c -o exp13
 * Run    : Terminal 1: ./exp13 server      Terminal 2: ./exp13 client
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 8080
void reverse(char *s) {
    int n = strlen(s);
    for (int i = 0; i < n / 2; i++) { char t = s[i]; s[i] = s[n - 1 - i]; s[n - 1 - i] = t; }
}
int main(int argc, char *argv[]) {
    char buf[1024];
    if (argc < 2) { printf("Usage: %s server|client\n", argv[0]); return 1; }
    if (strcmp(argv[1], "server") == 0) {
        int ss = socket(AF_INET, SOCK_STREAM, 0), opt = 1;
        setsockopt(ss, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        struct sockaddr_in addr = {0};
        addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(PORT);
        bind(ss, (struct sockaddr *)&addr, sizeof(addr));
        listen(ss, 5);
        printf("Server listening on port %d\n", PORT);
        while (1) {
            int c = accept(ss, NULL, NULL);
            int n = recv(c, buf, sizeof(buf) - 1, 0);
            if (n > 0) {
                buf[n] = '\0'; printf("Received: %s\n", buf);
                reverse(buf); send(c, buf, strlen(buf), 0);
            }
            close(c);
        }
    }
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) { perror("connect"); return 1; }
    printf("Enter message: ");
    fgets(buf, sizeof(buf), stdin); buf[strcspn(buf, "\n")] = '\0';
    send(s, buf, strlen(buf), 0);
    int n = recv(s, buf, sizeof(buf) - 1, 0);
    buf[n > 0 ? n : 0] = '\0';
    printf("Reversed: %s\n", buf);
    close(s);
    return 0;
}
