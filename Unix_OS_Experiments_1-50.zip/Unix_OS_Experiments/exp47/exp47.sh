#!/bin/bash
# Q47. Write a shell script that checks whether the system is connected to a network
#      by using the ping command.
# Run: chmod +x exp47.sh && ./exp47.sh [host]     (default host: 8.8.8.8)
host=${1:-8.8.8.8}
if ping -c 1 -W 2 "$host" > /dev/null 2>&1; then
    echo "System IS connected to the network ($host is reachable)."
else
    echo "System is NOT connected to the network ($host is unreachable)."
fi
