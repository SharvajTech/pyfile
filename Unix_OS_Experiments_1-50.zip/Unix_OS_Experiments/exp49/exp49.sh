#!/bin/bash
# Q49. Create a program (or script) that prints "Hello World" with bold, blinking, and
#      colored (red, blue, etc.) text effects.
# Run: chmod +x exp49.sh && ./exp49.sh     (blink may not show in every terminal)
printf "\e[1;31mHello World  - bold red\e[0m\n"
printf "\e[1;34mHello World  - bold blue\e[0m\n"
printf "\e[1;32mHello World  - bold green\e[0m\n"
printf "\e[1;5;33mHello World  - bold yellow BLINKING\e[0m\n"
