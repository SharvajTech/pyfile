/* Q26. Distributed computation server: Create a TCP server that accepts computation
 *      requests (factorial, matrix multiplication, string reversal) from multiple clients
 *      and returns results.
 * Compile: gcc exp26.c -o exp26
 * Run    : Terminal 1: ./exp26 server
 *          Terminal 2: ./exp26 client
 *          Requests: FACT 5 | REV hello | MATMUL 1 2 3 4 5 6 7 8
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define PORT 9026
#define BUF 1024
static void factorial_req(const char *args, char *out) {
    long long n = atoll(args), f = 1;
    for (long long i = 2; i <= n; i++) f *= i;
    sprintf(out, "%lld", f);
}
static void reverse_req(const char *s, char *out) {
    int n = strlen(s);
    for (int i = 0; i < n; i++) out[i] = s[n - 1 - i];
    out[n] = '\0';
}
static void matmul_req(const char *args, char *out) {
    int a, b, c, d, e, f, g, h;
    if (sscanf(args, "%d %d %d %d %d %d %d %d", &a, &b, &c, &d, &e, &f, &g, &h) != 8) {
        strcpy(out, "Error: need 8 numbers (a b c d e f g h)"); return;
    }
    sprintf(out, "[%d %d; %d %d]", a * e + b * g, a * f + b * h, c * e + d * g, c * f + d * h);
}
static void handle(int c) {
    char buf[BUF], out[BUF * 2], cmd[16] = "";
    int n = recv(c, buf, sizeof(buf) - 1, 0);
    if (n <= 0) { close(c); return; }
    buf[n] = '\0'; buf[strcspn(buf, "\n")] = '\0';
    sscanf(buf, "%15s", cmd);
    char *args = buf + strlen(cmd);
    while (*args == ' ') args++;
    if (!strcmp(cmd, "FACT"))        factorial_req(args, out);
    else if (!strcmp(cmd, "REV"))    reverse_req(args, out);
    else if (!strcmp(cmd, "MATMUL")) matmul_req(args, out);
    else strcpy(out, "Error: unknown command (use FACT, REV, MATMUL)");
    send(c, out, strlen(out), 0);
    close(c);
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s server | client\n", argv[0]); return 1; }
    if (!strcmp(argv[1], "server")) {
        int ss = socket(AF_INET, SOCK_STREAM, 0), opt = 1;
        setsockopt(ss, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
        struct sockaddr_in addr = {0};
        addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY); addr.sin_port = htons(PORT);
        bind(ss, (struct sockaddr *)&addr, sizeof(addr)); listen(ss, 10);
        signal(SIGCHLD, SIG_IGN);
        printf("Computation server on port %d\n", PORT);
        while (1) {
            int c = accept(ss, NULL, NULL);
            if (fork() == 0) { close(ss); handle(c); exit(0); }
            close(c);
        }
    }
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);
    if (connect(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) { perror("connect"); return 1; }
    char line[BUF], reply[BUF * 2];
    printf("Request (FACT <n> | REV <string> | MATMUL a b c d e f g h): ");
    fgets(line, sizeof(line), stdin);
    send(s, line, strlen(line), 0);
    int n = recv(s, reply, sizeof(reply) - 1, 0);
    reply[n > 0 ? n : 0] = '\0';
    printf("Result: %s\n", reply);
    close(s);
    return 0;
}
