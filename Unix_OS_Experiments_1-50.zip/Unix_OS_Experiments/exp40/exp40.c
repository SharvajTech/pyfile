/* Q40. Write a program that reports file statistics using lstat() (include important
 *      fields such as file access permissions, file type, etc.)
 * Compile: gcc exp40.c -o exp40
 * Run    : ./exp40 input.txt       (also works on symbolic links, e.g. ./exp40 mylink)
 */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
static void print_type(mode_t m) {
    if (S_ISREG(m))  printf("Regular file\n");
    else if (S_ISDIR(m))  printf("Directory\n");
    else if (S_ISLNK(m))  printf("Symbolic link\n");
    else if (S_ISCHR(m))  printf("Character device\n");
    else if (S_ISBLK(m))  printf("Block device\n");
    else if (S_ISFIFO(m)) printf("FIFO / named pipe\n");
    else if (S_ISSOCK(m)) printf("Socket\n");
    else printf("Unknown\n");
}
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s <file>\n", argv[0]); return 1; }
    struct stat st;
    if (lstat(argv[1], &st) == -1) { perror("lstat"); return 1; }   /* does NOT follow links */
    printf("File: %s\n", argv[1]);
    printf("Type: "); print_type(st.st_mode);
    if (S_ISLNK(st.st_mode)) {
        char target[512] = "";
        ssize_t n = readlink(argv[1], target, sizeof(target) - 1);
        if (n > 0) { target[n] = '\0'; printf("Link points to: %s\n", target); }
    }
    printf("Permissions: ");
    const char *rwx = "rwxrwxrwx";
    for (int i = 0; i < 9; i++) putchar((st.st_mode & (1 << (8 - i))) ? rwx[i] : '-');
    printf("  (octal %o)\n", st.st_mode & 0777);
    printf("Size: %ld bytes   Inode: %ld   Hard links: %ld\n",
           (long)st.st_size, (long)st.st_ino, (long)st.st_nlink);
    printf("Owner UID: %d   Group GID: %d\n", st.st_uid, st.st_gid);
    printf("Last modified: %s", ctime(&st.st_mtime));
    return 0;
}
