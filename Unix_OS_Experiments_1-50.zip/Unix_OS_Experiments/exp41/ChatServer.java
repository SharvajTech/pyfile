// Q41. Develop a multithreaded chat application in Java or C.
// Compile: javac ChatServer.java ChatClient.java
// Run    : Terminal 1: java ChatServer
//          Terminal 2: java ChatClient Alice      Terminal 3: java ChatClient Bob
import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    static List<PrintWriter> clients = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) throws IOException {
        ServerSocket ss = new ServerSocket(5000);
        System.out.println("Chat server running on port 5000...");
        while (true) {
            Socket s = ss.accept();
            new Thread(() -> handle(s)).start();      // one thread per client
        }
    }

    static void handle(Socket s) {
        PrintWriter out = null;
        try (BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()))) {
            out = new PrintWriter(s.getOutputStream(), true);
            clients.add(out);
            String line;
            while ((line = in.readLine()) != null) broadcast(line);
        } catch (IOException e) {
            System.out.println("A client disconnected.");
        } finally {
            if (out != null) clients.remove(out);
        }
    }

    static void broadcast(String msg) {
        synchronized (clients) {
            for (PrintWriter p : clients) p.println(msg);
        }
    }
}
