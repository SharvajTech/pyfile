// Q41 (client). Multithreaded chat client: one thread receives, main thread sends.
// Compile: javac ChatServer.java ChatClient.java
// Run    : java ChatClient Alice
import java.io.*;
import java.net.*;

public class ChatClient {
    public static void main(String[] args) throws IOException {
        String name = args.length > 0 ? args[0] : "User";
        Socket s = new Socket("localhost", 5000);
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

        new Thread(() -> {                       // receiver thread
            try {
                String msg;
                while ((msg = in.readLine()) != null) System.out.println(msg);
            } catch (IOException e) { /* connection closed */ }
        }).start();

        BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while ((line = kb.readLine()) != null) out.println(name + ": " + line);
    }
}
