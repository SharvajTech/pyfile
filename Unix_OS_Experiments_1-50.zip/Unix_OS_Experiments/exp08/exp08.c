/* Q8. Implement a shared memory program in which:
 *   a. Process 1 takes numbers as input from the user,
 *   b. Process 2 sorts the numbers,
 *   c. Process 3 displays the sorted list.
 * Compile: gcc exp08.c -o exp08
 * Run    : ./exp08
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#define KEY 0x0808
#define MAX 100
struct shared { int n; int a[MAX]; };
void sort_numbers(struct shared *s) {                 /* Process 2 */
    for (int i = 0; i < s->n - 1; i++)
        for (int j = 0; j < s->n - i - 1; j++)
            if (s->a[j] > s->a[j + 1]) { int t = s->a[j]; s->a[j] = s->a[j + 1]; s->a[j + 1] = t; }
}
void display(struct shared *s) {                      /* Process 3 */
    printf("Sorted list:");
    for (int i = 0; i < s->n; i++) printf(" %d", s->a[i]);
    printf("\n");
}
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    int id = shmget(KEY, sizeof(struct shared), 0666 | IPC_CREAT);
    struct shared *s = shmat(id, NULL, 0);
    printf("Process 1: how many numbers? "); scanf("%d", &s->n);
    if (s->n > MAX) s->n = MAX;
    for (int i = 0; i < s->n; i++) { printf("Enter number %d: ", i + 1); scanf("%d", &s->a[i]); }
    if (fork() == 0) { sort_numbers(s); exit(0); }
    wait(NULL);
    if (fork() == 0) { display(s); exit(0); }
    wait(NULL);
    shmdt(s); shmctl(id, IPC_RMID, NULL);
    return 0;
}
