/* Q16. Job scheduling system: Write a program where a client submits jobs (e.g.,
 *      factorial, Fibonacci, prime check) via message queues, and a server process
 *      executes and returns results.
 * Compile: gcc exp16.c -o exp16
 * Run    : Terminal 1: ./exp16 server
 *          Terminal 2: ./exp16 client fact 5      (also: fib 10, prime 97)
 *          Stop server: ./exp16 client quit 0
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#define REQ_KEY 0x1601
#define REP_KEY 0x1602
#define SERVER_TYPE 1
struct request { long mtype; int client_id; char job[16]; long long arg; };
struct reply   { long mtype; long long result; };
long long fact(long long n) { long long r = 1; for (long long i = 2; i <= n; i++) r *= i; return r; }
long long fib(long long n)  { long long a = 0, b = 1; for (long long i = 0; i < n; i++) { long long t = a + b; a = b; b = t; } return a; }
long long is_prime(long long n) { if (n < 2) return 0; for (long long i = 2; i * i <= n; i++) if (n % i == 0) return 0; return 1; }
int main(int argc, char *argv[]) {
    int req = msgget(REQ_KEY, 0666 | IPC_CREAT);
    int rep = msgget(REP_KEY, 0666 | IPC_CREAT);
    struct request r; struct reply out;
    if (argc == 2 && strcmp(argv[1], "server") == 0) {
        printf("Job server waiting for jobs...\n");
        while (1) {
            msgrcv(req, &r, sizeof(r) - sizeof(long), SERVER_TYPE, 0);
            if (strcmp(r.job, "quit") == 0) break;
            if (strcmp(r.job, "fact") == 0)       out.result = fact(r.arg);
            else if (strcmp(r.job, "fib") == 0)   out.result = fib(r.arg);
            else if (strcmp(r.job, "prime") == 0) out.result = is_prime(r.arg);
            else out.result = -1;
            printf("Executed %s(%lld) for client %d -> %lld\n", r.job, r.arg, r.client_id, out.result);
            out.mtype = r.client_id;
            msgsnd(rep, &out, sizeof(out) - sizeof(long), 0);
        }
        msgctl(req, IPC_RMID, NULL); msgctl(rep, IPC_RMID, NULL);
    } else if (argc == 4) {
        memset(&r, 0, sizeof(r));
        r.mtype = SERVER_TYPE; r.client_id = getpid();
        strncpy(r.job, argv[2], 15); r.arg = atoll(argv[3]);
        msgsnd(req, &r, sizeof(r) - sizeof(long), 0);
        if (strcmp(argv[2], "quit") == 0) return 0;
        msgrcv(rep, &out, sizeof(out) - sizeof(long), getpid(), 0);
        printf("Result of %s(%s) = %lld\n", argv[2], argv[3], out.result);
    } else {
        printf("Usage:\n  %s server\n  %s client fact|fib|prime <number>\n", argv[0], argv[0]);
    }
    return 0;
}
