/* Q5. Implement a program for a chat application between two processes using
 *     message queues.
 * Compile: gcc exp05.c -o exp05
 * Run    : Terminal 1: ./exp05 1      Terminal 2: ./exp05 2
 *          (type "bye" to leave)
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
#define KEY 0x0505
struct msgbuf { long mtype; char mtext[256]; };
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s 1|2\n", argv[0]); return 1; }
    int me = atoi(argv[1]);
    long in  = (me == 1) ? 1 : 2;         /* messages addressed to me   */
    long out = (me == 1) ? 2 : 1;         /* messages addressed to peer */
    int qid = msgget(KEY, 0666 | IPC_CREAT);
    struct msgbuf m;
    pid_t pid = fork();
    if (pid == 0) {                       /* child: receive */
        while (1) {
            msgrcv(qid, &m, sizeof(m.mtext), in, 0);
            if (strncmp(m.mtext, "bye", 3) == 0) { printf("\nPeer left the chat.\n"); kill(getppid(), SIGKILL); break; }
            printf("\nPeer: %s", m.mtext); fflush(stdout);
        }
        return 0;
    }
    while (fgets(m.mtext, sizeof(m.mtext), stdin)) {   /* parent: send */
        m.mtype = out;
        msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
        if (strncmp(m.mtext, "bye", 3) == 0) break;
    }
    kill(pid, SIGKILL); wait(NULL);
    if (me == 1) msgctl(qid, IPC_RMID, NULL);
    return 0;
}
