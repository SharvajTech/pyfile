/* Q7. Write a program using shared memory (shmget, shmat, shmdt) where the first
 *     process writes a string and the second process reads it.
 * Compile: gcc exp07.c -o exp07
 * Run    : Terminal 1: ./exp07 w      Terminal 2: ./exp07 r
 */
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>
#define KEY 0x0707
#define SIZE 256
int main(int argc, char *argv[]) {
    if (argc < 2) { printf("Usage: %s w|r\n", argv[0]); return 1; }
    int id = shmget(KEY, SIZE, 0666 | IPC_CREAT);
    char *p = shmat(id, NULL, 0);
    if (argv[1][0] == 'w') {
        printf("Process 1 - enter a string: ");
        fgets(p, SIZE, stdin);
        p[strcspn(p, "\n")] = '\0';
        printf("String written to shared memory.\n");
        shmdt(p);
    } else {
        printf("Process 2 - read from shared memory: %s\n", p);
        shmdt(p);
        shmctl(id, IPC_RMID, NULL);
    }
    return 0;
}
