/* Q10. Write a program using semaphores to synchronize two processes such that one
 *      process prints even numbers and the other prints odd numbers in order.
 * Compile: gcc -pthread exp10.c -o exp10
 * Run    : ./exp10
 */
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#define LIMIT 10
int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    sem_t *sem = mmap(NULL, 2 * sizeof(sem_t), PROT_READ | PROT_WRITE,
                      MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_t *odd = &sem[0], *even = &sem[1];
    sem_init(odd, 1, 1);                  /* odd goes first */
    sem_init(even, 1, 0);
    if (fork() == 0) {                    /* child prints even */
        for (int i = 2; i <= LIMIT; i += 2) {
            sem_wait(even); printf("Even: %d\n", i); sem_post(odd);
        }
        exit(0);
    }
    for (int i = 1; i <= LIMIT; i += 2) { /* parent prints odd */
        sem_wait(odd); printf("Odd : %d\n", i); sem_post(even);
    }
    wait(NULL);
    return 0;
}
