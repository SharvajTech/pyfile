/* Q29. Implement a program using vfork() where the child reads a login name and the
 *      parent reads the password.
 * Compile: gcc exp29.c -o exp29
 * Run    : ./exp29
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
char login[50];                              /* shared with child under vfork() */
int main(void) {
    pid_t pid = vfork();
    if (pid == 0) {                          /* child: read login name */
        printf("Child: enter login name: "); fflush(stdout);
        fgets(login, sizeof(login), stdin);
        login[strcspn(login, "\n")] = '\0';
        _exit(0);
    }
    wait(NULL);                              /* parent: read password */
    char pass[50];
    printf("Parent: enter password for %s: ", login); fflush(stdout);
    fgets(pass, sizeof(pass), stdin);
    pass[strcspn(pass, "\n")] = '\0';
    printf("Login: %s | Password: %s\n", login, pass);
    return 0;
}
