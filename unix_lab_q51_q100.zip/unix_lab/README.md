# UNIX Programming Lab - Q51 to Q100

Every source file starts with a comment block that says **how to compile and run it**.
Run `./build.sh` to compile everything into `./bin` (MPI and Java are skipped if not installed).

| Folder | Questions | Notes |
|---|---|---|
| 01_message_queue | Q51-Q57 | System V message queues (`gcc file.c -o name`) |
| 02_shared_memory | Q58-Q64 | System V shm; Q60 also needs `-pthread` (POSIX semaphore) |
| 03_sockets | Q65-Q72 | TCP/UDP in C; Q70 is Java (`Q70_*.java`) |
| 04_unnamed_pipes | Q73-Q78 | `pipe()`, `popen()` |
| 05_named_pipes_fifo | Q79-Q84 | Q82 is a **text file** of shell commands (no C needed) |
| 06_openmp | Q85-Q92 | compile with `gcc -fopenmp` |
| 07_mpi | Q93-Q100 | compile with `mpicc`, run with `mpirun -np N` |

Files are named `qNN_<topic>_<what-it-does>[_role].c`; programs that come in pairs (sender/receiver, server/client, writer/reader) - start them in separate terminals in the order given in the file header.
System V IPC programs use `ftok(".", ...)`, so run both halves from the **same directory**.

Cleanup if a run was interrupted:  `ipcs` to list, `ipcrm -q|-m <id>` to remove, `rm /tmp/q*_fifo*`.

Questions where the "program" is a command sequence rather than C code:
Q82 -> `05_named_pipes_fifo/q82_fifo_shell_commands_mkfifo_cat_echo.txt`.
Questions that also involve shell checks (ipcs, cmp, ss -tan, ls | wc) have those commands
written in the header comment of the C file (Q61, Q62, Q64, Q72, Q74).

## File index (Q number -> file)

| Q | Folder | File |
|---|---|---|
| 51 | 01_message_queue | q51_msgq_qnum_receiver.c |
| 51 | 01_message_queue | q51_msgq_qnum_sender.c |
| 52 | 01_message_queue | q52_msgq_two_way_chat.c |
| 53 | 01_message_queue | q53_msgq_sum_client.c |
| 53 | 01_message_queue | q53_msgq_sum_server.c |
| 54 | 01_message_queue | q54_msgq_negative_msgtyp.c |
| 55 | 01_message_queue | q55_msgq_multiclient_client.c |
| 55 | 01_message_queue | q55_msgq_multiclient_server.c |
| 56 | 01_message_queue | q56_msgq_ipc_stat_rmid.c |
| 57 | 01_message_queue | q57_msgq_alarm_timeout_receiver.c |
| 57 | 01_message_queue | q57_msgq_alarm_timeout_sender.c |
| 58 | 02_shared_memory | q58_shm_string_reverse_reader.c |
| 58 | 02_shared_memory | q58_shm_string_writer.c |
| 59 | 02_shared_memory | q59_shm_array_max_parent_child.c |
| 60 | 02_shared_memory | q60_shm_semaphore_average_reader.c |
| 60 | 02_shared_memory | q60_shm_semaphore_writer.c |
| 61 | 02_shared_memory | q61_shm_nattch_ipcs.c |
| 62 | 02_shared_memory | q62_shm_file_copy_reader.c |
| 62 | 02_shared_memory | q62_shm_file_copy_writer.c |
| 63 | 02_shared_memory | q63_shm_message_board_reader.c |
| 63 | 02_shared_memory | q63_shm_message_board_writer.c |
| 64 | 02_shared_memory | q64_shm_reattach_and_rmid.c |
| 64 | 02_shared_memory | q64_shm_shmdt_keeps_segment.c |
| 65 | 03_sockets | q65_tcp_time_client.c |
| 65 | 03_sockets | q65_tcp_time_server.c |
| 66 | 03_sockets | q66_tcp_sum_client.c |
| 66 | 03_sockets | q66_tcp_sum_server.c |
| 67 | 03_sockets | q67_udp_echo_client.c |
| 67 | 03_sockets | q67_udp_echo_server.c |
| 68 | 03_sockets | q68_tcp_chat_client.c |
| 68 | 03_sockets | q68_tcp_chat_server.c |
| 69 | 03_sockets | q69_tcp_fork_uppercase_client.c |
| 69 | 03_sockets | q69_tcp_fork_uppercase_server.c |
| 70 | 03_sockets | Q70_MultiThreadEchoClient.java |
| 70 | 03_sockets | Q70_MultiThreadEchoServer.java |
| 71 | 03_sockets | q71_tcp_file_transfer_client.c |
| 71 | 03_sockets | q71_tcp_file_transfer_server.c |
| 72 | 03_sockets | q72_tcp_getsockname_peername_client.c |
| 72 | 03_sockets | q72_tcp_getsockname_peername_server.c |
| 73 | 04_unnamed_pipes | q73_pipe_parent_child_sum.c |
| 74 | 04_unnamed_pipes | q74_pipe_ls_wc_dup2_execlp.c |
| 75 | 04_unnamed_pipes | q75_pipe_popen_ls_pclose.c |
| 76 | 04_unnamed_pipes | q76_pipe_child_pid_to_parent.c |
| 77 | 04_unnamed_pipes | q77_pipe_file_wc_lines_words_chars.c |
| 78 | 04_unnamed_pipes | q78_pipe_capacity_nonblock.c |
| 79 | 05_named_pipes_fifo | q79_fifo_two_way_chat.c |
| 80 | 05_named_pipes_fifo | q80_fifo_file_client.c |
| 80 | 05_named_pipes_fifo | q80_fifo_file_server.c |
| 81 | 05_named_pipes_fifo | q81_fifo_five_numbers_sum_reader.c |
| 81 | 05_named_pipes_fifo | q81_fifo_five_numbers_writer.c |
| 82 | 05_named_pipes_fifo | q82_fifo_shell_commands_mkfifo_cat_echo.txt |
| 83 | 05_named_pipes_fifo | q83_fifo_nonblock_open_no_writer.c |
| 84 | 05_named_pipes_fifo | q84_fifo_logger_reader.c |
| 84 | 05_named_pipes_fifo | q84_fifo_logger_writer.c |
| 85 | 06_openmp | q85_omp_hello_threads_cores.c |
| 86 | 06_openmp | q86_omp_sum_reduction_timing.c |
| 87 | 06_openmp | q87_omp_matrix_multiply_threads.c |
| 88 | 06_openmp | q88_omp_sections_primes_even_fib.c |
| 89 | 06_openmp | q89_omp_race_critical_atomic.c |
| 90 | 06_openmp | q90_omp_max_reduction.c |
| 91 | 06_openmp | q91_omp_schedule_static_dynamic.c |
| 92 | 06_openmp | q92_omp_pi_integration.c |
| 93 | 07_mpi | q93_mpi_hello_rank_size.c |
| 94 | 07_mpi | q94_mpi_send_recv_double.c |
| 95 | 07_mpi | q95_mpi_bcast_rank_multiply.c |
| 96 | 07_mpi | q96_mpi_reduce_sum_1_to_n.c |
| 97 | 07_mpi | q97_mpi_scatter_gather_square.c |
| 98 | 07_mpi | q98_mpi_ring_token.c |
| 99 | 07_mpi | q99_mpi_pi_integration_wtime.c |
| 100 | 07_mpi | q100_mpi_master_worker_factorial.c |

Tip: `ls */q73*` or `find . -name 'q7*'` finds a question's files instantly.
Executables built by `build.sh` use the same names (in `./bin`).
