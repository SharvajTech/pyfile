/*
 * PROBLEM STATEMENT (Q69)
 * Write a concurrent TCP server using fork() that returns the uppercase form
 * of each line it receives. Test with two clients at the same time.
 */
/*
 * Q69 - Client for the concurrent uppercase server.
 * Compile : gcc q69_tcp_fork_uppercase_client.c -o q69_tcp_fork_uppercase_client
 * Run     : ./q69_tcp_fork_uppercase_client [server_ip]       (Ctrl-D to quit)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5069

int main(int argc, char *argv[])
{
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }

    char line[512], reply[512];
    printf("Type lines (Ctrl-D to quit):\n");
    while (fgets(line, sizeof line, stdin)) {
        write(s, line, strlen(line));
        ssize_t n = read(s, reply, sizeof reply - 1);
        if (n <= 0) break;
        reply[n] = '\0';
        printf("Server: %s", reply);
    }
    close(s);
    return 0;
}
