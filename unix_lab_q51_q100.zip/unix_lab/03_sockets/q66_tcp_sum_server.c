/*
 * PROBLEM STATEMENT (Q66)
 * Write a TCP server that receives two numbers from a client and returns
 * their sum. The client prints the result.
 */
/*
 * Q66 - TCP server: receives two numbers, returns their sum.
 * Compile : gcc q66_tcp_sum_server.c -o q66_tcp_sum_server
 *           gcc q66_tcp_sum_client.c -o q66_tcp_sum_client
 * Run     : Terminal 1: ./q66_tcp_sum_server
 *           Terminal 2: ./q66_tcp_sum_client [server_ip]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5066

int main(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 5);
    printf("Sum server listening on port %d\n", PORT);

    for (;;) {
        int c = accept(ls, NULL, NULL);
        if (c < 0) continue;
        char buf[128];
        ssize_t n = read(c, buf, sizeof buf - 1);
        if (n > 0) {
            buf[n] = '\0';
            double x, y;
            if (sscanf(buf, "%lf %lf", &x, &y) == 2) {
                char out[64];
                snprintf(out, sizeof out, "%g\n", x + y);
                printf("Received %g and %g -> sending %s", x, y, out);
                write(c, out, strlen(out));
            }
        }
        close(c);
    }
}
