/*
 * PROBLEM STATEMENT (Q71)
 * Write a TCP file transfer program: the client sends a file name and the
 * server sends back the file content, which the client saves.
 */
/*
 * Q71 - TCP file transfer, client: sends a file name, saves the returned
 *       content as  downloaded_<name>.
 * Compile : gcc q71_tcp_file_transfer_client.c -o q71_tcp_file_transfer_client
 * Run     : ./q71_tcp_file_transfer_client [server_ip] filename
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5071

int main(int argc, char *argv[])
{
    if (argc < 2) { fprintf(stderr, "Usage: %s [server_ip] filename\n", argv[0]); return 1; }
    const char *ip = argc > 2 ? argv[1] : "127.0.0.1";
    const char *fname = argv[argc - 1];

    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, ip, &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }

    write(s, fname, strlen(fname));

    char out[300];
    snprintf(out, sizeof out, "downloaded_%s", fname);
    FILE *f = fopen(out, "wb");
    if (!f) { perror("fopen"); return 1; }

    char buf[4096];
    ssize_t n;
    long total = 0;
    while ((n = read(s, buf, sizeof buf)) > 0) { fwrite(buf, 1, n, f); total += n; }
    fclose(f);
    close(s);

    if (total == 0) { remove(out); printf("File not found on server (or empty).\n"); }
    else printf("Saved %ld bytes to %s\n", total, out);
    return 0;
}
