/*
 * PROBLEM STATEMENT (Q70)
 * Write a multi-threaded TCP echo server in Java in which each client is
 * handled by a new thread.
 */
/*
 * Q70 - Multi-threaded TCP echo server in Java: one new thread per client.
 * Compile : javac Q70_MultiThreadEchoServer.java Q70_MultiThreadEchoClient.java
 * Run     : Terminal 1: java Q70_MultiThreadEchoServer
 *           Terminal 2: java Q70_MultiThreadEchoClient       (several at once)
 *           (or test with:  nc 127.0.0.1 5070)
 */
import java.io.*;
import java.net.*;

public class Q70_MultiThreadEchoServer {
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(5070);
        System.out.println("Echo server listening on port 5070");
        while (true) {
            Socket client = server.accept();
            new Thread(new ClientHandler(client)).start();   // new thread per client
        }
    }

    static class ClientHandler implements Runnable {
        private final Socket socket;
        ClientHandler(Socket s) { socket = s; }

        public void run() {
            String name = Thread.currentThread().getName();
            System.out.println(name + " handling " + socket.getRemoteSocketAddress());
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
                String line;
                while ((line = in.readLine()) != null) {
                    out.println("Echo: " + line);
                }
            } catch (IOException e) {
                System.out.println(name + " error: " + e.getMessage());
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
                System.out.println(name + " finished");
            }
        }
    }
}
