/*
 * PROBLEM STATEMENT (Q72)
 * Use getsockname() and getpeername() to print the local and remote IP
 * address and port of a connected socket. Also check the connection state
 * with ss -tan.
 */
/*
 * Q72 - Client side: prints local and remote address of its connected socket,
 *       then waits for Enter so you can inspect it with  ss -tan.
 * Compile : gcc q72_tcp_getsockname_peername_client.c -o q72_tcp_getsockname_peername_client
 * Run     : ./q72_tcp_getsockname_peername_client [server_ip]
 *           In another terminal:   ss -tan | grep 5072
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5072

int main(int argc, char *argv[])
{
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }

    struct sockaddr_in local, remote;
    socklen_t len = sizeof local;
    getsockname(s, (struct sockaddr *)&local, &len);
    len = sizeof remote;
    getpeername(s, (struct sockaddr *)&remote, &len);

    char lip[INET_ADDRSTRLEN], rip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &local.sin_addr, lip, sizeof lip);
    inet_ntop(AF_INET, &remote.sin_addr, rip, sizeof rip);
    printf("Local  (this client) : %s:%d\n", lip, ntohs(local.sin_port));
    printf("Remote (the server)  : %s:%d\n", rip, ntohs(remote.sin_port));

    printf("Connection is open. Run 'ss -tan | grep %d' now, then press Enter...", PORT);
    getchar();
    close(s);
    printf("Closed. Run 'ss -tan | grep %d' again to see TIME-WAIT.\n", PORT);
    return 0;
}
