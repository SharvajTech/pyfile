/*
 * PROBLEM STATEMENT (Q71)
 * Write a TCP file transfer program: the client sends a file name and the
 * server sends back the file content, which the client saves.
 */
/*
 * Q71 - TCP file transfer, server: receives a file name, sends the file
 *       content back, then closes the connection.
 * Compile : gcc q71_tcp_file_transfer_server.c -o q71_tcp_file_transfer_server
 *           gcc q71_tcp_file_transfer_client.c -o q71_tcp_file_transfer_client
 * Run     : Terminal 1 (in a directory holding files):  ./q71_tcp_file_transfer_server
 *           Terminal 2:  ./q71_tcp_file_transfer_client [server_ip] somefile.txt
 *                        -> saved as  downloaded_somefile.txt
 * Verify  : cmp somefile.txt downloaded_somefile.txt
 * Note    : only plain names in the server's current directory are served.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5071

int main(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 5);
    printf("File server on port %d\n", PORT);

    for (;;) {
        int c = accept(ls, NULL, NULL);
        if (c < 0) continue;
        char name[256];
        ssize_t n = read(c, name, sizeof name - 1);
        if (n > 0) {
            name[n] = '\0';
            name[strcspn(name, "\r\n")] = '\0';
            printf("Request for '%s'\n", name);
            int fd = strchr(name, '/') ? -1 : open(name, O_RDONLY);
            if (fd < 0) {
                printf("  cannot open file\n");
            } else {
                char buf[4096];
                ssize_t r;
                long total = 0;
                while ((r = read(fd, buf, sizeof buf)) > 0) { write(c, buf, r); total += r; }
                close(fd);
                printf("  sent %ld bytes\n", total);
            }
        }
        close(c);                 /* closing = end of file for the client */
    }
}
