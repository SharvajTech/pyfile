/*
 * PROBLEM STATEMENT (Q66)
 * Write a TCP server that receives two numbers from a client and returns
 * their sum. The client prints the result.
 */
/*
 * Q66 - TCP client: sends two numbers, prints the sum from the server.
 * Compile : gcc q66_tcp_sum_client.c -o q66_tcp_sum_client
 * Run     : ./q66_tcp_sum_client [server_ip]      (start q66_tcp_sum_server first)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5066

int main(int argc, char *argv[])
{
    double x, y;
    printf("Enter two numbers: ");
    if (scanf("%lf %lf", &x, &y) != 2) return 1;

    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }

    char buf[128];
    snprintf(buf, sizeof buf, "%g %g\n", x, y);
    write(s, buf, strlen(buf));

    ssize_t n = read(s, buf, sizeof buf - 1);
    if (n > 0) { buf[n] = '\0'; printf("Sum = %s", buf); }
    close(s);
    return 0;
}
