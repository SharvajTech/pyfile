/*
 * PROBLEM STATEMENT (Q65)
 * Write a TCP time server: when a client connects, the server sends the
 * current date and time (use time() and ctime()) and the client prints it.
 */
/*
 * Q65 - TCP time client: connects, prints the date/time sent by the server.
 * Compile : gcc q65_tcp_time_client.c -o q65_tcp_time_client
 * Run     : ./q65_tcp_time_client [server_ip]      (start q65_tcp_time_server first)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5065

int main(int argc, char *argv[])
{
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }

    char buf[128];
    ssize_t n = read(s, buf, sizeof buf - 1);
    if (n > 0) { buf[n] = '\0'; printf("Server time: %s", buf); }
    close(s);
    return 0;
}
