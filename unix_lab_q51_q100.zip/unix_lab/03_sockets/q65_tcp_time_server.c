/*
 * PROBLEM STATEMENT (Q65)
 * Write a TCP time server: when a client connects, the server sends the
 * current date and time (use time() and ctime()) and the client prints it.
 */
/*
 * Q65 - TCP time server: on every connection send the current date/time.
 * Compile : gcc q65_tcp_time_server.c -o q65_tcp_time_server
 *           gcc q65_tcp_time_client.c -o q65_tcp_time_client
 * Run     : Terminal 1: ./q65_tcp_time_server          (Ctrl-C to stop)
 *           Terminal 2: ./q65_tcp_time_client [server_ip]     (default 127.0.0.1)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5065

int main(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);

    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 5);
    printf("Time server listening on port %d\n", PORT);

    for (;;) {
        int c = accept(ls, NULL, NULL);
        if (c < 0) { perror("accept"); continue; }
        time_t t = time(NULL);
        char *s = ctime(&t);
        write(c, s, strlen(s));
        close(c);
    }
}
