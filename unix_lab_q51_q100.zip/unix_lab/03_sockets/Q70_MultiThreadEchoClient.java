/*
 * PROBLEM STATEMENT (Q70)
 * Write a multi-threaded TCP echo server in Java in which each client is
 * handled by a new thread.
 */
/*
 * Q70 - Simple client for Q70_MultiThreadEchoServer.
 * Compile : javac Q70_MultiThreadEchoClient.java
 * Run     : java Q70_MultiThreadEchoClient [host]       (Ctrl-D to quit)
 */
import java.io.*;
import java.net.*;

public class Q70_MultiThreadEchoClient {
    public static void main(String[] args) throws IOException {
        String host = args.length > 0 ? args[0] : "localhost";
        try (Socket s = new Socket(host, 5070);
             BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
             PrintWriter out = new PrintWriter(s.getOutputStream(), true);
             BufferedReader kb = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            System.out.print("Type: ");
            while ((line = kb.readLine()) != null) {
                out.println(line);
                System.out.println(in.readLine());
                System.out.print("Type: ");
            }
        }
    }
}
