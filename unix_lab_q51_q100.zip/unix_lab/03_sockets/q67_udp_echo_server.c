/*
 * PROBLEM STATEMENT (Q67)
 * Write a UDP echo server and client using sendto() and recvfrom().
 */
/*
 * Q67 - UDP echo server using recvfrom() / sendto().
 * Compile : gcc q67_udp_echo_server.c -o q67_udp_echo_server
 *           gcc q67_udp_echo_client.c -o q67_udp_echo_client
 * Run     : Terminal 1: ./q67_udp_echo_server
 *           Terminal 2: ./q67_udp_echo_client [server_ip]   (type "quit" to stop client)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5067

int main(void)
{
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0}, cli;
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    printf("UDP echo server on port %d\n", PORT);

    char buf[512];
    for (;;) {
        socklen_t len = sizeof cli;
        ssize_t n = recvfrom(s, buf, sizeof buf - 1, 0, (struct sockaddr *)&cli, &len);
        if (n < 0) { perror("recvfrom"); continue; }
        buf[n] = '\0';
        printf("From %s:%d -> %s", inet_ntoa(cli.sin_addr), ntohs(cli.sin_port), buf);
        sendto(s, buf, n, 0, (struct sockaddr *)&cli, len);
    }
}
