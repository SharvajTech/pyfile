/*
 * PROBLEM STATEMENT (Q68)
 * Write a TCP chat in which the server and client send messages alternately
 * until one of them types "bye".
 */
/*
 * Q68 - TCP chat, client side (speaks first).  Type "bye" to end.
 * Compile : gcc q68_tcp_chat_client.c -o q68_tcp_chat_client
 * Run     : ./q68_tcp_chat_client [server_ip]      (start q68_tcp_chat_server first)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5068

int main(int argc, char *argv[])
{
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("connect"); return 1; }
    printf("Connected. You talk first.\n");

    char buf[256];
    for (;;) {
        printf("You   : ");
        fflush(stdout);
        if (!fgets(buf, sizeof buf, stdin)) strcpy(buf, "bye\n");
        send(s, buf, strlen(buf), 0);
        if (strcmp(buf, "bye\n") == 0) break;

        ssize_t n = recv(s, buf, sizeof buf - 1, 0);
        if (n <= 0) { printf("Server disconnected.\n"); break; }
        buf[n] = '\0';
        printf("Server: %s", buf);
        if (strcmp(buf, "bye\n") == 0) break;
    }
    close(s);
    return 0;
}
