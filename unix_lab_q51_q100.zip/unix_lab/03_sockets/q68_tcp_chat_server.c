/*
 * PROBLEM STATEMENT (Q68)
 * Write a TCP chat in which the server and client send messages alternately
 * until one of them types "bye".
 */
/*
 * Q68 - TCP chat, server side.  Messages alternate: client speaks first,
 *       then server, and so on, until either side types "bye".
 * Compile : gcc q68_tcp_chat_server.c -o q68_tcp_chat_server
 *           gcc q68_tcp_chat_client.c -o q68_tcp_chat_client
 * Run     : Terminal 1: ./q68_tcp_chat_server
 *           Terminal 2: ./q68_tcp_chat_client [server_ip]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5068

int main(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 1);
    printf("Chat server waiting on port %d ...\n", PORT);
    int c = accept(ls, NULL, NULL);
    printf("Client connected. Client talks first.\n");

    char buf[256];
    for (;;) {
        ssize_t n = recv(c, buf, sizeof buf - 1, 0);
        if (n <= 0) { printf("Client disconnected.\n"); break; }
        buf[n] = '\0';
        printf("Client: %s", buf);
        if (strcmp(buf, "bye\n") == 0) break;

        printf("You   : ");
        fflush(stdout);
        if (!fgets(buf, sizeof buf, stdin)) strcpy(buf, "bye\n");
        send(c, buf, strlen(buf), 0);
        if (strcmp(buf, "bye\n") == 0) break;
    }
    close(c);
    close(ls);
    return 0;
}
