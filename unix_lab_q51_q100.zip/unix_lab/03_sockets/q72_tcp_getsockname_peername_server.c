/*
 * PROBLEM STATEMENT (Q72)
 * Use getsockname() and getpeername() to print the local and remote IP
 * address and port of a connected socket. Also check the connection state
 * with ss -tan.
 */
/*
 * Q72 - getsockname() / getpeername() : print local and remote IP:port of a
 *       connected socket.   (server side)
 * Compile : gcc q72_tcp_getsockname_peername_server.c -o q72_tcp_getsockname_peername_server
 *           gcc q72_tcp_getsockname_peername_client.c -o q72_tcp_getsockname_peername_client
 * Run     : Terminal 1: ./q72_tcp_getsockname_peername_server
 *           Terminal 2: ./q72_tcp_getsockname_peername_client            (waits for Enter)
 *           Terminal 3 (while both are connected):
 *                ss -tan | grep 5072        -> state ESTAB for both ends
 *           Press Enter in the client; then run  ss -tan | grep 5072  again
 *           -> TIME-WAIT / FIN states appear as the connection closes.
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5072

int main(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 1);
    printf("Server waiting on port %d (try: ss -tan | grep %d)\n", PORT, PORT);

    int c = accept(ls, NULL, NULL);

    struct sockaddr_in local, remote;
    socklen_t len = sizeof local;
    getsockname(c, (struct sockaddr *)&local, &len);
    len = sizeof remote;
    getpeername(c, (struct sockaddr *)&remote, &len);

    char lip[INET_ADDRSTRLEN], rip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &local.sin_addr, lip, sizeof lip);
    inet_ntop(AF_INET, &remote.sin_addr, rip, sizeof rip);
    printf("Local  (this server) : %s:%d\n", lip, ntohs(local.sin_port));
    printf("Remote (the client)  : %s:%d\n", rip, ntohs(remote.sin_port));

    char b;
    read(c, &b, 1);                    /* blocks until the client closes */
    printf("Client closed the connection.\n");
    close(c);
    close(ls);
    return 0;
}
