/*
 * PROBLEM STATEMENT (Q69)
 * Write a concurrent TCP server using fork() that returns the uppercase form
 * of each line it receives. Test with two clients at the same time.
 */
/*
 * Q69 - Concurrent TCP server (fork per client): returns each received
 *       line in UPPER CASE.
 * Compile : gcc q69_tcp_fork_uppercase_server.c -o q69_tcp_fork_uppercase_server
 *           gcc q69_tcp_fork_uppercase_client.c -o q69_tcp_fork_uppercase_client
 * Run     : Terminal 1: ./q69_tcp_fork_uppercase_server
 *           Terminal 2: ./q69_tcp_fork_uppercase_client      <- two clients at the same time
 *           Terminal 3: ./q69_tcp_fork_uppercase_client
 *           (Or test with:  nc 127.0.0.1 5069)
 * Check   : ps -ef | grep q69_tcp_fork_uppercase_server   shows one child per connected client.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5069

int main(void)
{
    signal(SIGCHLD, SIG_IGN);          /* auto-reap children (no zombies) */

    int ls = socket(AF_INET, SOCK_STREAM, 0);
    int on = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(PORT);
    if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(ls, 5);
    printf("Concurrent server on port %d\n", PORT);

    for (;;) {
        int c = accept(ls, NULL, NULL);
        if (c < 0) continue;
        if (fork() == 0) {                         /* child */
            close(ls);
            printf("Child %d serving a new client\n", (int)getpid());
            FILE *in = fdopen(c, "r");
            char line[512];
            while (fgets(line, sizeof line, in)) {
                for (char *p = line; *p; p++) *p = toupper((unsigned char)*p);
                write(c, line, strlen(line));
            }
            printf("Child %d: client left\n", (int)getpid());
            fclose(in);
            fflush(stdout); _exit(0);
        }
        close(c);                                  /* parent */
    }
}
