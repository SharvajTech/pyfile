/*
 * PROBLEM STATEMENT (Q67)
 * Write a UDP echo server and client using sendto() and recvfrom().
 */
/*
 * Q67 - UDP echo client.
 * Compile : gcc q67_udp_echo_client.c -o q67_udp_echo_client
 * Run     : ./q67_udp_echo_client [server_ip]     type lines; "quit" or Ctrl-D exits.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 5067

int main(int argc, char *argv[])
{
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0};
    a.sin_family = AF_INET;
    a.sin_port = htons(PORT);
    inet_pton(AF_INET, argc > 1 ? argv[1] : "127.0.0.1", &a.sin_addr);

    char line[512], reply[512];
    printf("Type text: ");
    while (fgets(line, sizeof line, stdin)) {
        if (strcmp(line, "quit\n") == 0) break;
        sendto(s, line, strlen(line), 0, (struct sockaddr *)&a, sizeof a);
        ssize_t n = recvfrom(s, reply, sizeof reply - 1, 0, NULL, NULL);
        if (n < 0) { perror("recvfrom"); break; }
        reply[n] = '\0';
        printf("Echo: %s", reply);
        printf("Type text: ");
    }
    close(s);
    return 0;
}
