/*
 * PROBLEM STATEMENT (Q55)
 * A server and two clients use one queue. Each client uses its own PID as
 * mtype for replies, and the server sends each reply to the correct client.
 */
/*
 * Q55 - Server for two (or more) clients on ONE queue.
 * Clients send requests with mtype = 1 and include their PID in the body.
 * The server replies using mtype = client PID, so each client receives
 * only its own reply.  Reply = request text in UPPER CASE.
 * Compile : gcc q55_msgq_multiclient_server.c -o q55_msgq_multiclient_server
 * Run     : Terminal 1: ./q55_msgq_multiclient_server        (Ctrl-C to stop; removes queue)
 *           Terminal 2: ./q55_msgq_multiclient_client
 *           Terminal 3: ./q55_msgq_multiclient_client
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct req { long mtype; pid_t pid; char text[100]; };
struct rep { long mtype; char text[100]; };

static int qid;
static void cleanup(int s) { (void)s; msgctl(qid, IPC_RMID, NULL); _exit(0); }

int main(void)
{
    qid = msgget(ftok(".", 'M'), IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }
    signal(SIGINT, cleanup);
    printf("Server ready.\n");

    for (;;) {
        struct req r;
        if (msgrcv(qid, &r, sizeof r - sizeof(long), 1, 0) == -1) { perror("msgrcv"); break; }
        printf("Request from client PID %d: %s\n", (int)r.pid, r.text);

        struct rep p;
        p.mtype = r.pid;                      /* reply addressed to that PID */
        size_t i;
        for (i = 0; r.text[i] && i < sizeof p.text - 1; i++)
            p.text[i] = toupper((unsigned char)r.text[i]);
        p.text[i] = '\0';
        msgsnd(qid, &p, sizeof p.text, 0);
    }
    return 0;
}
