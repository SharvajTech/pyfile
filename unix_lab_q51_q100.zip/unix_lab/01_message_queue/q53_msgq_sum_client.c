/*
 * PROBLEM STATEMENT (Q53)
 * The client sends a message containing two integers. The server replies
 * with their sum.
 */
/*
 * Q53 - Client: sends two integers, prints the sum returned by the server.
 * Compile : gcc q53_msgq_sum_client.c -o q53_msgq_sum_client
 * Run     : start ./q53_msgq_sum_server first, then ./q53_msgq_sum_client
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct req { long mtype; int a, b; };
struct rep { long mtype; int sum; };

int main(void)
{
    int qid = msgget(ftok(".", 'S'), 0666);
    if (qid == -1) { perror("msgget (is the server running?)"); return 1; }

    struct req r = { 1, 0, 0 };
    printf("Enter two integers: ");
    if (scanf("%d %d", &r.a, &r.b) != 2) return 1;
    msgsnd(qid, &r, 2 * sizeof(int), 0);

    struct rep p;
    msgrcv(qid, &p, sizeof(int), 2, 0);
    printf("Sum from server = %d\n", p.sum);
    return 0;
}
