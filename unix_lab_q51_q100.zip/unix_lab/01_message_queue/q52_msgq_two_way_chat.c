/*
 * PROBLEM STATEMENT (Q52)
 * Two programs chat through one queue: one sends with mtype 1 and receives
 * mtype 2, the other does the opposite. The chat stops when either side
 * types "bye".
 */
/*
 * Q52 - Two-way chat through ONE message queue.
 *   Program "A" sends with mtype 1 and receives mtype 2.
 *   Program "B" sends with mtype 2 and receives mtype 1.
 *   Chat stops when either side types "bye".
 * Compile : gcc q52_msgq_two_way_chat.c -o q52_msgq_two_way_chat
 * Run     : Terminal 1:  ./q52_msgq_two_way_chat A      (A speaks first)
 *           Terminal 2:  ./q52_msgq_two_way_chat B
 * Turns alternate: A types, B reads then types, and so on.
 * The side that receives "bye" removes the queue.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[256]; };

int main(int argc, char *argv[])
{
    if (argc != 2 || (argv[1][0] != 'A' && argv[1][0] != 'B')) {
        fprintf(stderr, "Usage: %s A|B\n", argv[0]);
        return 1;
    }
    int isA = (argv[1][0] == 'A');
    long sendtype = isA ? 1 : 2;
    long recvtype = isA ? 2 : 1;

    int qid = msgget(ftok(".", 'C'), IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }

    struct msgbuf m;
    int myturn = isA;
    for (;;) {
        if (myturn) {
            printf("[%c] you: ", argv[1][0]);
            fflush(stdout);
            if (!fgets(m.mtext, sizeof m.mtext, stdin)) strcpy(m.mtext, "bye");
            m.mtext[strcspn(m.mtext, "\n")] = '\0';
            m.mtype = sendtype;
            if (msgsnd(qid, &m, strlen(m.mtext) + 1, 0) == -1) { perror("msgsnd"); break; }
            if (strcmp(m.mtext, "bye") == 0) { printf("You ended the chat.\n"); break; }
        } else {
            printf("[%c] waiting...\n", argv[1][0]);
            if (msgrcv(qid, &m, sizeof m.mtext, recvtype, 0) == -1) { perror("msgrcv"); break; }
            printf("peer: %s\n", m.mtext);
            if (strcmp(m.mtext, "bye") == 0) {
                printf("Peer ended the chat.\n");
                msgctl(qid, IPC_RMID, NULL);
                break;
            }
        }
        myturn = !myturn;
    }
    return 0;
}
