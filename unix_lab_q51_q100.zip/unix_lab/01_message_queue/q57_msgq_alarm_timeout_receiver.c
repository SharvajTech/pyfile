/*
 * PROBLEM STATEMENT (Q57)
 * Write a receiver that waits for a message for at most 5 seconds using
 * alarm(). If nothing arrives, it prints a timeout message.
 */
/*
 * Q57 - Receiver that waits at most 5 seconds using alarm().
 * SIGALRM interrupts the blocking msgrcv() (errno == EINTR) because the
 * handler is installed WITHOUT SA_RESTART.
 * Compile : gcc q57_msgq_alarm_timeout_receiver.c -o q57_msgq_alarm_timeout_receiver
 *           gcc q57_msgq_alarm_timeout_sender.c -o q57_msgq_alarm_timeout_sender
 * Run     : ./q57_msgq_alarm_timeout_receiver                -> prints timeout after 5 s
 *           ./q57_msgq_alarm_timeout_receiver  then (within 5 s, other terminal) ./q57_msgq_alarm_timeout_sender
 * Note    : this receiver removes the queue when it exits.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[100]; };

static void on_alarm(int s) { (void)s; }   /* just interrupts msgrcv */

int main(void)
{
    int qid = msgget(ftok(".", 'T'), IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }

    struct sigaction sa = {0};
    sa.sa_handler = on_alarm;
    sa.sa_flags = 0;                       /* no SA_RESTART */
    sigaction(SIGALRM, &sa, NULL);

    printf("Waiting up to 5 seconds for a message...\n");
    alarm(5);
    struct msgbuf m;
    ssize_t n = msgrcv(qid, &m, sizeof m.mtext, 0, 0);
    if (n == -1 && errno == EINTR)
        printf("Timeout: no message arrived within 5 seconds.\n");
    else if (n == -1)
        perror("msgrcv");
    else {
        alarm(0);                          /* cancel pending alarm */
        printf("Received: %s\n", m.mtext);
    }
    msgctl(qid, IPC_RMID, NULL);
    return 0;
}
