/*
 * PROBLEM STATEMENT (Q51)
 * Write a sender and a receiver. Before receiving, print the number of
 * messages waiting in the queue using msgctl(IPC_STAT) (msg_qnum).
 */
/*
 * Q51 - Receiver (pairs with q51_msgq_qnum_sender.c)
 * Compile : gcc q51_msgq_qnum_receiver.c -o q51_msgq_qnum_receiver
 * Run     : first ./q51_msgq_qnum_sender, then ./q51_msgq_qnum_receiver
 * Output  : number of messages waiting (msg_qnum from msgctl IPC_STAT),
 *           then every message; finally the queue is removed.
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[128]; };

int main(void)
{
    key_t key = ftok(".", 'Q');
    int qid = msgget(key, 0666);
    if (qid == -1) { perror("msgget (run q51_msgq_qnum_sender first)"); exit(1); }

    struct msqid_ds info;
    if (msgctl(qid, IPC_STAT, &info) == -1) { perror("msgctl"); exit(1); }
    printf("Messages waiting in the queue: %lu\n", (unsigned long)info.msg_qnum);

    struct msgbuf m;
    while (msgrcv(qid, &m, sizeof m.mtext, 0, IPC_NOWAIT) != -1)
        printf("Received: %s\n", m.mtext);

    msgctl(qid, IPC_RMID, NULL);   /* cleanup */
    return 0;
}
