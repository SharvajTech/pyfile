/*
 * PROBLEM STATEMENT (Q57)
 * Write a receiver that waits for a message for at most 5 seconds using
 * alarm(). If nothing arrives, it prints a timeout message.
 */
/*
 * Q57 - Helper sender for q57_msgq_alarm_timeout_receiver.c
 * Compile : gcc q57_msgq_alarm_timeout_sender.c -o q57_msgq_alarm_timeout_sender
 * Run     : ./q57_msgq_alarm_timeout_sender   (while q57_msgq_alarm_timeout_receiver is waiting)
 */
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[100]; };

int main(void)
{
    int qid = msgget(ftok(".", 'T'), IPC_CREAT | 0666);
    struct msgbuf m = { 1, "Hello before the timeout!" };
    msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
    printf("Message sent.\n");
    return 0;
}
