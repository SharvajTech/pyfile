/*
 * PROBLEM STATEMENT (Q53)
 * The client sends a message containing two integers. The server replies
 * with their sum.
 */
/*
 * Q53 - Server: receives two integers, replies with their sum.
 * Compile : gcc q53_msgq_sum_server.c -o q53_msgq_sum_server
 * Run     : Terminal 1:  ./q53_msgq_sum_server      (Ctrl-C stops it and removes the queue)
 *           Terminal 2:  ./q53_msgq_sum_client
 * Request mtype = 1, reply mtype = 2.
 */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct req { long mtype; int a, b; };
struct rep { long mtype; int sum; };

static int qid;
static void cleanup(int s) { (void)s; msgctl(qid, IPC_RMID, NULL); _exit(0); }

int main(void)
{
    qid = msgget(ftok(".", 'S'), IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); return 1; }
    signal(SIGINT, cleanup);
    printf("Server ready (Ctrl-C to quit)\n");

    for (;;) {
        struct req r;
        if (msgrcv(qid, &r, 2 * sizeof(int), 1, 0) == -1) { perror("msgrcv"); break; }
        printf("Request: %d + %d\n", r.a, r.b);
        struct rep p = { 2, r.a + r.b };
        msgsnd(qid, &p, sizeof(int), 0);
    }
    return 0;
}
