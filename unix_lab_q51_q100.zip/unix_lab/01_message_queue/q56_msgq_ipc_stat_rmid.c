/*
 * PROBLEM STATEMENT (Q56)
 * Use msgctl(IPC_STAT) to print the owner UID, permissions, number of
 * messages and maximum bytes of a queue. Then remove the queue using
 * IPC_RMID.
 */
/*
 * Q56 - msgctl(IPC_STAT): print owner UID, permissions, number of messages
 *       and maximum bytes of a queue; then remove it with IPC_RMID.
 * Compile : gcc q56_msgq_ipc_stat_rmid.c -o q56_msgq_ipc_stat_rmid
 * Run     : ./q56_msgq_ipc_stat_rmid
 * Check   : ipcs -q   (before/after - queue is gone at the end)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[32]; };

int main(void)
{
    int qid = msgget(IPC_PRIVATE, IPC_CREAT | 0640);
    if (qid == -1) { perror("msgget"); return 1; }

    struct msgbuf m = { 1, "hello" };
    msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
    msgsnd(qid, &m, strlen(m.mtext) + 1, 0);

    struct msqid_ds info;
    if (msgctl(qid, IPC_STAT, &info) == -1) { perror("IPC_STAT"); return 1; }
    printf("Queue id            : %d\n", qid);
    printf("Owner UID           : %d\n", (int)info.msg_perm.uid);
    printf("Permissions (octal) : %o\n", (unsigned)(info.msg_perm.mode & 0777));
    printf("Messages in queue   : %lu\n", (unsigned long)info.msg_qnum);
    printf("Max bytes in queue  : %lu\n", (unsigned long)info.msg_qbytes);

    if (msgctl(qid, IPC_RMID, NULL) == -1) { perror("IPC_RMID"); return 1; }
    printf("Queue removed with IPC_RMID.\n");
    return 0;
}
