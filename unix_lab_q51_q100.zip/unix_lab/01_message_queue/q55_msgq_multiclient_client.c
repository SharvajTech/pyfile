/*
 * PROBLEM STATEMENT (Q55)
 * A server and two clients use one queue. Each client uses its own PID as
 * mtype for replies, and the server sends each reply to the correct client.
 */
/*
 * Q55 - Client.  Sends a line to the server (mtype 1, with own PID) and
 * waits for the reply whose mtype equals its own PID.
 * Compile : gcc q55_msgq_multiclient_client.c -o q55_msgq_multiclient_client
 * Run     : start ./q55_msgq_multiclient_server first, then run this in two terminals.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct req { long mtype; pid_t pid; char text[100]; };
struct rep { long mtype; char text[100]; };

int main(void)
{
    int qid = msgget(ftok(".", 'M'), 0666);
    if (qid == -1) { perror("msgget (is the server running?)"); return 1; }

    struct req r;
    r.mtype = 1;
    r.pid = getpid();
    printf("[client %d] Enter text: ", (int)r.pid);
    if (!fgets(r.text, sizeof r.text, stdin)) return 1;
    r.text[strcspn(r.text, "\n")] = '\0';
    msgsnd(qid, &r, sizeof r - sizeof(long), 0);

    struct rep p;
    msgrcv(qid, &p, sizeof p.text, getpid(), 0);   /* only MY replies */
    printf("[client %d] Reply: %s\n", (int)r.pid, p.text);
    return 0;
}
