/*
 * PROBLEM STATEMENT (Q54)
 * Send five messages with different mtype values and receive them using a
 * negative msgtyp. Show that the messages come out in order of lowest type
 * first.
 */
/*
 * Q54 - Five messages with different mtypes, received with a NEGATIVE msgtyp.
 * msgrcv(..., msgtyp = -5, ...) returns the message with the LOWEST mtype
 * that is <= 5, so messages come out in order of lowest type first,
 * regardless of the order in which they were sent.
 * Compile : gcc q54_msgq_negative_msgtyp.c -o q54_msgq_negative_msgtyp
 * Run     : ./q54_msgq_negative_msgtyp
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[64]; };

int main(void)
{
    int qid = msgget(IPC_PRIVATE, IPC_CREAT | 0600);
    if (qid == -1) { perror("msgget"); return 1; }

    long types[5] = { 5, 2, 4, 1, 3 };          /* deliberately unordered */
    struct msgbuf m;
    printf("Sending order : ");
    for (int i = 0; i < 5; i++) {
        m.mtype = types[i];
        snprintf(m.mtext, sizeof m.mtext, "message with type %ld", types[i]);
        msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
        printf("%ld ", types[i]);
    }
    printf("\n\nReceiving with msgtyp = -5:\n");
    for (int i = 0; i < 5; i++) {
        msgrcv(qid, &m, sizeof m.mtext, -5, 0);
        printf("  got type %ld -> \"%s\"\n", m.mtype, m.mtext);
    }
    msgctl(qid, IPC_RMID, NULL);
    return 0;
}
