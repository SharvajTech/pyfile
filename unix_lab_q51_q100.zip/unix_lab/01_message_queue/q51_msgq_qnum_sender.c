/*
 * PROBLEM STATEMENT (Q51)
 * Write a sender and a receiver. Before receiving, print the number of
 * messages waiting in the queue using msgctl(IPC_STAT) (msg_qnum).
 */
/*
 * Q51 - Sender (pairs with q51_msgq_qnum_receiver.c)
 * Compile : gcc q51_msgq_qnum_sender.c -o q51_msgq_qnum_sender
 * Run     : ./q51_msgq_qnum_sender      (puts 3 messages in the queue, then exits)
 *           ./q51_msgq_qnum_receiver    (prints msg_qnum first, then reads the messages)
 * Check   : ipcs -q           (queue stays alive between the two runs)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msgbuf { long mtype; char mtext[128]; };

int main(void)
{
    key_t key = ftok(".", 'Q');
    if (key == -1) { perror("ftok"); exit(1); }
    int qid = msgget(key, IPC_CREAT | 0666);
    if (qid == -1) { perror("msgget"); exit(1); }

    struct msgbuf m;
    m.mtype = 1;
    for (int i = 1; i <= 3; i++) {
        snprintf(m.mtext, sizeof m.mtext, "Message number %d", i);
        if (msgsnd(qid, &m, strlen(m.mtext) + 1, 0) == -1) { perror("msgsnd"); exit(1); }
        printf("Sent: %s\n", m.mtext);
    }
    return 0;
}
