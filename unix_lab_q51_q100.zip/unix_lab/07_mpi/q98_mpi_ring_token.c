/*
 * PROBLEM STATEMENT (Q98)
 * Pass a token around a ring of processes: process 0 starts it, each process
 * adds its rank, and process 0 prints the final value.
 */
/*
 * Q98 - Token ring: process 0 starts the token, each process adds its rank
 *       and passes it on; process 0 prints the final value
 *       (= 0 + 1 + ... + (size-1)).
 * Compile : mpicc q98_mpi_ring_token.c -o q98_mpi_ring_token
 * Run     : mpirun -np 5 ./q98_mpi_ring_token        (expect 10 for 5 processes)
 */
#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size, token;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size == 1) {
        printf("Only one process; token = 0\n");
    } else if (rank == 0) {
        token = 0;                                   /* start; adds its rank (0) */
        printf("Process 0 starts the token with value %d\n", token);
        MPI_Send(&token, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        MPI_Recv(&token, 1, MPI_INT, size - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 0 received the final token: %d\n", token);
    } else {
        MPI_Recv(&token, 1, MPI_INT, rank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        token += rank;
        printf("Process %d adds its rank -> token = %d\n", rank, token);
        MPI_Send(&token, 1, MPI_INT, (rank + 1) % size, 0, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}
