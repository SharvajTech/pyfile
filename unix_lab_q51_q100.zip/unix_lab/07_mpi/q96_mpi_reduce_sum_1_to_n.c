/*
 * PROBLEM STATEMENT (Q96)
 * Compute the sum of 1 to N by splitting the range among the processes. Each
 * process computes a partial sum and MPI_Reduce() collects the total at
 * process 0.
 */
/*
 * Q96 - Sum 1..N by splitting the range among processes; each computes a
 *       partial sum and MPI_Reduce collects the total at process 0.
 * Compile : mpicc q96_mpi_reduce_sum_1_to_n.c -o q96_mpi_reduce_sum_1_to_n
 * Run     : mpirun -np 4 ./q96_mpi_reduce_sum_1_to_n [N]       (default N = 1000)
 */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    long long N = (argc > 1) ? atoll(argv[1]) : 1000;

    /* contiguous block for each process */
    long long chunk = N / size;
    long long start = rank * chunk + 1;
    long long end   = (rank == size - 1) ? N : start + chunk - 1;   /* last takes remainder */

    long long partial = 0;
    for (long long i = start; i <= end; i++) partial += i;
    printf("Process %d sums %lld..%lld = %lld\n", rank, start, end, partial);

    long long total = 0;
    MPI_Reduce(&partial, &total, 1, MPI_LONG_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
        printf("Total of 1..%lld = %lld   (formula: %lld)\n", N, total, N * (N + 1) / 2);
    MPI_Finalize();
    return 0;
}
