/*
 * PROBLEM STATEMENT (Q100)
 * Write a master-worker program: the master sends a different number to each
 * worker, each worker returns the factorial of its number, and the master
 * prints all the results.
 */
/*
 * Q100 - Master/worker: the master sends a different number to each worker;
 *        each worker returns the factorial of its number; the master prints
 *        all results.
 * Compile : mpicc q100_mpi_master_worker_factorial.c -o q100_mpi_master_worker_factorial
 * Run     : mpirun -np 5 ./q100_mpi_master_worker_factorial        (1 master + 4 workers)
 * Note    : worker k gets number k+2 (3,4,5,...); keep -np <= 19 so that the
 *           factorial (max 20!) fits in unsigned long long.
 */
#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size < 2 || size > 19) {
        if (rank == 0) fprintf(stderr, "Use between 2 and 19 processes\n");
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {                                  /* master */
        for (int w = 1; w < size; w++) {
            int num = w + 2;
            MPI_Send(&num, 1, MPI_INT, w, 0, MPI_COMM_WORLD);
            printf("Master sent %d to worker %d\n", num, w);
        }
        for (int w = 1; w < size; w++) {
            unsigned long long fact;
            MPI_Recv(&fact, 1, MPI_UNSIGNED_LONG_LONG, w, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            printf("Result from worker %d: %d! = %llu\n", w, w + 2, fact);
        }
    } else {                                          /* worker */
        int num;
        MPI_Recv(&num, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        unsigned long long fact = 1;
        for (int i = 2; i <= num; i++) fact *= i;
        MPI_Send(&fact, 1, MPI_UNSIGNED_LONG_LONG, 0, 1, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}
