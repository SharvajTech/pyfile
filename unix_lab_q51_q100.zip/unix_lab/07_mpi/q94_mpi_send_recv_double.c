/*
 * PROBLEM STATEMENT (Q94)
 * Process 0 sends an integer to process 1 using MPI_Send(). Process 1
 * doubles it and sends it back using MPI_Recv() and MPI_Send(). Process 0
 * prints the result.
 */
/*
 * Q94 - Process 0 sends an integer to process 1; process 1 doubles it and
 *       sends it back; process 0 prints the result.
 * Compile : mpicc q94_mpi_send_recv_double.c -o q94_mpi_send_recv_double
 * Run     : mpirun -np 2 ./q94_mpi_send_recv_double
 */
#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size, value;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size < 2) {
        if (rank == 0) fprintf(stderr, "Need at least 2 processes\n");
        MPI_Finalize();
        return 1;
    }

    if (rank == 0) {
        value = 21;
        printf("Process 0 sends %d to process 1\n", value);
        MPI_Send(&value, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        MPI_Recv(&value, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 0 received back %d\n", value);
    } else if (rank == 1) {
        MPI_Recv(&value, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        printf("Process 1 received %d, doubling it\n", value);
        value *= 2;
        MPI_Send(&value, 1, MPI_INT, 0, 1, MPI_COMM_WORLD);
    }
    MPI_Finalize();
    return 0;
}
