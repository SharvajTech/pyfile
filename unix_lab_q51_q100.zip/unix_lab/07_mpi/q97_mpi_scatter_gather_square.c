/*
 * PROBLEM STATEMENT (Q97)
 * Distribute an array of 8 integers among 4 processes using MPI_Scatter().
 * Each process squares its elements and the results are collected using
 * MPI_Gather().
 */
/*
 * Q97 - Distribute 8 integers among 4 processes with MPI_Scatter; each
 *       squares its 2 elements; results are collected with MPI_Gather.
 * Compile : mpicc q97_mpi_scatter_gather_square.c -o q97_mpi_scatter_gather_square
 * Run     : mpirun -np 4 ./q97_mpi_scatter_gather_square          (exactly 4 processes)
 */
#include <stdio.h>
#include <mpi.h>

#define TOTAL 8

int main(int argc, char *argv[])
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    if (size != 4) {
        if (rank == 0) fprintf(stderr, "Run with exactly 4 processes: mpirun -np 4 ./q97_mpi_scatter_gather_square\n");
        MPI_Finalize();
        return 1;
    }

    int data[TOTAL] = { 1, 2, 3, 4, 5, 6, 7, 8 };
    int result[TOTAL];
    int per = TOTAL / size;                 /* 2 elements each */
    int mine[TOTAL];

    if (rank == 0) {
        printf("Original array:");
        for (int i = 0; i < TOTAL; i++) printf(" %d", data[i]);
        printf("\n");
    }

    MPI_Scatter(data, per, MPI_INT, mine, per, MPI_INT, 0, MPI_COMM_WORLD);

    for (int i = 0; i < per; i++) mine[i] *= mine[i];       /* square */
    printf("Process %d squared its part: %d %d\n", rank, mine[0], mine[1]);

    MPI_Gather(mine, per, MPI_INT, result, per, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Gathered result:");
        for (int i = 0; i < TOTAL; i++) printf(" %d", result[i]);
        printf("\n");
    }
    MPI_Finalize();
    return 0;
}
