/*
 * PROBLEM STATEMENT (Q99)
 * Compute the value of pi using numerical integration with MPI. Each process
 * handles a part of the intervals and MPI_Reduce() adds the results. Print
 * the time using MPI_Wtime().
 */
/*
 * Q99 - Compute pi by numerical integration of 4/(1+x^2) over [0,1].
 *       Each process handles part of the intervals; MPI_Reduce adds the
 *       results; time measured with MPI_Wtime().
 * Compile : mpicc -O2 q99_mpi_pi_integration_wtime.c -o q99_mpi_pi_integration_wtime
 * Run     : mpirun -np 4 ./q99_mpi_pi_integration_wtime [intervals]     (default 100,000,000)
 *           Try -np 1, 2, 4 and compare the times.
 */
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    long n = (argc > 1) ? atol(argv[1]) : 100000000L;
    double dx = 1.0 / n;

    MPI_Barrier(MPI_COMM_WORLD);
    double t0 = MPI_Wtime();

    double local = 0.0;
    for (long i = rank; i < n; i += size) {          /* every size-th interval */
        double x = (i + 0.5) * dx;
        local += 4.0 / (1.0 + x * x);
    }
    local *= dx;

    double pi = 0.0;
    MPI_Reduce(&local, &pi, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    MPI_Barrier(MPI_COMM_WORLD);
    double t1 = MPI_Wtime();

    if (rank == 0) {
        printf("pi ~= %.12f   (error %.2e)\n", pi, pi - 3.141592653589793);
        printf("Processes = %d, intervals = %ld, time = %.4f s\n", size, n, t1 - t0);
    }
    MPI_Finalize();
    return 0;
}
