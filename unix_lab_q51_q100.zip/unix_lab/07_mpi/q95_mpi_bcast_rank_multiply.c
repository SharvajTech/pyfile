/*
 * PROBLEM STATEMENT (Q95)
 * Broadcast a value from process 0 using MPI_Bcast(). Every process prints
 * the value multiplied by its rank.
 */
/*
 * Q95 - Broadcast a value from process 0 with MPI_Bcast; every process
 *       prints the value multiplied by its rank.
 * Compile : mpicc q95_mpi_bcast_rank_multiply.c -o q95_mpi_bcast_rank_multiply
 * Run     : mpirun -np 4 ./q95_mpi_bcast_rank_multiply
 */
#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size, value = 0;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) value = 10;                       /* only root knows it */
    MPI_Bcast(&value, 1, MPI_INT, 0, MPI_COMM_WORLD);

    printf("Process %d: value = %d, value * rank = %d\n", rank, value, value * rank);
    MPI_Finalize();
    return 0;
}
