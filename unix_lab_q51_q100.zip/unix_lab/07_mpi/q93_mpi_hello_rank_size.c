/*
 * PROBLEM STATEMENT (Q93)
 * Write an MPI hello program in which every process prints its rank and the
 * total number of processes. Run it with mpirun -np 4.
 */
/*
 * Q93 - MPI hello: every process prints its rank and the total processes.
 * Compile : mpicc q93_mpi_hello_rank_size.c -o q93_mpi_hello_rank_size
 * Run     : mpirun -np 4 ./q93_mpi_hello_rank_size
 *           (if you get "not enough slots":  mpirun --oversubscribe -np 4 ./q93_mpi_hello_rank_size)
 * Install : sudo apt install mpich     (or openmpi-bin libopenmpi-dev)
 */
#include <stdio.h>
#include <mpi.h>

int main(int argc, char *argv[])
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    printf("Hello from process %d of %d\n", rank, size);
    MPI_Finalize();
    return 0;
}
