/*
 * PROBLEM STATEMENT (Q77)
 * The parent writes the contents of a text file into a pipe. The child
 * counts the lines, words and characters.
 */
/*
 * Q77 - Parent writes a text file into a pipe; child counts lines, words
 *       and characters (like wc).
 * Compile : gcc q77_pipe_file_wc_lines_words_chars.c -o q77_pipe_file_wc_lines_words_chars
 * Run     : ./q77_pipe_file_wc_lines_words_chars somefile.txt        (compare with: wc somefile.txt)
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s file\n", argv[0]); return 1; }
    int file = open(argv[1], O_RDONLY);
    if (file < 0) { perror("open"); return 1; }

    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    if (fork() == 0) {                    /* child: counts */
        close(fd[1]);
        char buf[4096];
        ssize_t n;
        long lines = 0, words = 0, chars = 0;
        int inword = 0;
        while ((n = read(fd[0], buf, sizeof buf)) > 0) {
            for (ssize_t i = 0; i < n; i++) {
                chars++;
                if (buf[i] == '\n') lines++;
                if (isspace((unsigned char)buf[i])) inword = 0;
                else if (!inword) { inword = 1; words++; }
            }
        }
        printf("Lines: %ld  Words: %ld  Characters: %ld\n", lines, words, chars);
        fflush(stdout); _exit(0);
    }
    close(fd[0]);                         /* parent: writes file to pipe */
    char buf[4096];
    ssize_t n;
    while ((n = read(file, buf, sizeof buf)) > 0) write(fd[1], buf, n);
    close(fd[1]);
    close(file);
    wait(NULL);
    return 0;
}
