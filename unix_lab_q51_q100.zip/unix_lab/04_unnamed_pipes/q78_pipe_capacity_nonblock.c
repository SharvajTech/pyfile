/*
 * PROBLEM STATEMENT (Q78)
 * Find the capacity of a pipe: set the write end to O_NONBLOCK and write one
 * byte at a time until the write fails. Print the number of bytes written.
 */
/*
 * Q78 - Find the capacity of a pipe: make the write end O_NONBLOCK and
 *       write one byte at a time until write() fails (EAGAIN).
 * Compile : gcc q78_pipe_capacity_nonblock.c -o q78_pipe_capacity_nonblock
 * Run     : ./q78_pipe_capacity_nonblock       (Linux default is normally 65536 bytes)
 * Check   : ulimit -a | grep pipe   (shows 512-byte blocks per pipe buffer)
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int main(void)
{
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    int flags = fcntl(fd[1], F_GETFL);
    fcntl(fd[1], F_SETFL, flags | O_NONBLOCK);

    long count = 0;
    char c = 'x';
    while (write(fd[1], &c, 1) == 1) count++;

    printf("write() failed: %s\n", strerror(errno));
    printf("Pipe capacity = %ld bytes\n", count);
    return 0;
}
