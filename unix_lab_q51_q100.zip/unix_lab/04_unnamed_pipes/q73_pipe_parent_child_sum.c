/*
 * PROBLEM STATEMENT (Q73)
 * The parent sends two numbers through a pipe. The child adds them and
 * prints the sum.
 */
/*
 * Q73 - Parent sends two numbers through a pipe; child adds and prints sum.
 * Compile : gcc q73_pipe_parent_child_sum.c -o q73_pipe_parent_child_sum
 * Run     : ./q73_pipe_parent_child_sum
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    pid_t pid = fork();
    if (pid == 0) {                       /* child: reader */
        close(fd[1]);
        int n[2];
        read(fd[0], n, sizeof n);
        printf("Child: %d + %d = %d\n", n[0], n[1], n[0] + n[1]);
        close(fd[0]);
        fflush(stdout); _exit(0);
    }
    close(fd[0]);                         /* parent: writer */
    int n[2];
    printf("Parent: enter two integers: ");
    if (scanf("%d %d", &n[0], &n[1]) != 2) return 1;
    write(fd[1], n, sizeof n);
    close(fd[1]);
    wait(NULL);
    return 0;
}
