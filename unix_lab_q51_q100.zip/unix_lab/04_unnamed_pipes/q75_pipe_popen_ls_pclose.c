/*
 * PROBLEM STATEMENT (Q75)
 * Use popen() to run ls -l, count the lines of its output, and print the
 * exit status returned by pclose().
 */
/*
 * Q75 - popen() runs "ls -l"; count the lines of its output and print the
 *       exit status returned by pclose().
 * Compile : gcc q75_pipe_popen_ls_pclose.c -o q75_pipe_popen_ls_pclose
 * Run     : ./q75_pipe_popen_ls_pclose
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(void)
{
    FILE *fp = popen("ls -l", "r");
    if (!fp) { perror("popen"); return 1; }

    char line[1024];
    int lines = 0;
    while (fgets(line, sizeof line, fp)) lines++;

    int status = pclose(fp);
    printf("Lines in 'ls -l' output : %d\n", lines);
    printf("pclose() raw status      : %d\n", status);
    if (WIFEXITED(status))
        printf("Exit status of ls -l     : %d\n", WEXITSTATUS(status));
    return 0;
}
