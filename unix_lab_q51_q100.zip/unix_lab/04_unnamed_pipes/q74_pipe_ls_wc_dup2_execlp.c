/*
 * PROBLEM STATEMENT (Q74)
 * Implement the shell command ls | wc -l using pipe(), fork(), dup2() and
 * execlp().
 */
/*
 * Q74 - Implement the shell command   ls | wc -l   with pipe(), fork(),
 *       dup2() and execlp().
 * Compile : gcc q74_pipe_ls_wc_dup2_execlp.c -o q74_pipe_ls_wc_dup2_execlp
 * Run     : ./q74_pipe_ls_wc_dup2_execlp          (compare with:  ls | wc -l)
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    if (fork() == 0) {                    /* child 1: ls  (stdout -> pipe) */
        dup2(fd[1], STDOUT_FILENO);
        close(fd[0]); close(fd[1]);
        execlp("ls", "ls", (char *)NULL);
        perror("execlp ls"); _exit(127);
    }
    if (fork() == 0) {                    /* child 2: wc -l (stdin <- pipe) */
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]); close(fd[1]);
        execlp("wc", "wc", "-l", (char *)NULL);
        perror("execlp wc"); _exit(127);
    }
    close(fd[0]); close(fd[1]);           /* parent must close both ends */
    wait(NULL); wait(NULL);
    return 0;
}
