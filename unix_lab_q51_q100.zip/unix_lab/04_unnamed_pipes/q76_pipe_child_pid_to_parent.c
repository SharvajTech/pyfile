/*
 * PROBLEM STATEMENT (Q76)
 * The child sends its PID and a short message to the parent through a pipe.
 * The parent reads in a loop until end of file and prints them.
 */
/*
 * Q76 - Child sends its PID and a short message to the parent through a
 *       pipe.  Parent reads in a loop until EOF and prints everything.
 * Compile : gcc q76_pipe_child_pid_to_parent.c -o q76_pipe_child_pid_to_parent
 * Run     : ./q76_pipe_child_pid_to_parent
 * Note    : EOF arrives only when ALL write ends are closed, so the parent
 *           must close its own copy of the write end.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return 1; }

    if (fork() == 0) {                    /* child */
        close(fd[0]);
        char msg[100];
        snprintf(msg, sizeof msg, "Child PID = %d\n", (int)getpid());
        write(fd[1], msg, strlen(msg));
        strcpy(msg, "Message: Hello parent, greetings from the child!\n");
        write(fd[1], msg, strlen(msg));
        close(fd[1]);
        _exit(0);
    }
    close(fd[1]);                         /* parent closes write end */
    char buf[64];
    ssize_t n;
    printf("Parent received:\n");
    while ((n = read(fd[0], buf, sizeof buf - 1)) > 0) {   /* until EOF */
        buf[n] = '\0';
        printf("%s", buf);
    }
    close(fd[0]);
    wait(NULL);
    return 0;
}
