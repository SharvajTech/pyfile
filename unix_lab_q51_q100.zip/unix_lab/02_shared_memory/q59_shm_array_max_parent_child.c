/*
 * PROBLEM STATEMENT (Q59)
 * The parent writes an array of 10 integers into shared memory. The child
 * finds the largest value and stores it in the same segment. The parent
 * prints it.
 */
/*
 * Q59 - Parent writes 10 integers into shared memory, child finds the
 *       largest value and stores it in the same segment, parent prints it.
 * Compile : gcc q59_shm_array_max_parent_child.c -o q59_shm_array_max_parent_child
 * Run     : ./q59_shm_array_max_parent_child
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

struct shared { int arr[10]; int max; };

int main(void)
{
    int id = shmget(IPC_PRIVATE, sizeof(struct shared), IPC_CREAT | 0600);
    if (id == -1) { perror("shmget"); return 1; }
    struct shared *s = shmat(id, NULL, 0);
    if (s == (void *)-1) { perror("shmat"); return 1; }

    int data[10] = { 12, 45, 7, 89, 23, 56, 91, 3, 67, 38 };
    printf("Parent writes:");
    for (int i = 0; i < 10; i++) { s->arr[i] = data[i]; printf(" %d", s->arr[i]); }
    printf("\n");

    pid_t pid = fork();
    if (pid == 0) {                              /* child */
        int m = s->arr[0];
        for (int i = 1; i < 10; i++) if (s->arr[i] > m) m = s->arr[i];
        s->max = m;
        shmdt(s);
        _exit(0);
    }
    wait(NULL);                                  /* parent waits for child */
    printf("Largest value (found by child) = %d\n", s->max);

    shmdt(s);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
