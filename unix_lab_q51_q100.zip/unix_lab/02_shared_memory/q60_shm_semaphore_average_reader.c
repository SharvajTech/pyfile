/*
 * PROBLEM STATEMENT (Q60)
 * One process writes 5 numbers into shared memory and another reads them and
 * prints the average. Synchronise them with a semaphore.
 */
/*
 * Q60 - Reader: waits on the semaphore, then prints the average of the
 *       5 numbers found in shared memory.  Cleans up the segment/semaphore.
 * Compile : gcc q60_shm_semaphore_average_reader.c -o q60_shm_semaphore_average_reader -pthread
 * Run     : see q60_shm_semaphore_writer.c
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(void)
{
    int id = shmget(ftok(".", 'A'), 5 * sizeof(int), IPC_CREAT | 0666);
    int *a = shmat(id, NULL, 0);
    if (id == -1 || a == (void *)-1) { perror("shm"); return 1; }
    sem_t *sem = sem_open("/q60_sem", O_CREAT, 0666, 0);
    if (sem == SEM_FAILED) { perror("sem_open"); return 1; }

    printf("Reader: waiting for the writer...\n");
    sem_wait(sem);                      /* blocks until writer posts */

    int sum = 0;
    printf("Numbers:");
    for (int i = 0; i < 5; i++) { printf(" %d", a[i]); sum += a[i]; }
    printf("\nAverage = %.2f\n", sum / 5.0);

    sem_close(sem);
    sem_unlink("/q60_sem");
    shmdt(a);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
