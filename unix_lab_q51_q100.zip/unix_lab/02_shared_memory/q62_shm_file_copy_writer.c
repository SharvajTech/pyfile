/*
 * PROBLEM STATEMENT (Q62)
 * Copy a file using shared memory: program 1 writes the file contents into
 * the segment and program 2 writes them to a new file. Verify with cmp.
 */
/*
 * Q62 - Program 1: copy a file INTO shared memory.
 * Compile : gcc q62_shm_file_copy_writer.c -o q62_shm_file_copy_writer
 *           gcc q62_shm_file_copy_reader.c -o q62_shm_file_copy_reader
 * Run     : ./q62_shm_file_copy_writer input.txt
 *           ./q62_shm_file_copy_reader copy.txt
 * Verify  : cmp input.txt copy.txt && echo "files identical"
 * Limit   : files up to 1 MB.   (Reader may be started first; it waits.)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define MAXF (1 << 20)
struct seg { volatile int ready; size_t len; char data[MAXF]; };

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s inputfile\n", argv[0]); return 1; }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("fopen"); return 1; }

    int id = shmget(ftok(".", 'F'), sizeof(struct seg), IPC_CREAT | 0666);
    struct seg *s = shmat(id, NULL, 0);
    if (id == -1 || s == (void *)-1) { perror("shm"); return 1; }

    s->len = fread(s->data, 1, MAXF, f);
    fclose(f);
    __sync_synchronize();
    s->ready = 1;                       /* tell reader data is complete */
    printf("Wrote %zu bytes into shared memory.\n", s->len);
    shmdt(s);
    return 0;
}
