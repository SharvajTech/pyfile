/*
 * PROBLEM STATEMENT (Q61)
 * Print the number of attached processes (shm_nattch) using shmctl(IPC_STAT)
 * before and after a second attach. Also check with ipcs -m.
 */
/*
 * Q61 - Print shm_nattch (number of attached processes) with
 *       shmctl(IPC_STAT) before and after a second attach, then check
 *       with  ipcs -m.
 * Compile : gcc q61_shm_nattch_ipcs.c -o q61_shm_nattch_ipcs
 * Run     : Terminal 1: ./q61_shm_nattch_ipcs
 *           When it pauses ("Press Enter"), open Terminal 2 and run:
 *                ipcs -m          (NATTCH column shows 2)
 *                ipcs -m -i <shmid>   (details for that segment)
 *           Then press Enter in Terminal 1 to continue.
 * Optional: run a second copy of ./q61_shm_nattch_ipcs in another terminal while the first
 *           is paused - both use the same key, so nattch counts both processes.
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

static unsigned long nattch(int id)
{
    struct shmid_ds ds;
    shmctl(id, IPC_STAT, &ds);
    return (unsigned long)ds.shm_nattch;
}

int main(void)
{
    int id = shmget(ftok(".", 'N'), 1024, IPC_CREAT | 0666);
    if (id == -1) { perror("shmget"); return 1; }
    printf("Segment id = %d\n", id);
    printf("Before any attach          : shm_nattch = %lu\n", nattch(id));

    void *p1 = shmat(id, NULL, 0);
    printf("After first attach         : shm_nattch = %lu\n", nattch(id));

    void *p2 = shmat(id, NULL, 0);          /* second attach */
    printf("After second attach        : shm_nattch = %lu\n", nattch(id));

    printf("Now run  'ipcs -m'  in another terminal. Press Enter to continue...");
    getchar();

    shmdt(p2);
    printf("After detaching one        : shm_nattch = %lu\n", nattch(id));
    shmdt(p1);
    printf("After detaching both       : shm_nattch = %lu\n", nattch(id));

    shmctl(id, IPC_RMID, NULL);
    return 0;
}
