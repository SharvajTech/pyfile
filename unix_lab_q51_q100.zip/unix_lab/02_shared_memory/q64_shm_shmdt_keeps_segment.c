/*
 * PROBLEM STATEMENT (Q64)
 * Show that shmdt() does not delete a segment: detach in one program, attach
 * again from another program, and then remove it using IPC_RMID.
 */
/*
 * Q64 (part 1) - Create a segment, write to it, DETACH with shmdt() and
 *                exit WITHOUT removing it.  shmdt() only unmaps; it does not
 *                delete the segment.
 * Compile : gcc q64_shm_shmdt_keeps_segment.c -o q64_shm_shmdt_keeps_segment
 *           gcc q64_shm_reattach_and_rmid.c -o q64_shm_reattach_and_rmid
 * Run     : ./q64_shm_shmdt_keeps_segment
 *           ipcs -m                (segment is STILL listed, nattch = 0)
 *           ./q64_shm_reattach_and_rmid    (attach again from another program,
 *                                   read data, then IPC_RMID)
 *           ipcs -m                (segment is gone)
 */
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(void)
{
    int id = shmget(ftok(".", 'D'), 256, IPC_CREAT | 0666);
    char *p = shmat(id, NULL, 0);
    if (id == -1 || p == (void *)-1) { perror("shm"); return 1; }

    strcpy(p, "Data written by program 1");
    shmdt(p);

    struct shmid_ds ds;
    shmctl(id, IPC_STAT, &ds);
    printf("Detached. Segment %d still exists, shm_nattch = %lu\n",
           id, (unsigned long)ds.shm_nattch);
    printf("Check with:  ipcs -m\n");
    return 0;                         /* NOTE: no IPC_RMID here */
}
