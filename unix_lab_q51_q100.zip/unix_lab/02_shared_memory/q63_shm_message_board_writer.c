/*
 * PROBLEM STATEMENT (Q63)
 * Make a message board in shared memory: a writer stores up to 5 text
 * messages in an array of strings and a reader prints them all.
 */
/*
 * Q63 - Message board in shared memory: WRITER stores up to 5 messages
 *       in an array of strings.
 * Compile : gcc q63_shm_message_board_writer.c -o q63_shm_message_board_writer
 *           gcc q63_shm_message_board_reader.c -o q63_shm_message_board_reader
 * Run     : ./q63_shm_message_board_writer     (type up to 5 lines; empty line stops early)
 *           ./q63_shm_message_board_reader     (prints all messages, removes the segment)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define MAXMSG 5
#define LEN 100
struct board { int count; char msg[MAXMSG][LEN]; };

int main(void)
{
    int id = shmget(ftok(".", 'B'), sizeof(struct board), IPC_CREAT | 0666);
    struct board *b = shmat(id, NULL, 0);
    if (id == -1 || b == (void *)-1) { perror("shm"); return 1; }

    b->count = 0;
    while (b->count < MAXMSG) {
        printf("Message %d (empty line to stop): ", b->count + 1);
        char line[LEN];
        if (!fgets(line, sizeof line, stdin)) break;
        line[strcspn(line, "\n")] = '\0';
        if (line[0] == '\0') break;
        strcpy(b->msg[b->count++], line);
    }
    printf("Stored %d message(s).\n", b->count);
    shmdt(b);
    return 0;
}
