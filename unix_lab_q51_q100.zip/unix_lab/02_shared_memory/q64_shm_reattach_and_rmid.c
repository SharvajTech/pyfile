/*
 * PROBLEM STATEMENT (Q64)
 * Show that shmdt() does not delete a segment: detach in one program, attach
 * again from another program, and then remove it using IPC_RMID.
 */
/*
 * Q64 (part 2) - Attach again to the segment left by q64_shm_shmdt_keeps_segment,
 *                read the data, detach, then remove with IPC_RMID.
 * Compile : gcc q64_shm_reattach_and_rmid.c -o q64_shm_reattach_and_rmid
 * Run     : after ./q64_shm_shmdt_keeps_segment
 */
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(void)
{
    key_t key = ftok(".", 'D');
    int id = shmget(key, 256, 0666);
    if (id == -1) { perror("shmget (run q64_shm_shmdt_keeps_segment first)"); return 1; }
    char *p = shmat(id, NULL, 0);
    if (p == (void *)-1) { perror("shmat"); return 1; }

    printf("Re-attached; data still there: \"%s\"\n", p);
    shmdt(p);

    if (shmctl(id, IPC_RMID, NULL) == 0)
        printf("Segment removed with IPC_RMID.\n");

    if (shmget(key, 256, 0666) == -1)
        printf("shmget now fails: %s  (segment is gone)\n", strerror(errno));
    return 0;
}
