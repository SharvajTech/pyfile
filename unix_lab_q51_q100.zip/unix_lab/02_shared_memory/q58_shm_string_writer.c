/*
 * PROBLEM STATEMENT (Q58)
 * The writer stores a string typed by the user in shared memory. The reader
 * prints it and then reverses it in the same shared memory.
 */
/*
 * Q58 - Writer: stores a string typed by the user in shared memory.
 * Compile : gcc q58_shm_string_writer.c -o q58_shm_string_writer
 *           gcc q58_shm_string_reverse_reader.c -o q58_shm_string_reverse_reader
 * Run     : ./q58_shm_string_writer      (type a string, program exits, segment stays)
 *           ./q58_shm_string_reverse_reader      (prints the string, reverses it IN the segment,
 *                              prints it again, then removes the segment)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 256

int main(void)
{
    int id = shmget(ftok(".", 'W'), SHM_SIZE, IPC_CREAT | 0666);
    if (id == -1) { perror("shmget"); return 1; }
    char *p = shmat(id, NULL, 0);
    if (p == (void *)-1) { perror("shmat"); return 1; }

    printf("Enter a string: ");
    if (!fgets(p, SHM_SIZE, stdin)) return 1;
    p[strcspn(p, "\n")] = '\0';
    printf("Stored \"%s\" in shared memory (id %d).\n", p, id);

    shmdt(p);
    return 0;
}
