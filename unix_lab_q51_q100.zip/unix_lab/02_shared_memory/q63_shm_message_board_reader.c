/*
 * PROBLEM STATEMENT (Q63)
 * Make a message board in shared memory: a writer stores up to 5 text
 * messages in an array of strings and a reader prints them all.
 */
/*
 * Q63 - Message board READER: prints all messages, then removes segment.
 * Compile : gcc q63_shm_message_board_reader.c -o q63_shm_message_board_reader
 * Run     : after ./q63_shm_message_board_writer  ->  ./q63_shm_message_board_reader
 */
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define MAXMSG 5
#define LEN 100
struct board { int count; char msg[MAXMSG][LEN]; };

int main(void)
{
    int id = shmget(ftok(".", 'B'), sizeof(struct board), 0666);
    if (id == -1) { perror("shmget (run q63_shm_message_board_writer first)"); return 1; }
    struct board *b = shmat(id, NULL, 0);
    if (b == (void *)-1) { perror("shmat"); return 1; }

    printf("---- Message Board (%d messages) ----\n", b->count);
    for (int i = 0; i < b->count; i++)
        printf("%d: %s\n", i + 1, b->msg[i]);

    shmdt(b);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
