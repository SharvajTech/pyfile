/*
 * PROBLEM STATEMENT (Q58)
 * The writer stores a string typed by the user in shared memory. The reader
 * prints it and then reverses it in the same shared memory.
 */
/*
 * Q58 - Reader: prints the string, reverses it in the same shared memory,
 *       prints the reversed string, then removes the segment.
 * Compile : gcc q58_shm_string_reverse_reader.c -o q58_shm_string_reverse_reader
 * Run     : run ./q58_shm_string_writer first, then ./q58_shm_string_reverse_reader
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 256

int main(void)
{
    int id = shmget(ftok(".", 'W'), SHM_SIZE, 0666);
    if (id == -1) { perror("shmget (run q58_shm_string_writer first)"); return 1; }
    char *p = shmat(id, NULL, 0);
    if (p == (void *)-1) { perror("shmat"); return 1; }

    printf("Original : %s\n", p);
    size_t n = strlen(p);
    for (size_t i = 0; i < n / 2; i++) {          /* reverse in place */
        char t = p[i]; p[i] = p[n - 1 - i]; p[n - 1 - i] = t;
    }
    printf("Reversed : %s   (stored back in shared memory)\n", p);

    shmdt(p);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
