/*
 * PROBLEM STATEMENT (Q62)
 * Copy a file using shared memory: program 1 writes the file contents into
 * the segment and program 2 writes them to a new file. Verify with cmp.
 */
/*
 * Q62 - Program 2: write the shared-memory contents to a NEW file.
 * Compile : gcc q62_shm_file_copy_reader.c -o q62_shm_file_copy_reader
 * Run     : ./q62_shm_file_copy_reader copy.txt        (after / while q62_shm_file_copy_writer runs)
 * Verify  : cmp input.txt copy.txt && echo "files identical"
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define MAXF (1 << 20)
struct seg { volatile int ready; size_t len; char data[MAXF]; };

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s outputfile\n", argv[0]); return 1; }
    int id = shmget(ftok(".", 'F'), sizeof(struct seg), IPC_CREAT | 0666);
    struct seg *s = shmat(id, NULL, 0);
    if (id == -1 || s == (void *)-1) { perror("shm"); return 1; }

    while (!s->ready) sleep(1);         /* wait for writer */

    FILE *f = fopen(argv[1], "wb");
    if (!f) { perror("fopen"); return 1; }
    fwrite(s->data, 1, s->len, f);
    fclose(f);
    printf("Wrote %zu bytes to %s\n", s->len, argv[1]);

    shmdt(s);
    shmctl(id, IPC_RMID, NULL);
    return 0;
}
