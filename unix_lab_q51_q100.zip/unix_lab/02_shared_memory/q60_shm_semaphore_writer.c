/*
 * PROBLEM STATEMENT (Q60)
 * One process writes 5 numbers into shared memory and another reads them and
 * prints the average. Synchronise them with a semaphore.
 */
/*
 * Q60 - Writer: puts 5 numbers in shared memory, then signals a POSIX
 *       named semaphore so that the reader may proceed.
 * Compile : gcc q60_shm_semaphore_writer.c -o q60_shm_semaphore_writer -pthread
 *           gcc q60_shm_semaphore_average_reader.c -o q60_shm_semaphore_average_reader -pthread
 * Run     : Terminal 1: ./q60_shm_semaphore_average_reader   (blocks on sem_wait)
 *           Terminal 2: ./q60_shm_semaphore_writer   (enter 5 numbers)
 *           The reader then prints the average.  (Order of start doesn't matter.)
 * Cleanup : if a run was interrupted:  rm -f /dev/shm/sem.q60_sem ; ipcrm -M <key>
 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(void)
{
    int id = shmget(ftok(".", 'A'), 5 * sizeof(int), IPC_CREAT | 0666);
    int *a = shmat(id, NULL, 0);
    if (id == -1 || a == (void *)-1) { perror("shm"); return 1; }
    sem_t *sem = sem_open("/q60_sem", O_CREAT, 0666, 0);   /* initial value 0 */
    if (sem == SEM_FAILED) { perror("sem_open"); return 1; }

    printf("Enter 5 integers: ");
    for (int i = 0; i < 5; i++)
        if (scanf("%d", &a[i]) != 1) return 1;

    sem_post(sem);                      /* data ready -> wake the reader */
    printf("Writer: data written, semaphore posted.\n");
    sem_close(sem);
    shmdt(a);
    return 0;
}
