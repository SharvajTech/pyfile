/*
 * PROBLEM STATEMENT (Q86)
 * Compute the sum of 1 to 1,000,000 using a parallel for loop with
 * reduction(+:sum). Compare its time with the serial version using
 * omp_get_wtime().
 */
/*
 * Q86 - Sum of 1..1,000,000 with parallel for + reduction(+:sum);
 *       compare with the serial version using omp_get_wtime().
 * Compile : gcc -fopenmp q86_omp_sum_reduction_timing.c -o q86_omp_sum_reduction_timing
 * Run     : ./q86_omp_sum_reduction_timing
 * Note    : for such a small loop, thread start-up overhead can make the
 *           parallel version no faster (or even slower) than the serial one.
 */
#include <stdio.h>
#include <omp.h>

#define N 1000000L

int main(void)
{
    long long sum = 0;
    double t0 = omp_get_wtime();
    for (long i = 1; i <= N; i++) sum += i;
    double serial = omp_get_wtime() - t0;
    printf("Serial   : sum = %lld   time = %.6f s\n", sum, serial);

    sum = 0;
    t0 = omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for (long i = 1; i <= N; i++) sum += i;
    double par = omp_get_wtime() - t0;
    printf("Parallel : sum = %lld   time = %.6f s  (%d threads)\n",
           sum, par, omp_get_max_threads());

    printf("Expected : %lld\n", (long long)N * (N + 1) / 2);
    return 0;
}
