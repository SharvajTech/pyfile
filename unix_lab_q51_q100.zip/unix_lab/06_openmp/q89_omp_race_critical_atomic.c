/*
 * PROBLEM STATEMENT (Q89)
 * Show a race condition by incrementing a shared counter inside a parallel
 * loop without protection. Fix it first with critical and then with atomic.
 */
/*
 * Q89 - Race condition on a shared counter, fixed with critical and atomic.
 * Compile : gcc -fopenmp -O1 q89_omp_race_critical_atomic.c -o q89_omp_race_critical_atomic
 * Run     : ./q89_omp_race_critical_atomic     (needs a multi-core machine to show the race; expected total = 4,000,000; the unprotected result
 *                      is usually smaller and different on every run)
 */
#include <stdio.h>
#include <omp.h>

#define N 1000000L

int main(void)
{
    omp_set_num_threads(4);
    long expected = N * 4;                         /* each of the 4 threads loops N times */

    volatile long unsafe = 0;                      /* volatile keeps the race visible */
    #pragma omp parallel
    {
        for (long i = 0; i < N; i++) unsafe++;     /* RACE: read-modify-write */
    }
    printf("No protection : %ld   (expected %ld)\n", unsafe, expected);

    long c1 = 0;
    double t0 = omp_get_wtime();
    #pragma omp parallel
    {
        for (long i = 0; i < N; i++) {
            #pragma omp critical
            c1++;
        }
    }
    printf("critical      : %ld   (%.4f s)\n", c1, omp_get_wtime() - t0);

    long c2 = 0;
    t0 = omp_get_wtime();
    #pragma omp parallel
    {
        for (long i = 0; i < N; i++) {
            #pragma omp atomic
            c2++;
        }
    }
    printf("atomic        : %ld   (%.4f s)\n", c2, omp_get_wtime() - t0);
    return 0;
}
