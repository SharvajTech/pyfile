/*
 * PROBLEM STATEMENT (Q87)
 * Multiply two 200 x 200 matrices using a parallel for loop. Compare the
 * time taken with 1, 2 and 4 threads.
 */
/*
 * Q87 - Multiply two 200x200 matrices with a parallel for loop;
 *       compare time with 1, 2 and 4 threads.
 * Compile : gcc -fopenmp -O2 q87_omp_matrix_multiply_threads.c -o q87_omp_matrix_multiply_threads
 * Run     : ./q87_omp_matrix_multiply_threads
 */
#include <stdio.h>
#include <omp.h>

#define N 200
static double A[N][N], B[N][N], C[N][N];

int main(void)
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) { A[i][j] = i + j; B[i][j] = i - j; }

    int counts[3] = { 1, 2, 4 };
    for (int t = 0; t < 3; t++) {
        omp_set_num_threads(counts[t]);
        double t0 = omp_get_wtime();

        #pragma omp parallel for
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++) {
                double s = 0;
                for (int k = 0; k < N; k++) s += A[i][k] * B[k][j];
                C[i][j] = s;
            }

        double el = omp_get_wtime() - t0;
        printf("%d thread(s): %.5f s   (check C[10][10] = %.0f)\n",
               counts[t], el, C[10][10]);
    }
    return 0;
}
