/*
 * PROBLEM STATEMENT (Q91)
 * Use schedule(static) and schedule(dynamic, 4) on a loop whose iterations
 * take uneven time. Print which thread runs which iteration and compare.
 */
/*
 * Q91 - schedule(static) vs schedule(dynamic, 4) on a loop whose iterations
 *       take uneven time (iteration i costs ~ i units).  Prints which thread
 *       ran which iteration and the total time.
 * Compile : gcc -fopenmp -O1 q91_omp_schedule_static_dynamic.c -o q91_omp_schedule_static_dynamic
 * Run     : ./q91_omp_schedule_static_dynamic
 * Expect  : static gives every thread a fixed block, so the thread with the
 *           heaviest iterations finishes last; dynamic hands out chunks of 4
 *           on demand, so the load is better balanced.
 */
#include <stdio.h>
#include <omp.h>

#define N 16

static volatile double sink;
static void work(int i)                 /* cost grows with i */
{
    double x = 0;
    for (long k = 0; k < (long)(i + 1) * 2000000L; k++) x += k * 0.5;
    sink = x;
}

int main(void)
{
    int owner[N];
    omp_set_num_threads(4);

    double t0 = omp_get_wtime();
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < N; i++) { owner[i] = omp_get_thread_num(); work(i); }
    double ts = omp_get_wtime() - t0;
    printf("schedule(static):\n");
    for (int i = 0; i < N; i++) printf("  iteration %2d -> thread %d\n", i, owner[i]);
    printf("  total time = %.3f s\n\n", ts);

    t0 = omp_get_wtime();
    #pragma omp parallel for schedule(dynamic, 4)
    for (int i = 0; i < N; i++) { owner[i] = omp_get_thread_num(); work(i); }
    double td = omp_get_wtime() - t0;
    printf("schedule(dynamic, 4):\n");
    for (int i = 0; i < N; i++) printf("  iteration %2d -> thread %d\n", i, owner[i]);
    printf("  total time = %.3f s\n", td);
    return 0;
}
