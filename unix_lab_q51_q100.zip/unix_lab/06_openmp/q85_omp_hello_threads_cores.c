/*
 * PROBLEM STATEMENT (Q85)
 * Use #pragma omp parallel to print "Hello from thread X of Y". Set the
 * number of threads to 4 with omp_set_num_threads() and print the number of
 * cores with omp_get_num_procs().
 */
/*
 * Q85 - "Hello from thread X of Y" with 4 threads; print number of cores.
 * Compile : gcc -fopenmp q85_omp_hello_threads_cores.c -o q85_omp_hello_threads_cores
 * Run     : ./q85_omp_hello_threads_cores
 */
#include <stdio.h>
#include <omp.h>

int main(void)
{
    printf("Number of cores (omp_get_num_procs) = %d\n", omp_get_num_procs());
    omp_set_num_threads(4);

    #pragma omp parallel
    {
        printf("Hello from thread %d of %d\n",
               omp_get_thread_num(), omp_get_num_threads());
    }
    return 0;
}
