/*
 * PROBLEM STATEMENT (Q88)
 * Use sections: one section prints prime numbers up to 100, another prints
 * even numbers up to 20 and the third prints the first 10 Fibonacci numbers.
 */
/*
 * Q88 - Three parallel sections: primes <= 100, even numbers <= 20,
 *       first 10 Fibonacci numbers.
 * Compile : gcc -fopenmp q88_omp_sections_primes_even_fib.c -o q88_omp_sections_primes_even_fib
 * Run     : ./q88_omp_sections_primes_even_fib      (output of the sections may interleave)
 */
#include <stdio.h>
#include <omp.h>

int main(void)
{
    omp_set_num_threads(3);
    #pragma omp parallel sections
    {
        #pragma omp section
        {
            char out[512]; int len = 0;
            len += sprintf(out + len, "[thread %d] Primes <= 100:", omp_get_thread_num());
            for (int n = 2; n <= 100; n++) {
                int prime = 1;
                for (int d = 2; d * d <= n; d++) if (n % d == 0) { prime = 0; break; }
                if (prime) len += sprintf(out + len, " %d", n);
            }
            printf("%s\n", out);
        }
        #pragma omp section
        {
            char out[256]; int len = 0;
            len += sprintf(out + len, "[thread %d] Even numbers <= 20:", omp_get_thread_num());
            for (int n = 2; n <= 20; n += 2) len += sprintf(out + len, " %d", n);
            printf("%s\n", out);
        }
        #pragma omp section
        {
            char out[256]; int len = 0;
            len += sprintf(out + len, "[thread %d] First 10 Fibonacci:", omp_get_thread_num());
            long a = 0, b = 1;
            for (int i = 0; i < 10; i++) {
                len += sprintf(out + len, " %ld", a);
                long t = a + b; a = b; b = t;
            }
            printf("%s\n", out);
        }
    }
    return 0;
}
