/*
 * PROBLEM STATEMENT (Q92)
 * Compute the value of pi using numerical integration (rectangle rule) with
 * a parallel for and reduction. Test it with different numbers of threads.
 */
/*
 * Q92 - Compute pi by numerical integration (rectangle rule) of
 *       4/(1+x^2) over [0,1] with parallel for + reduction.
 *       Tested with different numbers of threads.
 * Compile : gcc -fopenmp -O2 q92_omp_pi_integration.c -o q92_omp_pi_integration
 * Run     : ./q92_omp_pi_integration
 */
#include <stdio.h>
#include <omp.h>

#define STEPS 200000000L

int main(void)
{
    double dx = 1.0 / STEPS;
    int counts[4] = { 1, 2, 4, 8 };

    for (int t = 0; t < 4; t++) {
        omp_set_num_threads(counts[t]);
        double sum = 0.0;
        double t0 = omp_get_wtime();

        #pragma omp parallel for reduction(+:sum)
        for (long i = 0; i < STEPS; i++) {
            double x = (i + 0.5) * dx;          /* midpoint of rectangle */
            sum += 4.0 / (1.0 + x * x);
        }
        double pi = sum * dx;
        printf("%d thread(s): pi = %.12f   error = %.2e   time = %.4f s\n",
               counts[t], pi, pi - 3.141592653589793, omp_get_wtime() - t0);
    }
    return 0;
}
