/*
 * PROBLEM STATEMENT (Q90)
 * Find the largest element in an array of 1 million random numbers using a
 * parallel for loop with reduction(max:...).
 */
/*
 * Q90 - Largest element of an array of 1,000,000 random numbers using
 *       parallel for with reduction(max:...).
 * Compile : gcc -fopenmp q90_omp_max_reduction.c -o q90_omp_max_reduction
 * Run     : ./q90_omp_max_reduction
 */
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define N 1000000

int main(void)
{
    int *a = malloc(N * sizeof(int));
    srand(42);
    for (int i = 0; i < N; i++) a[i] = rand();

    int max = a[0];
    double t0 = omp_get_wtime();
    #pragma omp parallel for reduction(max:max)
    for (int i = 0; i < N; i++)
        if (a[i] > max) max = a[i];
    double el = omp_get_wtime() - t0;

    int check = a[0];                              /* serial check */
    for (int i = 1; i < N; i++) if (a[i] > check) check = a[i];

    printf("Parallel max = %d  (%.6f s, %d threads)\n", max, el, omp_get_max_threads());
    printf("Serial   max = %d   %s\n", check, max == check ? "-> match" : "-> MISMATCH");
    free(a);
    return 0;
}
