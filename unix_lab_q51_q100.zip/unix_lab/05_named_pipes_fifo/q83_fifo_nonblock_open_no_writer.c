/*
 * PROBLEM STATEMENT (Q83)
 * Open a FIFO for reading with O_NONBLOCK when no writer exists. Print what
 * open() and read() return, and compare with a blocking open.
 */
/*
 * Q83 - Open a FIFO for reading with O_NONBLOCK when NO writer exists.
 *       Print what open() and read() return, then compare with a
 *       blocking open().
 * Compile : gcc q83_fifo_nonblock_open_no_writer.c -o q83_fifo_nonblock_open_no_writer
 * Run     : ./q83_fifo_nonblock_open_no_writer
 * Expected:
 *   open(O_RDONLY|O_NONBLOCK) -> succeeds at once (fd >= 0)
 *   read() with no writer     -> returns 0 (EOF)
 *   open(O_WRONLY|O_NONBLOCK) with no reader -> -1, errno ENXIO
 *   blocking open(O_RDONLY)   -> waits until a writer opens (~3 s here)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define FIFO "/tmp/q83_fifo"

int main(void)
{
    unlink(FIFO);
    if (mkfifo(FIFO, 0666) == -1) { perror("mkfifo"); return 1; }

    /* ---- 1. Non-blocking read open, no writer ---- */
    int fd = open(FIFO, O_RDONLY | O_NONBLOCK);
    printf("[non-blocking] open(O_RDONLY|O_NONBLOCK) returned %d\n", fd);
    char buf[64];
    ssize_t n = read(fd, buf, sizeof buf);
    printf("[non-blocking] read() returned %zd  (0 = EOF, because no writer exists)\n", n);
    close(fd);

    /* ---- 2. Non-blocking WRITE open, no reader ---- */
    int wfd = open(FIFO, O_WRONLY | O_NONBLOCK);
    printf("[non-blocking] open(O_WRONLY|O_NONBLOCK) returned %d (%s)\n",
           wfd, wfd < 0 ? strerror(errno) : "ok");

    /* ---- 3. Blocking open: a child opens the writer after 3 seconds ---- */
    pid_t pid = fork();
    if (pid == 0) {
        sleep(3);
        int w = open(FIFO, O_WRONLY);
        write(w, "hello", 5);
        sleep(1);
        close(w);
        _exit(0);
    }
    printf("[blocking]     calling open(O_RDONLY) - will block until a writer appears...\n");
    time_t t0 = time(NULL);
    fd = open(FIFO, O_RDONLY);
    printf("[blocking]     open returned %d after about %ld second(s)\n", fd, (long)(time(NULL) - t0));
    n = read(fd, buf, sizeof buf);
    printf("[blocking]     read() returned %zd bytes: \"%.*s\"\n", n, (int)n, buf);
    n = read(fd, buf, sizeof buf);
    printf("[blocking]     next read() returned %zd (writer closed -> EOF)\n", n);
    close(fd);
    wait(NULL);
    unlink(FIFO);
    return 0;
}
