/*
 * PROBLEM STATEMENT (Q80)
 * A server reads a file name from one FIFO and writes the contents of that
 * file into a second FIFO. The client prints the contents.
 */
/*
 * Q80 - FIFO file client: sends a file name, prints the contents received.
 * Compile : gcc q80_fifo_file_client.c -o q80_fifo_file_client
 * Run     : ./q80_fifo_file_client filename      (start q80_fifo_file_server first)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#define REQ  "/tmp/q80_request"
#define RESP "/tmp/q80_response"

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "Usage: %s filename\n", argv[0]); return 1; }

    int rq = open(REQ, O_WRONLY);
    if (rq < 0) { perror("open request FIFO (is the server running?)"); return 1; }
    write(rq, argv[1], strlen(argv[1]));
    close(rq);

    int rp = open(RESP, O_RDONLY);
    char buf[4096];
    ssize_t n;
    while ((n = read(rp, buf, sizeof buf)) > 0) fwrite(buf, 1, n, stdout);
    close(rp);
    return 0;
}
