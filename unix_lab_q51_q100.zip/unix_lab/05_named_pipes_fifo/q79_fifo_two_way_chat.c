/*
 * PROBLEM STATEMENT (Q79)
 * Write a chat between two terminals using two FIFOs. The chat ends when
 * either side types "quit".
 */
/*
 * Q79 - Chat between two terminals using TWO FIFOs (one per direction).
 *       The chat ends when either side types "quit".
 * Compile : gcc q79_fifo_two_way_chat.c -o q79_fifo_two_way_chat
 * Run     : Terminal 1: ./q79_fifo_two_way_chat A      (A speaks first)
 *           Terminal 2: ./q79_fifo_two_way_chat B
 * FIFOs   : /tmp/q79_a2b  (A -> B)   and   /tmp/q79_b2a  (B -> A)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define F_AB "/tmp/q79_a2b"
#define F_BA "/tmp/q79_b2a"

int main(int argc, char *argv[])
{
    if (argc != 2 || (argv[1][0] != 'A' && argv[1][0] != 'B')) {
        fprintf(stderr, "Usage: %s A|B\n", argv[0]);
        return 1;
    }
    int isA = (argv[1][0] == 'A');

    if (mkfifo(F_AB, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    if (mkfifo(F_BA, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }

    /* Opening order is chosen so the two sides never deadlock. */
    int wfd, rfd;
    printf("Waiting for the other side...\n");
    if (isA) { wfd = open(F_AB, O_WRONLY); rfd = open(F_BA, O_RDONLY); }
    else     { rfd = open(F_AB, O_RDONLY); wfd = open(F_BA, O_WRONLY); }
    FILE *in  = fdopen(rfd, "r");
    FILE *out = fdopen(wfd, "w");
    printf("Connected. Type \"quit\" to end.\n");

    char line[256];
    int myturn = isA;
    for (;;) {
        if (myturn) {
            printf("you  : ");
            fflush(stdout);
            if (!fgets(line, sizeof line, stdin)) strcpy(line, "quit\n");
            fputs(line, out);
            fflush(out);
            if (strcmp(line, "quit\n") == 0) break;
        } else {
            if (!fgets(line, sizeof line, in)) { printf("Peer disconnected.\n"); break; }
            printf("peer : %s", line);
            if (strcmp(line, "quit\n") == 0) { printf("Peer ended the chat.\n"); break; }
        }
        myturn = !myturn;
    }
    fclose(in);
    fclose(out);
    unlink(F_AB);
    unlink(F_BA);
    return 0;
}
