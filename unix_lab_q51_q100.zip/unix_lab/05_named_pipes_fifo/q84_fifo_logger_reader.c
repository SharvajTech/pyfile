/*
 * PROBLEM STATEMENT (Q84)
 * Write a logger: three writers in three terminals write messages to the
 * same FIFO, and one reader appends each message with a timestamp to a log
 * file.
 */
/*
 * Q84 - Logger: reads messages from one FIFO and appends each, with a
 *       timestamp, to a log file.  Several writers may use the FIFO at once.
 * Compile : gcc q84_fifo_logger_reader.c -o q84_fifo_logger_reader
 *           gcc q84_fifo_logger_writer.c -o q84_fifo_logger_writer
 * Run     : Terminal 1: ./q84_fifo_logger_reader [logfile]       (default: q84.log)
 *           Terminal 2: ./q84_fifo_logger_writer W1
 *           Terminal 3: ./q84_fifo_logger_writer W2
 *           Terminal 4: ./q84_fifo_logger_writer W3
 *           Watch:      tail -f q84.log
 *           Stop logger with Ctrl-C (removes the FIFO).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>

#define FIFO "/tmp/q84_log_fifo"

static void cleanup(int s) { (void)s; unlink(FIFO); _exit(0); }

int main(int argc, char *argv[])
{
    const char *logname = argc > 1 ? argv[1] : "q84.log";
    if (mkfifo(FIFO, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    signal(SIGINT, cleanup);

    int rfd = open(FIFO, O_RDONLY);          /* waits for first writer */
    int dummy = open(FIFO, O_WRONLY);        /* keep a writer open so we never see EOF
                                                when all real writers have gone */
    (void)dummy;
    FILE *in  = fdopen(rfd, "r");
    FILE *log = fopen(logname, "a");
    if (!log) { perror("fopen log"); return 1; }
    printf("Logger running, appending to %s\n", logname);

    char line[512];
    while (fgets(line, sizeof line, in)) {
        time_t t = time(NULL);
        char ts[32];
        strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", localtime(&t));
        fprintf(log, "[%s] %s", ts, line);
        fflush(log);
    }
    return 0;
}
