/*
 * PROBLEM STATEMENT (Q81)
 * The writer sends 5 numbers through a FIFO. The reader adds them and prints
 * the total.
 */
/*
 * Q81 - Reader: receives 5 numbers from the FIFO, prints their total.
 * Compile : gcc q81_fifo_five_numbers_sum_reader.c -o q81_fifo_five_numbers_sum_reader
 * Run     : ./q81_fifo_five_numbers_sum_reader   (then run ./q81_fifo_five_numbers_writer in another terminal)
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define FIFO "/tmp/q81_fifo"

int main(void)
{
    if (mkfifo(FIFO, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    printf("Reader: waiting for writer...\n");
    int fd = open(FIFO, O_RDONLY);                /* blocks until writer opens */
    int n[5], total = 0;
    ssize_t got = read(fd, n, sizeof n);
    close(fd);
    if (got != (ssize_t)sizeof n) { fprintf(stderr, "short read\n"); return 1; }
    printf("Numbers:");
    for (int i = 0; i < 5; i++) { printf(" %d", n[i]); total += n[i]; }
    printf("\nTotal = %d\n", total);
    unlink(FIFO);
    return 0;
}
