/*
 * PROBLEM STATEMENT (Q84)
 * Write a logger: three writers in three terminals write messages to the
 * same FIFO, and one reader appends each message with a timestamp to a log
 * file.
 */
/*
 * Q84 - Logger writer: every line typed is sent to the shared FIFO,
 *       prefixed with the writer's name.  Run one per terminal.
 * Compile : gcc q84_fifo_logger_writer.c -o q84_fifo_logger_writer
 * Run     : ./q84_fifo_logger_writer NAME        (Ctrl-D to quit)
 * Note    : each message is sent with ONE write() of less than PIPE_BUF
 *           bytes, so lines from different writers never get mixed up.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

#define FIFO "/tmp/q84_log_fifo"

int main(int argc, char *argv[])
{
    const char *name = argc > 1 ? argv[1] : "writer";
    int fd = open(FIFO, O_WRONLY);
    if (fd < 0) { perror("open FIFO (is q84_fifo_logger_reader running?)"); return 1; }

    char line[400], msg[512];
    printf("[%s] type messages (Ctrl-D to quit)\n", name);
    while (fgets(line, sizeof line, stdin)) {
        int len = snprintf(msg, sizeof msg, "%s: %s", name, line);
        if (msg[len - 1] != '\n') { msg[len++] = '\n'; msg[len] = '\0'; }
        write(fd, msg, len);               /* single atomic write */
    }
    close(fd);
    return 0;
}
