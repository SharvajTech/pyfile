/*
 * PROBLEM STATEMENT (Q80)
 * A server reads a file name from one FIFO and writes the contents of that
 * file into a second FIFO. The client prints the contents.
 */
/*
 * Q80 - FIFO file server: reads a file name from FIFO 1 (request) and
 *       writes the file content into FIFO 2 (response).
 * Compile : gcc q80_fifo_file_server.c -o q80_fifo_file_server
 *           gcc q80_fifo_file_client.c -o q80_fifo_file_client
 * Run     : Terminal 1: ./q80_fifo_file_server          (Ctrl-C to stop)
 *           Terminal 2: ./q80_fifo_file_client somefile.txt
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/stat.h>

#define REQ  "/tmp/q80_request"
#define RESP "/tmp/q80_response"

static void cleanup(int s) { (void)s; unlink(REQ); unlink(RESP); _exit(0); }

int main(void)
{
    if (mkfifo(REQ,  0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    if (mkfifo(RESP, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    signal(SIGINT, cleanup);
    printf("File server ready (FIFOs: %s, %s)\n", REQ, RESP);

    for (;;) {
        int rq = open(REQ, O_RDONLY);               /* blocks until a client writes */
        char name[256];
        ssize_t n = read(rq, name, sizeof name - 1);
        close(rq);
        if (n <= 0) continue;
        name[n] = '\0';
        name[strcspn(name, "\r\n")] = '\0';
        printf("Request: %s\n", name);

        int rp = open(RESP, O_WRONLY);              /* blocks until client reads */
        int fd = open(name, O_RDONLY);
        if (fd < 0) {
            const char *err = "ERROR: cannot open that file\n";
            write(rp, err, strlen(err));
        } else {
            char buf[4096];
            ssize_t r;
            while ((r = read(fd, buf, sizeof buf)) > 0) write(rp, buf, r);
            close(fd);
        }
        close(rp);
    }
}
