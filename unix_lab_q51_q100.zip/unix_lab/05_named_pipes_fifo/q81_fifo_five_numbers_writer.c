/*
 * PROBLEM STATEMENT (Q81)
 * The writer sends 5 numbers through a FIFO. The reader adds them and prints
 * the total.
 */
/*
 * Q81 - Writer: sends 5 numbers through a FIFO.
 * Compile : gcc q81_fifo_five_numbers_writer.c -o q81_fifo_five_numbers_writer
 *           gcc q81_fifo_five_numbers_sum_reader.c -o q81_fifo_five_numbers_sum_reader
 * Run     : Terminal 1: ./q81_fifo_five_numbers_sum_reader     (waits, adds, prints total)
 *           Terminal 2: ./q81_fifo_five_numbers_writer     (type 5 numbers)
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define FIFO "/tmp/q81_fifo"

int main(void)
{
    if (mkfifo(FIFO, 0666) == -1 && errno != EEXIST) { perror("mkfifo"); return 1; }
    int fd = open(FIFO, O_WRONLY);                /* blocks until reader opens */
    int n[5];
    printf("Enter 5 integers: ");
    for (int i = 0; i < 5; i++)
        if (scanf("%d", &n[i]) != 1) return 1;
    write(fd, n, sizeof n);
    close(fd);
    printf("Writer: sent 5 numbers.\n");
    return 0;
}
