#!/bin/bash
# Compile every program into ./bin  (usage: ./build.sh)
# Needs: gcc (all), libgomp/-fopenmp (OpenMP), mpicc (MPI), javac (Q70).
# Sources are compiled with the flags given in the header comment of each file.
mkdir -p bin
ok=0; bad=0
build() {   # build <compiler> <flags> <file>
    out="bin/$(basename "${3%.c}")"
    if $1 $2 "$3" -o "$out" 2>/tmp/build_err.txt; then ok=$((ok+1)); else bad=$((bad+1)); echo "FAILED: $3"; cat /tmp/build_err.txt; fi
}
for f in 01_message_queue/*.c 03_sockets/*.c 04_unnamed_pipes/*.c 05_named_pipes_fifo/*.c; do build gcc "-Wall" "$f"; done
for f in 02_shared_memory/*.c; do build gcc "-Wall -pthread" "$f"; done
for f in 06_openmp/*.c; do build gcc "-Wall -O2 -fopenmp" "$f"; done
if command -v mpicc >/dev/null; then
    for f in 07_mpi/*.c; do build mpicc "-O2" "$f"; done
else echo "mpicc not found - skipping 07_mpi (sudo apt install mpich)"; fi
if command -v javac >/dev/null; then
    (cd 03_sockets && javac Q70_*.java) && echo "Java (Q70) compiled in 03_sockets/"
else echo "javac not found - skipping Q70 (sudo apt install default-jdk)"; fi
echo "Built OK: $ok   Failed: $bad   -> executables are in ./bin"
